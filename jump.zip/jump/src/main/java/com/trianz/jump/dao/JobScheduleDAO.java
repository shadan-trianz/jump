package com.trianz.jump.dao;

import java.sql.Timestamp;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.model.Batch;
import com.trianz.jump.model.FulfilledCandidate;
import com.trianz.jump.services.JobScheduleService;

@Repository
public class JobScheduleDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(JobScheduleService.class);

	private final String JOB_TABLE = "JOB_SCHEDULE";
	private final String TALENTO_VIEW = "JUMP.dbo.vw_HRRFDetailJump";
	private final String APP_HIST = "APPLICATIONS_STATUS_HIST";

	public Batch getPendingJob() {
		log.debug(">>> jobScheduleDao.getPendingJob()");
		
		String sql = "SELECT TOP(1) BATCH_ID, START_TIME from " + JOB_TABLE + " WHERE STATUS IN ('P', 'R', 'F')"
				+ " ORDER BY START_TIME DESC";
		try {
			Batch startTimeOfLatestJob = jdbcTemplate.queryForObject(sql, (rs, row) -> {
				Batch cur = new Batch();
				cur.setBatchId(rs.getString("BATCH_ID"));
				cur.setStartTime(rs.getTimestamp("START_TIME"));
				return cur;
			});

			log.debug("<<< jobScheduleDao.getPendingJob()");
			return startTimeOfLatestJob;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public boolean updateCurrentBatch(String batchId, Timestamp endTime, String status) {
		log.debug(">>> jobScheduleDao.updateCurrentBatch()");
		
		String sql = "UPDATE " + JOB_TABLE + " SET END_TIME = ?, STATUS = ? WHERE BATCH_ID = ?";
		try {

			int result = jdbcTemplate.update(sql, endTime, status, batchId);
			
			log.debug("<<< jobScheduleDao.updateCurrentBatch()");
			return result > 0;
			
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public List<String> getJumpSelectedCandidates(Timestamp startTime, Timestamp endTime) {
		log.debug(">>> jobScheduleDao.getJumpSelectedCandidates()");
		
		// Get the list of candidates whose status was updated to SELECTED between start
		// and end time AND
		// the current status in applications table is also SELECTED
		String sql = "SELECT DISTINCT HIST.TR_ID FROM " + APP_HIST + " AS HIST"
				+ " JOIN APPLICATIONS ON HIST.TR_ID=APPLICATIONS.TR_ID"
				+ " WHERE APPLICATIONS.APPLICATION_STATUS_ID=50 AND" + " HIST.APPLICATION_STATUS_ID=50 AND"
				+ " HIST.LST_UPD_DATE BETWEEN ? AND ?";
		try {

			List<String> selectedCandidates = jdbcTemplate.query(sql, (rs, row) -> {

				return rs.getString("TR_ID");
				
			}, startTime, endTime);

			log.debug("<<< jobScheduleDao.getJumpSelectedCandidates()");
			return selectedCandidates;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get the list of candidates whose TR status was updated to CANCELLED/FULFILLED
	public List<String> getTalentoUpdatedCandidates() {
		log.debug(">>> jobScheduleDao.getTalentoUpdatedCandidates()");
		
		String sql = "SELECT DISTINCT TR_ID FROM APPLICATIONS JOIN " + TALENTO_VIEW
				+ " ON TR_ID=HRRFNUMBER"
				+ " WHERE APPLICATION_STATUS_ID IN (1,10,20) AND RequestStatus IN ('Cancelled', 'Fulfilled')";
		try {
			List<String> selectedCandidates = jdbcTemplate.query(sql, (rs, row) -> {

				return rs.getString("TR_ID");
			});

			log.debug("<<< jobScheduleDao.getTalentoUpdatedCandidates()");
			return selectedCandidates;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public boolean updateStatusToFulfilled(String item) {
		log.debug(">>> jobScheduleDao.updateStatusToFulfilled()");
		log.debug("Updated Active Applications of TR: "+item);
		
		String sql = "UPDATE APPLICATIONS SET APPLICATION_STATUS_ID=70"
				+ " WHERE TR_ID=? AND APPLICATION_STATUS_ID IN (1, 10, 20)";
		try {
			int res = jdbcTemplate.update(sql, item);

			log.debug("<<< jobScheduleDao.updateStatusToFulfilled()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public List<FulfilledCandidate> getFulfilledCandidates(Timestamp startTime) {
		log.debug(">>> jobScheduleDao.getFulfilledCandidates()");
		
		String sql = "SELECT DISTINCT EMP_EMAILID, TR_ID, RoleRequired FROM " + APP_HIST + " AS HIST JOIN "
				+ TALENTO_VIEW + " AS TALENTO ON HIST.TR_ID=TALENTO.HRRFNUMBER WHERE APPLICATION_STATUS_ID=70"
				+ " AND LST_UPD_DATE BETWEEN ? AND CURRENT_TIMESTAMP";
		try {
			List<FulfilledCandidate> fulfilledCandidates = jdbcTemplate.query(sql, (rs, row) -> {

				FulfilledCandidate candidate = new FulfilledCandidate();
				candidate.setEmail(rs.getString("EMP_EMAILID"));
				candidate.setTrId(rs.getString("TR_ID"));
				candidate.setPosition(rs.getString("RoleRequired"));
				return candidate;

			}, startTime);
			
			log.debug("<<< jobScheduleDao.getFulfilledCandidates()");
			return fulfilledCandidates;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public boolean createNewBatch(Timestamp startTime) {
		log.debug(">>> jobScheduleDao.createNewBatch()");
		
		String sql = "INSERT INTO " + JOB_TABLE + "(START_TIME, STATUS) VALUES(?, 'P')";
		try {
			int res = jdbcTemplate.update(sql, startTime);

			log.debug("<<< jobScheduleDao.createNewBatch()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	public String getCronTime() {
		log.debug(">>> dao.getCronTime");
		String sql = "SELECT cron_time from cron";
		String res = jdbcTemplate.queryForObject(sql, String.class);
		log.debug("<<< dao.getCronTime");
		return res;
	}

}
