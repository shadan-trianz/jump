package com.trianz.jump.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.dao.FeedbackDAO;
import com.trianz.jump.dao.TRDAO;
import com.trianz.jump.model.Feedback;
import com.trianz.jump.model.HistoryFeedbackDTO;
import com.trianz.jump.model.HistoryFeedbackRecruiterDTO;

@Service
public class FeedbackService {

	@Autowired
	private FeedbackDAO feedbackDao;
	
	@Autowired
	private TRDAO trDao;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private Environment environment;

	Logger log = LoggerFactory.getLogger(FeedbackService.class);

	// Updates the feedback
	public Map<String, Object> updateFeedback(String interviewerName, String interviewerEmail, Feedback feedback) {
		log.debug(">>> service.updateFeedback()");

		String message = "";
		try {
			boolean result = false;
			String subject = "";
			String template = "";
			Map<String, Object> variables = new HashMap<>();

			// Update feedback
			if (feedback.getLevel() != null && !feedback.getLevel().isEmpty()) {
				result = feedbackDao.updateFeedbackStatus(interviewerName, feedback);
				
				if(result) {
					if (getCurrentEnvironment()) {
						subject = "[NON-PROD] ";
					}
					
					String name = feedback.getEmail();
					name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
					name = name.substring(0, 1).toUpperCase() + name.substring(1);
					
					String job = trDao.getRoleRequired(feedback.getTrId());
					
					if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.FIRST) && feedback.getRating()>=3) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_1 + " [ " + feedback.getTrId() + " ]";
						template = "select";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("level", "Level 1");
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.SECOND) && feedback.getRating()>=3) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_2 + " [ " + feedback.getTrId() + " ]";
						template = "select";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("level", "Level 2");
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.HR) && feedback.getRating()>=3) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_HR + job +" [ " + feedback.getTrId() + " ]";
						template = "selectHR";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.CLIENT) && feedback.getRating()>=3) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_CLIENT + " [ " + feedback.getTrId() + " ]";
						template = "selectClient";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.FIRST) && feedback.getRating()<3) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_1 + " [ " + feedback.getTrId() + " ]";
						template = "reject";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.SECOND) && feedback.getRating()<3) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_2 + " [ " + feedback.getTrId() + " ]";
						template = "reject";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.HR) && feedback.getRating()<3) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_HR + " [ " + feedback.getTrId() + " ]";
						template = "rejectHR";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if(feedback.getLevel().equalsIgnoreCase(JumpConstatnts.CLIENT) && feedback.getRating()<3) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_CLIENT + " [ " + feedback.getTrId() + " ]";
						template = "rejectClient";
						variables.put("jobTitle", job);
						variables.put("name", name);
					}
					
					emailService.sendEmail(feedback.getEmail(), "", subject, template, variables);
				}
				message = "Successfully updated the feedback status!";
			} 
			if (!result)
				message = "Unsuccessful! Feedback for the given TR ID and EMAIL ID doesn't exist.";

			Map<String, Object> res = new HashMap<>();
			res.put("message", message);

			log.debug("<<< service.updateFeedback()");
			return res;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get history of feedback status
	public Map<String, Object> getFeedbackHistory(String trId, String email, String name, String level) {
		log.debug(">>> service.getFeedbackHistory()");

		try {
			// Get Feedback history
			List<HistoryFeedbackDTO> feedbackHist = feedbackDao.getFeedbackHistory(trId, email, name, level);

			Map<String, Object> resp = new HashMap<>();
			resp.put("feedbackHist", feedbackHist);
			resp.put("message", "success");

			log.debug("<<< service.getFeedbackHistory()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get history of the feedback
	
	public Map<String, Object> getFeedbackHistoryRecruiter(String trId, String email, String level) {
		log.debug(">>> service.getFeedbackHistoryRecruiter()");

		try {
			// Get Feedback history
			List<HistoryFeedbackRecruiterDTO> feedbackHist = feedbackDao.getFeedbackHistoryRecruiter(trId, email,
					level);

			Map<String, Object> resp = new HashMap<>();
			resp.put("feedbackHist", feedbackHist);
			resp.put("message", "success");

			log.debug("<<< service.getFeedbackHistoryRecruiter()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
	
	private boolean getCurrentEnvironment() {
		String[] activeEnv = environment.getActiveProfiles();
		return Stream.of(activeEnv).anyMatch(s -> s.contains(JumpConstatnts.DEV));
	}
}
