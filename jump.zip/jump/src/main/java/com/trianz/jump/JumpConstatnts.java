package com.trianz.jump;

public class JumpConstatnts {
	
	public static final String APPLIED = "Applied";
	public static final String INPROCESS = "In Process";
	public static final String INTERVIEWING = "Interviewing";
	public static final String LEVEL_1_SCHEDULE = "Level 1 Scheduled";
	public static final String LEVEL_2_SCHEDULE = "Level 2 Scheduled";
	public static final String HR_SCHEDULE = "HR Scheduled";
	public static final String CLIENT_SCHEDULE = "Client Scheduled";
	public static final String LEVEL_1_REJECT = "Level 1 Rejected";
	public static final String LEVEL_2_REJECT = "Level 2 Rejected";
	public static final String HR_REJECT = "HR Rejected";
	public static final String CLIENT_REJECT = "Client Rejected";
	public static final String SELECT = "Select";
	public static final String LEVEL_1_SELECT = "Level 1 Selected";
	public static final String LEVEL_2_SELECT = "Level 2 Selected";
	public static final String HR_SELECT = "HR Selected";
	public static final String CLIENT_SELECT = "Client Selected";
	public static final String OFFER_ACCEPT = "Offer Accepted";
	public static final String OFFER_REJECT = "Offer Rejected";
	public static final String POSITION_OFFERED = "Position Offered";
	public static final String RELIEVE_CONFIRM = "Relieving Confirmed";
	public static final String CLOSED = "Closed";
	public static final String RECRUITER = "Recruiter";
	
	public static final String REJECTED_TEXT_1 = "Update on Your Internal Job Application for Level 1";
	public static final String REJECTED_TEXT_2 = "Update on Your Internal Job Application for Level 2";
	public static final String REJECTED_TEXT_HR = "Update on Your Application – HR Discussion Outcome";
	public static final String REJECTED_TEXT_CLIENT = "Update on Your Application – Client Decision";
	public static final String WITHDRAW_TEXT = "Update on Your Application ";
	public static final String APPLIED_TEXT = "Successfully applied to the Internal Job";
	public static final String CLOSED_TEXT = "Closure of Your JUMP Program Application";
	public static final String SELECTED_TEXT_1 = "Congratulations! You Have Been Selected in Level 1";
	public static final String SELECTED_TEXT_2 = "Congratulations! You Have Been Selected in Level 2";
	public static final String SELECTED_TEXT_HR = "Congratulations! Selected for ";
	public static final String SELECTED_TEXT_CLIENT = "Congratulations! Selected in Client Round";
	public static final String FULL_FILLED_TEXT = "Closure of Your JUMP Program Application";
	public static final String IN_PROCESS_TEXT = "Your JUMP Program Application is Being Processed";
	public static final String INTERVIEWING_TEXT_1 = "Level 1 Technical Discussion Scheduled";
	public static final String INTERVIEWING_TEXT_2 = "Level 2 Technical Discussion Scheduled";
	public static final String INTERVIEWING_TEXT_HR= "HR Discussion Scheduled";
	public static final String INTERVIEWING_TEXT_CLIENT = "Scheduled Discussion with";
	public static final String OFFER_REJECTION_ACKNOWLEDGE = "Acknowledgment of Offer Rejection – ";
	public static final String OFFER_ACCEPTANCE = "Confirmation of Offer Acceptance – ";
	public static final String DISCUSS_LEVEL1 = "Level 1 Technical Discussion";
	public static final String DISCUSS_LEVEL2 = "Level 2 Technical Discussion";
	public static final String DISCUSS_HR= "HR Discussion";
	public static final String DISCUSS_CLIENT = "Client Discussion";
	
	public static final String DEV = "dev";
	public static final String NAME = "X-XSS-Protection";
	public static final String VALUE = "1; mode=block";
	public static final String JUMP = "/jump/";
	public static final String JUMP_RECRUITER = "/jump/recruiter";
	public static final String JUMP_TR = "/jump/tr";
	public static final String JUMP_FEEDBACK_UPDATE = "/jump/feedback";
	public static final String ROLES = "roles";
	public static final String PROFILE = "/profile";
	public static final String GET = "GET";
	public static final String SECURITY_CONTEXT = "SPRING_SECURITY_CONTEXT";
	public static final String TRIANZ = " (Trianz)";
	
	public static final String FIRST = "first";
	public static final String SECOND = "second";
	public static final String HR = "hr";
	public static final String CLIENT = "client";
}
