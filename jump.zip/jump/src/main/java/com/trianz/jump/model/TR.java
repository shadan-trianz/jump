package com.trianz.jump.model;


public class TR {
	
	private String trId;
	private String jobTitle;
	private String organizationGroup;
	private String jobDescription;
	private String primarySkills;
	private String experience;
	private String grade;
	private String location;
	private String practice;
	private String accountName;
	private String projectName;
	private String firstLevelTechPanel;
	private String secondLevelTechPanel;
	private String applicationsCount;
	private String assignmentStartDate;
	private String techPanelEmail;
	private String secondtechPanelEmail;
	private boolean canApply;
	
	public TR() {
		super();
	}

	public TR(String trId, String jobTitle, String department, String jobDescription, String primarySkills,
			String mandatorySkills, String gthSkills, String experience, String recruiterId, String grade,
			String location, String trStatusId, String deadline) {
		super();
		this.trId = trId;
		this.jobTitle = jobTitle;
		this.jobDescription = jobDescription;
		this.primarySkills = primarySkills;
		this.experience = experience;
		this.grade = grade;
		this.location = location;
	}

	public TR(String jobTitle, String department, String jobDescription, String primarySkills, String mandatorySkills,
			String gthSkills, String experience, String recruiterId, String grade, String location, String trStatusId,
			String deadline) {
		super();
		this.jobTitle = jobTitle;
		this.jobDescription = jobDescription;
		this.primarySkills = primarySkills;
		this.experience = experience;
		this.grade = grade;
		this.location = location;
	}

	public String getTrId() {
		return trId;
	}

	public void setTrId(String trId) {
		this.trId = trId;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getPrimarySkills() {
		return primarySkills;
	}

	public void setPrimarySkills(String primarySkills) {
		this.primarySkills = primarySkills;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	@Override
	public String toString() {
		return "TR [trId=" + trId + ", jobTitle=" + jobTitle + ", organizationGroup=" + organizationGroup
				+ ", jobDescription=" + jobDescription + ", primarySkills=" + primarySkills + ", experience=" 
				+ experience + ", grade=" + grade + ", location=" + location + ", practice=" + practice 
				+ ", accountName=" + accountName + ", projectName=" + projectName + ", firstLevelTechPanel=" 
				+ firstLevelTechPanel + ", secondLevelTechPanel=" + secondLevelTechPanel + "]";
	}

	public String getPractice() {
		return practice;
	}

	public void setPractice(String practice) {
		this.practice = practice;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getFirstLevelTechPanel() {
		return firstLevelTechPanel;
	}

	public void setFirstLevelTechPanel(String firstLevelTechPanel) {
		this.firstLevelTechPanel = firstLevelTechPanel;
	}

	public String getSecondLevelTechPanel() {
		return secondLevelTechPanel;
	}

	public void setSecondLevelTechPanel(String secondLevelTechPanel) {
		this.secondLevelTechPanel = secondLevelTechPanel;
	}

	public String getOrganizationGroup() {
		return organizationGroup;
	}

	public void setOrganizationGroup(String organization_group) {
		this.organizationGroup = organization_group;
	}

	public String getApplicationsCount() {
		return applicationsCount;
	}

	public void setApplicationsCount(String applicationsCount) {
		this.applicationsCount = applicationsCount;
	}

	public boolean isCanApply() {
		return canApply;
	}

	public void setCanApply(boolean canApply) {
		this.canApply = canApply;
	}

	public String getAssignmentStartDate() {
		return assignmentStartDate;
	}

	public void setAssignmentStartDate(String assignmentStartDate) {
		this.assignmentStartDate = assignmentStartDate;
	}

	public String getTechPanelEmail() {
		return techPanelEmail;
	}

	public void setTechPanelEmail(String techPanelEmail) {
		this.techPanelEmail = techPanelEmail;
	}

	public String getSecondtechPanelEmail() {
		return secondtechPanelEmail;
	}

	public void setSecondtechPanelEmail(String secondtechPanelEmail) {
		this.secondtechPanelEmail = secondtechPanelEmail;
	}
	
	
}
