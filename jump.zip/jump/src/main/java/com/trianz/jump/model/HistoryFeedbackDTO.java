package com.trianz.jump.model;

public class HistoryFeedbackDTO {
	
	private String feedback;
	private String lastUpdate;
	private double rating;
	
	public HistoryFeedbackDTO(String feedback, String lastUpdate, double rating) {
		super();
		this.feedback = feedback;
		this.lastUpdate = lastUpdate;
		this.setRating(rating);
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}
	
}
