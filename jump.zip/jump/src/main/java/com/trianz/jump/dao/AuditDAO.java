package com.trianz.jump.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

@Service
public class AuditDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public void saveRequestsInfo(String userInfo, String reqMethod, String url, String reqBody) {
		String sql = "INSERT INTO AUDIT(USER_EMAIL, HTTP_METHOD, API_ENDPOINT, REQ_PAYLOAD)"
				   + " VALUES(?,?,?, LEFT(?, COL_LENGTH('AUDIT', 'REQ_PAYLOAD')))";
		jdbcTemplate.update(sql, userInfo, reqMethod, url, reqBody);
	}
}
