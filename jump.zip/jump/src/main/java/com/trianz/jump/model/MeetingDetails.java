package com.trianz.jump.model;

import java.time.LocalDateTime;
import java.util.List;

public class MeetingDetails {

	private String trId;
	private String email;
	private List<String> interviewerMail;
	private int level;
	private String meetingId;
	private LocalDateTime start_date;
	private LocalDateTime end_date;
	private boolean reschedule;
	
	

	public MeetingDetails() {
		super();
	}

	public String getTrId() {
		return trId;
	}

	public void setTrId(String trId) {
		this.trId = trId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getMeetingId() {
		return meetingId;
	}

	public void setMeetingId(String meetingId) {
		this.meetingId = meetingId;
	}

	public LocalDateTime getStart_date() {
		return start_date;
	}

	public void setStart_date(LocalDateTime start_date) {
		this.start_date = start_date;
	}

	public LocalDateTime getEnd_date() {
		return end_date;
	}

	public void setEnd_date(LocalDateTime end_date) {
		this.end_date = end_date;
	}

	public List<String> getInterviewerMail() {
		return interviewerMail;
	}

	public void setInterviewerMail(List<String> interviewerMail) {
		this.interviewerMail = interviewerMail;
	}

	public boolean isReschedule() {
		return reschedule;
	}

	public void setReschedule(boolean reschedule) {
		this.reschedule = reschedule;
	}

	
}
