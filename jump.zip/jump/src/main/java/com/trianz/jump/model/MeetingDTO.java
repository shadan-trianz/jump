package com.trianz.jump.model;

import java.util.List;

public class MeetingDTO {
	
	private String meetingId;
	private List<String> panelEmails;
	private String lastUpdate;
	
	
	public MeetingDTO(String meetingId, String lastUpdate, List<String> panelEmails) {
		super();
		this.meetingId = meetingId;
		this.lastUpdate = lastUpdate;
		this.panelEmails = panelEmails;
	}


	public MeetingDTO() {
		// TODO Auto-generated constructor stub
	}


	public String getMeetingId() {
		return meetingId;
	}


	public void setMeetingId(String meetingId) {
		this.meetingId = meetingId;
	}


	public String getLastUpdate() {
		return lastUpdate;
	}


	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}


	public List<String> getPanelEmails() {
		return panelEmails;
	}


	public void setPanelEmails(List<String> panelEmails) {
		this.panelEmails = panelEmails;
	}
}
