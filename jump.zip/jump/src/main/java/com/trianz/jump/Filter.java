package com.trianz.jump;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextImpl;
import org.springframework.stereotype.Component;

import com.trianz.jump.dao.AuditDAO;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Component
public class Filter implements jakarta.servlet.Filter {

	@Autowired
	private AuditDAO auditService;
	

	@SuppressWarnings("unchecked")
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpSession session = request.getSession(false);
		HttpServletResponse response = (HttpServletResponse) res;
		response.setHeader(JumpConstatnts.NAME, JumpConstatnts.VALUE);

		boolean isHR = false;
		boolean isRecruiter = false;
		NamedOidcUser userInfo = null;
		Map<String, Object> userInfoMap = new HashMap<>();
		if (session != null) {
			SecurityContextImpl sci = (SecurityContextImpl) session.getAttribute(JumpConstatnts.SECURITY_CONTEXT);
			userInfo = (NamedOidcUser) sci.getAuthentication().getPrincipal();

			userInfoMap = userInfo.getAttributes();
			String uri = request.getRequestURI();

			if (userInfoMap != null && !uri.isEmpty()) {

				// Logs the request details for audit.
				req = (ServletRequest) processRequest(request, userInfo);
				
				
				// Check for HR role
				isHR = userInfoMap.entrySet().stream().filter(entry -> entry.getKey().contains(JumpConstatnts.ROLES))
						.map(entry -> (List<String>) entry.getValue()).flatMap(List::stream)
						.anyMatch(role -> role.toLowerCase().contains("hr"));
				
				// Check for Recruiter role
	            isRecruiter = userInfoMap.entrySet().stream()
	                    .filter(entry -> entry.getKey().contains(JumpConstatnts.ROLES))
	                    .map(entry -> (List<String>) entry.getValue())
	                    .flatMap(List::stream)
	                    .anyMatch(role -> role.toLowerCase().contains("recruiter"));
	            
	         // Allow access based on roles
	            if (isRecruiter || (isHR && (uri.equals("/jump/tr") || uri.equals("/jump/feedback"))) || 
	                (isHR && isRecruiter)) {
	                chain.doFilter(req, res); // Allow access
	                return; // Prevent further processing
	            }

	            // Block the request for unauthorized access
	            if (uri.startsWith("/jump/recruiter") && !isRecruiter) {
	                response.sendError(HttpServletResponse.SC_FORBIDDEN, "You are not authorized to access this resource");
	                return; // Prevent further processing
	            }
				
			}
		}
		chain.doFilter(req, res);

	}


	private HttpServletRequest processRequest(HttpServletRequest request, NamedOidcUser userInfo)
			throws IOException, ServletException {

		String uri = request.getRequestURI();
		String reqBody = null;
		String reqMethod = request.getMethod();

		if (reqMethod.equals(JumpConstatnts.GET) || uri.contains(JumpConstatnts.PROFILE)) {
			if (request.getQueryString() != null)
				uri += "?" + request.getQueryString();

		} else {
			CustomHttpServletRequestWrapper crequest = new CustomHttpServletRequestWrapper(request);
			StringBuilder sb = new StringBuilder();
			BufferedReader reader = new BufferedReader(new InputStreamReader(crequest.getInputStream()));
			String line;
			while ((line = reader.readLine()) != null) {
				sb.append(line);
			}
			reqBody = sb.toString();
			request = (HttpServletRequest) crequest;

		}
		String userEmail = userInfo.getPreferredUsername().toLowerCase();
		auditService.saveRequestsInfo(userEmail, reqMethod, uri, reqBody);
		return request;
	}

}