package com.trianz.jump.dao;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.model.Application;
import com.trianz.jump.model.HistoryNotesDTO;
import com.trianz.jump.model.HistoryStatusDTO;

@Repository
public class RecruiterDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(RecruiterDAO.class);

	private String applicationsTable = "dbo.APPLICATIONS";
	private String statusTable = "dbo.APPLICATION_STATUS_VALUES";
	private static String talentoView = "JUMP.dbo.vw_HRRFDetailJump";

	// Get all the applications of a particular TR_ID
	public List<Application> getApplicationsByTrId(String trId, List<String> roles, String level) {
		log.debug(">>> dao.getApplicationsByTrId()");

		boolean hasHr = roles.stream().anyMatch(role -> role.equalsIgnoreCase("hr"));
		boolean hasRecruiter = roles.stream().anyMatch(role -> role.equalsIgnoreCase("recruiter"));

		String sql = "SELECT TR_ID, EMP_EMAILID, EMP_NAME, PRIMARY_SKILLS, SECONDARY_SKILLS, TOTAL_EXPERIENCE,"
				+ " TRIANZ_EXPERIENCE, LOCATION, APPLICATIONS.APPLICATION_STATUS_ID, APPLICATION_STATUS_NAME, NOTES,"
				+ " MOBILE, FORMAT(APPLICATIONS.CRT_DATE, 'dd-MM-yyyy') AS CRT_DATE FROM " + applicationsTable
				+ " INNER JOIN " + statusTable
				+ " ON APPLICATIONS.APPLICATION_STATUS_ID=APPLICATION_STATUS_VALUES.APPLICATION_STATUS_ID"
				+ " WHERE TR_ID=? ORDER BY APPLICATIONS.CRT_DATE";

		log.debug("sql:" + sql);

		try {
			List<Application> applications = jdbcTemplate.query(sql, (rs, row) -> {
				Application cur = new Application();

				String statusId = rs.getString("APPLICATION_STATUS_ID");
				int sid = Integer.parseInt(statusId);

				cur.setTrId(rs.getString("TR_ID"));
				cur.setPrimarySkills(rs.getString("PRIMARY_SKILLS"));
				cur.setSecondarySkills(rs.getString("SECONDARY_SKILLS"));
				cur.setTotalExperience(rs.getString("TOTAL_EXPERIENCE"));
				cur.setTrianzExperience(rs.getString("TRIANZ_EXPERIENCE"));
				cur.setLocation(rs.getString("LOCATION"));
				cur.setStatusId(statusId);
				cur.setStatusName(rs.getString("APPLICATION_STATUS_NAME"));
				cur.setNotes(rs.getString("NOTES"));
				cur.setAppliedDate(rs.getString("CRT_DATE"));
				cur.setMobile(rs.getString("MOBILE"));
				cur.setEmail(rs.getString("EMP_EMAILID"));
				cur.setEmpName(rs.getString("EMP_NAME"));
				if (hasRecruiter)					
					cur.setLevel("recruiter");				
				else if (hasHr && (sid >= 90 && sid < 210)) {
					if (level != null && !level.isEmpty()) 
						cur.setLevel(level + ", hr");						
					else
						cur.setLevel("hr");
				} else
					cur.setLevel(level);
				
				if(!hasHr && !hasRecruiter && level.equals("trowner")) {				
					cur.setMobile(null);
					cur.setEmail(null);
					cur.setEmpName(null);
				}

				return cur;
			}, trId);

			log.debug("<<< dao.getApplicationsByTrId()");
			return applications;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch applications for this TR_ID");
		}
	}

	// Updates the application status
	public boolean updateApplicationStatus(String recruiterName, Application application) {
		log.debug(">>> dao.updateApplicationStatus()");

		String sql = "UPDATE " + applicationsTable + " SET APPLICATION_STATUS_ID=?, UPDATED_BY=?"
				+ " WHERE TR_ID=? AND EMP_EMAILID=?";
		log.debug("sql:" + sql);

		try {
			int res = jdbcTemplate.update(sql, application.getStatusId(), recruiterName, application.getTrId(),
					application.getEmail());

			log.debug("<<< dao.updateApplicationStatus()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to update the application status!");
		}
	}

	// Updates the application notes
	public boolean updateApplicationNotes(String recruiterName, Application application) {
		log.debug(">>> dao.updateApplicationNotes()");

		String sql = "UPDATE " + applicationsTable + " SET NOTES=?, UPDATED_BY=? WHERE TR_ID=? AND EMP_EMAILID=?";
		log.debug("sql:" + sql);

		try {
			int res = jdbcTemplate.update(sql, application.getNotes(), recruiterName, application.getTrId(),
					application.getEmail());

			log.debug("<<< dao.updateApplicationNotes()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to update the application notes!");
		}
	}

	// Fetches the status ids with its values for an application
	public List<Map<String, Object>> getAppStatusList() {
		log.debug(">>> dao.getAppStatusList()");

		String sql = "SELECT application_status_id, application_status_name FROM " + statusTable
				+ " WHERE application_status_id not in (20, 70, 80, 110, 140, 210)";
		log.debug("sql:" + sql);

		try {
			List<Map<String, Object>> statusList = jdbcTemplate.queryForList(sql);

			log.debug("<<< dao.getAppStatusList()");
			return statusList;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch status list.");
		}
	}

	// Fetches the history of status-updates of an application
	public List<HistoryStatusDTO> getStatusHistory(String trId, String email) {
		log.debug(">>> dao.getStatusHistory()");

		String sql = "SELECT APPLICATIONS_STATUS_HIST.application_status_id, application_status_name,"
				+ " format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
				+ " FROM APPLICATIONS_STATUS_HIST left join APPLICATION_STATUS_VALUES"
				+ " ON APPLICATIONS_STATUS_HIST.APPLICATION_STATUS_ID=APPLICATION_STATUS_VALUES.APPLICATION_STATUS_ID"
				+ " WHERE TR_ID= ? AND EMP_EMAILID= ? ORDER BY LST_UPD_DATE DESC";
		try {
			List<HistoryStatusDTO> res = jdbcTemplate.query(sql, (rs, row) -> {

				HistoryStatusDTO cur = new HistoryStatusDTO(rs.getString("application_status_id"),
						rs.getString("application_status_name"), rs.getString("last_update"));
				return cur;

			}, trId, email);

			log.debug("<<< dao.getStatusHistory()");
			return res;
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch application status.");
		}
	}

	// Fetches the history of notes updates of an application
	public List<HistoryNotesDTO> getNotesHistory(String trId, String email) {
		log.debug(">>> dao.getNotesHistory()");

		String sql = "SELECT notes, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
				+ " FROM APPLICATIONS_NOTES_HIST" + " WHERE TR_ID = ? and EMP_EMAILID = ? ORDER BY LST_UPD_DATE DESC";
		try {
			List<HistoryNotesDTO> res = jdbcTemplate.query(sql, (rs, row) -> {

				HistoryNotesDTO cur = new HistoryNotesDTO(rs.getString("notes"), rs.getString("last_update"));
				return cur;

			}, trId, email);

			log.debug("<<< dao.getNotesHistory()");
			return res;
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch application status.");
		}
	}

	// Retrieves status name based on status id from APPLICATION_STATUS_VALUES table
	public String getStatusName(int id) {

		log.debug(">>> dao.getStatusName()");

		String sql = "SELECT APPLICATION_STATUS_NAME FROM " + statusTable + " WHERE APPLICATION_STATUS_ID =  ?";
		log.debug("sql:" + sql);

		try {
			String name = jdbcTemplate.queryForObject(sql, String.class, id);
			log.debug("<<< dao.getStatusName()");

			return name;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Couldn't find status name for " + id);
		}

	}

	public List<Application> getApplicationsByTrIdAndEmail(String trId, String email) {
		log.debug(">>> dao.getApplicationsByTrIdAndEmail()");
		log.debug(trId + " " + email);
		String sql = "SELECT * FROM " + applicationsTable + " WHERE TR_ID=? AND EMP_EMAILID=?";
		try {
			List<Application> applications = jdbcTemplate.query(sql, (rs, row) -> {
				Application cur = new Application();
				cur.setTrId(rs.getString("TR_ID"));
				cur.setPrimarySkills(rs.getString("PRIMARY_SKILLS"));
				cur.setSecondarySkills(rs.getString("SECONDARY_SKILLS"));
				cur.setTotalExperience(rs.getString("TOTAL_EXPERIENCE"));
				cur.setTrianzExperience(rs.getString("TRIANZ_EXPERIENCE"));
				cur.setLocation(rs.getString("LOCATION"));
				cur.setStatusId(rs.getString("APPLICATION_STATUS_ID"));
				cur.setNotes(rs.getString("NOTES"));
				cur.setAppliedDate(rs.getString("CRT_DATE"));
				cur.setMobile(rs.getString("MOBILE"));
				cur.setEmail(rs.getString("EMP_EMAILID"));
				cur.setEmpName(rs.getString("EMP_NAME"));

				return cur;
			}, trId, email);

			return applications;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch applications for this TR_ID");
		}
	}

	public List<Map<String, Object>> exportDashboard(List<String> trs) {
		log.debug("trs: " + trs.toString());
		log.debug(">>> dao.exportDashboard()");
		String sql = "SELECT TR_ID, EMP_EMAILID, EMP_NAME, MOBILE, FORMAT(APPLICATIONS.CRT_DATE, 'dd-MM-yyyy') AS APPLIED_DATE,"
				+ " PRIMARY_SKILLS, SECONDARY_SKILLS, LOCATION, TOTAL_EXPERIENCE, TRIANZ_EXPERIENCE,"
				+ " APPLICATION_STATUS_NAME AS APPLICATION_STATUS, RoleRequired as POSITION, CSKILL as TR_PRIMARY_SKILLS,"
				+ " GRADE, AccountName AS ACCOUNT_NAME, ProjectName as PROJECT_NAME, PRACTICE,"
				+ " TECHPANELEmail as TECH_PANEL_1, SECONDTECHPANELEmail as TECH_PANEL_2, SubmittedBy as TR_OWNER"
				+ " FROM " + applicationsTable
				+ " JOIN " + statusTable + " ON " + applicationsTable + ".APPLICATION_STATUS_ID=" + statusTable
				+ ".APPLICATION_STATUS_ID" + " JOIN " + talentoView + " ON TR_ID=HRRFNUMBER" + " WHERE TR_ID IN (:trs)";

		MapSqlParameterSource parameters = new MapSqlParameterSource();
		parameters.addValue("trs", trs);

		try {
			NamedParameterJdbcTemplate namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(jdbcTemplate);

			return namedParameterJdbcTemplate.queryForList(sql, parameters);
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch applications for this TR_ID");
		}
	}

}
