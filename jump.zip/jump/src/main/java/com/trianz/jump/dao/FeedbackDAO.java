package com.trianz.jump.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.model.Feedback;
import com.trianz.jump.model.HistoryFeedbackDTO;
import com.trianz.jump.model.HistoryFeedbackRecruiterDTO;

@Repository
public class FeedbackDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private String feedbackTable = "dbo.APPLICATIONS";

	Logger log = LoggerFactory.getLogger(FeedbackDAO.class);

	public boolean updateFeedbackStatus(String interviewerName, Feedback feedback) {
		log.debug(">>> dao.updateFeedbackStatus()");
		String sql = "";
		String level = feedback.getLevel();
		
		switch (level) {
		case JumpConstatnts.FIRST:
			sql = "UPDATE " + feedbackTable
					+ " SET FIRST_LEVEL_FEEDBACK=?, FIRST_LEVEL_RATING=?, FIRST_LEVEL_UPDATED_BY=?, FIRST_LEVEL_LST_UPD_DATE=?,"
					+ " APPLICATION_STATUS_ID=? WHERE TR_ID=? AND EMP_EMAILID=?";
			break;
		case JumpConstatnts.SECOND:
			sql = "UPDATE " + feedbackTable
					+ " SET SECOND_LEVEL_FEEDBACK=?, SECOND_LEVEL_RATING=?, SECOND_LEVEL_UPDATED_BY=?, SECOND_LEVEL_LST_UPD_DATE=?,"
					+ " APPLICATION_STATUS_ID=? WHERE TR_ID=? AND EMP_EMAILID=?";
			break;
		case JumpConstatnts.HR:
			sql = "UPDATE " + feedbackTable
					+ " SET HR_FEEDBACK=?, HR_RATING=?, HR_LEVEL_UPDATED_BY=?, HR_LEVEL_LST_UPD_DATE=?,"
					+ " APPLICATION_STATUS_ID=? WHERE TR_ID=? AND EMP_EMAILID=?";
			break;
		case JumpConstatnts.CLIENT:
			sql = "UPDATE " + feedbackTable
					+ " SET CLIENT_FEEDBACK=?, CLIENT_RATING=?, CLIENT_LEVEL_UPDATED_BY=?, CLIENT_LEVEL_LST_UPD_DATE=?,"
					+ " APPLICATION_STATUS_ID=? WHERE TR_ID=? AND EMP_EMAILID=?";
			break;
		}

		log.debug("sql:" + sql);

		try {
			int res = jdbcTemplate.update(sql, feedback.getFeedback(), feedback.getRating(), interviewerName,
					getCurrentDateTime(), getApplicationStatusId(feedback.getRating(), level), feedback.getTrId(), feedback.getEmail());

			log.debug("<<< dao.updateFeedbackStatus()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to update the feedback status!");
		}

	}

	// Fetches the history of feedback
	@SuppressWarnings("deprecation")
	public List<HistoryFeedbackDTO> getFeedbackHistory(String trId, String email, String name, String level) {
		log.debug(">>> dao.getFeedbackHistory()");
		String sql = "";
		List<String> emails_list;
		List<HistoryFeedbackDTO> res;

		String emails_sql = "SELECT UPDATED_BY FROM FEEDBACK_HIST WHERE TR_ID = ? and EMP_EMAILID = ?";

		try {
			emails_list = jdbcTemplate.queryForList(emails_sql, new Object[] { trId, email }, String.class);

		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch interviewer emails");
		}

		if (emails_list.contains(name)) {

			switch (level) {
			case JumpConstatnts.FIRST:
				sql = "SELECT feedback, rating, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
						+ " FROM FEEDBACK_HIST"
						+ " WHERE TR_ID = ? and EMP_EMAILID = ? and LEVEL = 'first' ORDER BY LST_UPD_DATE DESC";
				break;
			case JumpConstatnts.SECOND:
				sql = "SELECT feedback, rating, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
						+ " FROM FEEDBACK_HIST"
						+ " WHERE TR_ID = ? and EMP_EMAILID = ? and LEVEL IN ('first', 'second') ORDER BY LST_UPD_DATE DESC";
				break;
			case JumpConstatnts.HR:
				sql = "SELECT feedback, rating, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
						+ " FROM FEEDBACK_HIST"
						+ " WHERE TR_ID = ? and EMP_EMAILID = ? and LEVEL IN ('first', 'second', 'hr') ORDER BY LST_UPD_DATE DESC";
				break;
			case JumpConstatnts.CLIENT:
				sql = "SELECT feedback, rating, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
						+ " FROM FEEDBACK_HIST"
						+ " WHERE TR_ID = ? and EMP_EMAILID = ? and LEVEL = 'client' ORDER BY LST_UPD_DATE DESC";
				break;

			}
		}

		log.debug("SQL= " + sql);
		try {
			res = jdbcTemplate.query(sql, (rs, row) -> {

				HistoryFeedbackDTO cur = new HistoryFeedbackDTO(rs.getString("feedback"), rs.getString("last_update"),
						rs.getDouble("rating"));
				return cur;

			}, trId, email);

			log.debug("<<< dao.getFeedbackHistory()()");
			return res;

		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch feedback from history.");
		}

	}

	// Fetches the history of feedback for Recruiter
	public List<HistoryFeedbackRecruiterDTO> getFeedbackHistoryRecruiter(String trId, String email, String level) {
		log.debug(">>> dao.getFeedbackHistoryRecruiter()");
		String sql = "";

		List<HistoryFeedbackRecruiterDTO> resp;

		switch (level) {
		case JumpConstatnts.FIRST:
			sql = "SELECT FIRST_LEVEL_FEEDBACK AS feedback, FIRST_LEVEL_UPDATED_BY AS updatedBy, FIRST_LEVEL_RATING AS rating, format(FIRST_LEVEL_LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
					+ " FROM " + feedbackTable + " WHERE TR_ID = ? and EMP_EMAILID = ?";
			break;
		case JumpConstatnts.SECOND:
			sql = "SELECT SECOND_LEVEL_FEEDBACK AS feedback, SECOND_LEVEL_UPDATED_BY AS updatedBy, SECOND_LEVEL_RATING AS rating, format(SECOND_LEVEL_LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
					+ " FROM " + feedbackTable + " WHERE TR_ID = ? and EMP_EMAILID = ?";
			break;
		case JumpConstatnts.HR:
			sql = "SELECT HR_FEEDBACK AS feedback, HR_LEVEL_UPDATED_BY AS updatedBy, HR_RATING AS rating, format(HR_LEVEL_LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
					+ " FROM " + feedbackTable + " WHERE TR_ID = ? and EMP_EMAILID = ?";
			break;
		case JumpConstatnts.CLIENT:
			sql = "SELECT CLIENT_FEEDBACK AS feedback, CLIENT_LEVEL_UPDATED_BY AS updatedBy, CLIENT_RATING AS rating, format(CLIENT_LEVEL_LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS last_update"
					+ " FROM " + feedbackTable + " WHERE TR_ID = ? and EMP_EMAILID = ?";
			break;
		}

		log.debug("SQL= " + sql);
		try {
			resp = jdbcTemplate.query(sql, (rs, row) -> {

				HistoryFeedbackRecruiterDTO cur = new HistoryFeedbackRecruiterDTO(rs.getString("feedback"),
						rs.getString("updatedBy"), rs.getDouble("rating"), rs.getString("last_update"));
				return cur;

			}, trId, email);

			log.debug("<<< dao.getFeedbackHistoryRecruiter()()");
			return resp;

		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch feedback from history.");
		}

	}

	private String getCurrentDateTime() {
		LocalDateTime currentTimestamp = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return currentTimestamp.format(formatter);
	}
	
	private int getApplicationStatusId(double rating, String level) {
		int statusId =0;
		if(rating>=3 && level.equals(JumpConstatnts.FIRST)) {
			statusId = 30;
		}else if(rating<3 && level.equals(JumpConstatnts.FIRST)) {
			statusId = 40;
		}else if(rating>=3 && level.equals(JumpConstatnts.SECOND)) {
			statusId = 90;
		}else if(rating<3 && level.equals(JumpConstatnts.SECOND)) {
			statusId = 100;
		}else if(rating>=3 && level.equals(JumpConstatnts.HR)) {
			statusId = 120;
		}else if(rating<3 && level.equals(JumpConstatnts.HR)) {
			statusId = 130;
		}else if(rating>=3 && level.equals(JumpConstatnts.CLIENT)) {
			statusId = 150;
		}else if(rating<3 && level.equals(JumpConstatnts.CLIENT)) {
			statusId = 160;
		}
		
		return statusId;
	}

}
