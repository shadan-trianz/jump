package com.trianz.jump.model;

public class FulfilledCandidate {

	private String trId;
	private String email;
	private String position;
	
	public String getTrId() {
		return trId;
	}
	public void setTrId(String trId) {
		this.trId = trId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	@Override
	public String toString() {
		return "FulfilledCandidate [trId=" + trId + ", email=" + email + ", position=" + position + "]";
	}
	
}
