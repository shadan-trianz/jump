package com.trianz.jump;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserRequest;
import org.springframework.security.oauth2.client.oidc.userinfo.OidcUserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.savedrequest.HttpSessionRequestCache;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
public class JwtAuthorizationConfiguration {

	@SuppressWarnings("removal")
	@Bean
	SecurityFilterChain customJwtSecurityChain(HttpSecurity http) throws Exception {
		HttpSessionRequestCache requestCache = new HttpSessionRequestCache();
		requestCache.setMatchingRequestParameterName(null);

		return http.authorizeHttpRequests(r -> r.anyRequest().authenticated()).csrf().disable()

				.cors((cors) -> cors.configurationSource(corsConfigurationSource()))

				.oauth2Login(oauth2 -> oauth2.userInfoEndpoint(ep -> ep.oidcUserService(customOidcUserService())))
				.requestCache((cache) -> cache.requestCache(requestCache))// .sessionManagement(session ->
																			// session.invalidSessionUrl("/index.html"))
				.build();
	}

	private OAuth2UserService<OidcUserRequest, OidcUser> customOidcUserService() {
		final OidcUserService delegate = new OidcUserService();

		return userRequest -> {
			OidcUser oidcUser = delegate.loadUser(userRequest);
			// Enrich standard authorities with groups
			Set<GrantedAuthority> mappedAuthorities = new HashSet<>();
			mappedAuthorities.addAll(oidcUser.getAuthorities());

			oidcUser = new NamedOidcUser(mappedAuthorities, oidcUser.getIdToken(), oidcUser.getUserInfo(),
					oidcUser.getName());

			return oidcUser;
		};
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		// this securityHostSet can be from mysql query or YML config

		List<String> securityHostList = new ArrayList<>();
		securityHostList.add("http://localhost:[*]");
		securityHostList.add("http://127.0.0.1:[*]");

		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOriginPatterns(securityHostList);
		/**
		 * The allowed request header is very important, if you don't know what's in the
		 * * other party's request header, just let everything go, if you don't
		 * understand, * let it go or don't configure it!
		 */
		configuration.setAllowedHeaders(List.of("*"));
		configuration.setAllowedMethods(Arrays.asList("GET", "POST", "DELETE", "PUT", "HEAD", "POST", "OPTIONS"));
		configuration.setMaxAge(3600L);
		configuration.setAllowCredentials(true);
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);
		return source;
	}
}