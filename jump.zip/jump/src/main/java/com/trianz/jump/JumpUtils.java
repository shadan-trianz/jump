package com.trianz.jump;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;

public class JumpUtils {

	static Logger log = LoggerFactory.getLogger(JumpUtils.class);

	// To fetch the details of the logged in user
	public static Map<String, String> getUserDetails(Authentication auth) {
		log.debug(">>> JumpUtils.getUserDetails()");

		Map<String, String> userDetails = new HashMap<>();
		/*
		 * if (auth == null) { userDetails.put("email",
		 * "venkataramakrishna.v@trianz.com"); userDetails.put("name",
		 * "Venkata Vasamsetti"); return userDetails; }
		 */

		OidcUser user = (OidcUser) auth.getPrincipal();
		String email = user.getPreferredUsername().toLowerCase();
		String name = user.getName();

		// Remove (Trianz) from the user's name
		if (name.endsWith(JumpConstatnts.TRIANZ)) {
			name = name.substring(0, name.indexOf(JumpConstatnts.TRIANZ));
		}

		userDetails.put("email", email);
		userDetails.put("name", name);

		log.debug("<<< JumpUtils.getUserDetails()");
		return userDetails;
	}

	@SuppressWarnings("unchecked")
	public static List<String> getLoggedInUserRoles(Authentication authentication) {
		log.debug(">>> JumpUtils.getLoggedInUserRoles()");
		List<String> roles = new ArrayList<String>();

		/*
		 * if(authentication == null) { roles.add("HR");
		 * 
		 * return roles; }
		 */

		OidcUser user = (OidcUser) authentication.getPrincipal();
		Map<String, Object> userAttr = user.getAttributes();
		if (userAttr.containsKey(JumpConstatnts.ROLES)) {
			roles = (List<String>) userAttr.get(JumpConstatnts.ROLES);
		}
		log.debug("<<< JumpUtils.getLoggedInUserRoles()");
		return roles;
	}

	// To fetch the details of the logged in user
	@SuppressWarnings("serial")
	public static Map<String, Object> getUserDetailsWithRoles(Authentication auth) {
		log.debug(">>> service.getUserDetails()");

		
		/*
		 * if(auth == null) { Map<String, String> userDetails = new HashMap<>();
		 * userDetails.put("email", "venkataramakrishna.v@trianz.com");
		 * userDetails.put("name", "Venkata Vasamsetti");
		 * 
		 * Map<String, Object> userInfo = new HashMap<>(); userInfo.put("roles", new
		 * ArrayList<String>() {{add("HR");}}); userInfo.put("userDetails",
		 * userDetails); userInfo.put("message", "success");
		 * 
		 * return userInfo; }
		 */ 

		OidcUser user = (OidcUser) auth.getPrincipal();
		String email = user.getPreferredUsername().toLowerCase();
		String name = user.getName();

		// Remove (Trianz) from the user's name
		if (name.endsWith(JumpConstatnts.TRIANZ)) {
			name = name.substring(0, name.indexOf(JumpConstatnts.TRIANZ));
		}

		Map<String, Object> userDetails = new HashMap<>();
		userDetails.put("email", email);
		userDetails.put("name", name);

		Map<String, Object> userInfo = new HashMap<>();
		userInfo.put("roles", user.getAttribute("roles"));
		userInfo.put("userDetails", userDetails);
		userInfo.put("message", "success");

		log.debug("<<< service.getUserDetails()");
		return userInfo;
	}

}
