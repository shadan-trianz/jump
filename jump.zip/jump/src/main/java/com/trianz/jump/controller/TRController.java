package com.trianz.jump.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trianz.jump.JumpUtils;
import com.trianz.jump.services.JumpService;

@RestController
@RequestMapping("jump/tr")
public class TRController {
	
	@Autowired
	private JumpService service;
	
	Logger log = LoggerFactory.getLogger(TRController.class);

	// Fetches active TRs for employees
	@GetMapping("active")
	public ResponseEntity<Map<String, Object>> getActiveTRs(Authentication auth, 
			@RequestParam(required = false, defaultValue = "1") Integer page,
			@RequestParam(required = false, defaultValue = "trId") String sortBy,
			@RequestParam(required = false, defaultValue = "desc") String sortDir,
			@RequestParam(required = false) String search,
			@RequestParam(required = false) String key)
	{
		log.debug(">>> getActiveTRs()");
		try {
			String email = getUserEmail(auth);
			Map<String, Object> trList = service.getActiveTRs(email, page, sortBy, sortDir, search, key);
			
			log.debug("<<< getActiveTRs()");
			return new ResponseEntity<>(trList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> err = new HashMap<>();
			err.put("message", e.getMessage());
			return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
		}
	}
	
	// Fetches TRs for recruiter dashboard 
	@GetMapping
	public ResponseEntity<Map<String, Object>> getFilteredTRs(Authentication auth,
			@RequestParam(required = false, defaultValue = "1") Integer page,
			@RequestParam(required = false, defaultValue = "open") String trflag,
			@RequestParam(required = false, defaultValue = "trId") String sortBy,
			@RequestParam(required = false, defaultValue = "desc") String sortDir,
			@RequestParam(required = false) String search,
			@RequestParam(required = false) String key)
	{
		log.debug(">>> getFilteredTRs()");
		try {
			String email = getUserEmail(auth);
			List<String> roles = JumpUtils.getLoggedInUserRoles(auth);
			Map<String, Object> trList = service.getFilteredTRs(email, page, trflag, sortBy, sortDir, search, key, roles);
			
			log.debug("<<< getFilteredTRs()");
			return new ResponseEntity<>(trList, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> err = new HashMap<>();
			err.put("message", e.getMessage());
			return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
		}
	}
	
	// Fetches details of a particular TR
	@GetMapping("{id}")
	public ResponseEntity<Map<String, Object>> getTRById(@PathVariable String id) {
		log.debug(">>> getTRById()");
		try {
			Map<String, Object> res = service.getTRById(id);
			
			log.debug("<<< getTRById()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> err = new HashMap<>();
			err.put("message", e.getMessage());
			return new ResponseEntity<>(err, HttpStatus.OK);
		}
	}
	
	// To get the email of the logged in user
	private String getUserEmail(Authentication auth) {
		log.debug(">>> service.getUserEmail()");
		//if(auth == null) return "shadan.asad@trianz.com";
		OidcUser userDetails = (OidcUser) auth.getPrincipal();
        String email = userDetails.getPreferredUsername().toLowerCase();
        
        log.debug("<<< service.getUserEmail()");
        return email;
	}
}
