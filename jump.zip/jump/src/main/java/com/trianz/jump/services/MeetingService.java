package com.trianz.jump.services;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.microsoft.graph.models.Attendee;
import com.microsoft.graph.models.AttendeeType;
import com.microsoft.graph.models.BodyType;
import com.microsoft.graph.models.DateTimeTimeZone;
import com.microsoft.graph.models.EmailAddress;
import com.microsoft.graph.models.Event;
import com.microsoft.graph.models.ItemBody;
import com.microsoft.graph.models.Location;
import com.microsoft.graph.requests.GraphServiceClient;
import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.dao.MeetingDAO;
import com.trianz.jump.dao.RecruiterDAO;
import com.trianz.jump.dao.TRDAO;
import com.trianz.jump.model.Application;
import com.trianz.jump.model.MeetingDTO;
import com.trianz.jump.model.MeetingDetails;

import okhttp3.Request;

@Service
public class MeetingService {

	@Autowired
	private RecruiterDAO recDao;

	@Autowired
	private TRDAO trDao;

	@Autowired
	private MeetingDAO meetDAO;

	@Autowired
	private EmailService emailService;

	@Autowired
	private Environment environment;

	@Value("${spring.mail.username}")
	private String fromEmail;

	private final SimpleAuthProvider authProvider;

	public MeetingService(SimpleAuthProvider authProvider) {
		this.authProvider = authProvider;
	}

	Logger log = LoggerFactory.getLogger(MeetingService.class);

	public Map<String, Object> getMeeting(String trid, String email, int level) {

		log.debug(">>>getMeeting()");
		Map<String, Object> result = new HashMap<>();
		try {
			MeetingDTO meetingDTO = meetDAO.getMeeting(trid, email, level);
			if (meetingDTO != null) {
				String id = meetingDTO.getMeetingId();
				if (id != null && !id.isEmpty()) {
					result.put("meetingId", id);
					result.put("lastUpdated", meetingDTO.getLastUpdate());			
					result.put("panelEmails", meetingDTO.getPanelEmails());
				}
			} else {
				result.put("meetingId", "No Meeting ID found");
			}
		}catch(Exception e) {
			String panelEmails = meetDAO.getPanelEmailsByTrid(trid, level);
			List<String> finalList = new ArrayList<>();
			if(panelEmails != null && !panelEmails.isEmpty()) {
					for(String mail: Arrays.asList(panelEmails.split(",")))
						finalList.add(mail.trim());
			}
			result.put("panelEmails", finalList);				
		}
		

		log.debug("<<<getMeeting()");
		return result;
	}

	public Map<String, String> removeMeeting(String meetingId) {

		log.debug(">>>removeMeeting()");
		Map<String, String> result = new HashMap<>();

		GraphServiceClient<Request> graphClient = GraphServiceClient.builder().authenticationProvider(authProvider)
				.buildClient();

		Event cancelMeeting = graphClient.users(fromEmail).events(meetingId).buildRequest().get();
		cancelMeeting.body = new ItemBody();
		cancelMeeting.body.content = "This scheduled meeting has been cancelled. We will update you on re-schedule";
		cancelMeeting.body.contentType = BodyType.HTML;
		cancelMeeting.isCancelled = true;

		graphClient.users(fromEmail).events(meetingId).buildRequest().patch(cancelMeeting);

		graphClient.users(fromEmail).events(meetingId).buildRequest().delete();

		String res = meetDAO.removeMeeting(meetingId);
		result.put("result", res);
		log.debug("<<<removeMeeting()");
		return result;

	}

	public Map<String, String> scheduleMeeting(String trid, String toMail, String recruiter,
			List<String> interviewerMail, int level, LocalDateTime st, LocalDateTime et, boolean reschedule) throws Exception {

		log.debug(">>>scheduleMeeting()");

		Map<String, String> resp = new HashMap<>();
		List<String> panelEmailList = new ArrayList<>();

		boolean emailFlag = allEmailsAreTrainz(interviewerMail);
		if(level == 1004) {
			panelEmailList = interviewerMail;
		} else if (emailFlag && (level == 1001 || level == 1002 || level == 1003)) {
			panelEmailList = interviewerMail;			
		} else if (emailFlag == false && (level >= 1001 && level<=1003)) {
			throw new Exception("Panel member's email is empty / incorrect");				
			
		} else {
			throw new Exception(" Incorrect Email / Level");		
		}

		Event newEvent = new Event();
		newEvent.body = new ItemBody();
		newEvent.body.contentType = BodyType.HTML;
		switch (level) {
		case 1001:
			newEvent.subject = JumpConstatnts.DISCUSS_LEVEL1;
			newEvent.body.content = "Level 1 Technical Disscussion is scheduled.";
			break;
		case 1002:
			newEvent.subject = JumpConstatnts.DISCUSS_LEVEL2;
			newEvent.body.content = "Level 2 Technical Disscussion is scheduled.";
			break;
		case 1003:
			newEvent.subject = JumpConstatnts.DISCUSS_HR;
			newEvent.body.content = "HR Disscussion is scheduled.";
			break;
		case 1004:
			newEvent.subject = JumpConstatnts.DISCUSS_CLIENT;
			newEvent.body.content = "Client Disscussion is scheduled.";
			break;
		}

		String name = toMail;
		name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
		name = name.substring(0, 1).toUpperCase() + name.substring(1);

		ZonedDateTime startIST = st.atZone(ZoneId.of("Asia/Kolkata"));
		ZonedDateTime endIST = et.atZone(ZoneId.of("Asia/Kolkata"));

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");

		newEvent.start = new DateTimeTimeZone();
		newEvent.start.dateTime = startIST.format(formatter);
		newEvent.start.timeZone = "Asia/Kolkata";
		newEvent.end = new DateTimeTimeZone();
		newEvent.end.dateTime = endIST.format(formatter);
		newEvent.end.timeZone = "Asia/Kolkata";
		newEvent.location = new Location();
		newEvent.location.displayName = "Microsoft Teams";

		List<Attendee> attendees = new ArrayList<Attendee>();

		Attendee attendee = new Attendee();

		EmailAddress emailAddress = new EmailAddress();
		emailAddress.address = toMail;
		emailAddress.name = name;

		attendee.emailAddress = emailAddress;
		attendee.type = AttendeeType.REQUIRED;

		attendees.add(attendee);

		for (String mail : panelEmailList) {
			attendee = new Attendee();
			emailAddress = new EmailAddress();
			emailAddress.address = mail;

			attendee.emailAddress = emailAddress;
			attendee.type = AttendeeType.REQUIRED;

			attendees.add(attendee);
		}

		newEvent.attendees = attendees;
		newEvent.isOnlineMeeting = true;

		GraphServiceClient<Request> graphClient = GraphServiceClient.builder().authenticationProvider(authProvider)
				.buildClient();

		Event createdMeeting = graphClient.users(fromEmail).events().buildRequest().post(newEvent);

		LocalTime stlt = st.toLocalTime();
		LocalTime etlt = et.toLocalTime();
		DateTimeFormatter formater = DateTimeFormatter.ofPattern("HH.mm");
		String s_t = stlt.format(formater);
		String e_t = etlt.format(formater);
		Duration duration = Duration.between(st, et);
		String scheduleDate = st.toLocalDate().toString();
		String scheduleTime = s_t + " - " + e_t;
		String timeLimit = formatDuration(duration);
		if(timeLimit.equalsIgnoreCase("1H 60M")) {
			timeLimit = "60M";
		}
		String meetingUrl = createdMeeting.onlineMeeting.joinUrl;
		String meetingId = createdMeeting.id;

		resp.put("date", scheduleDate);
		resp.put("time", scheduleTime);
		resp.put("meetingId", meetingId);

		Application application = new Application();
		application.setTrId(trid);
		application.setEmail(toMail);

		Map<String, Object> variables = new HashMap<>();
		variables.put("jobTitle", trDao.getRoleRequired(trid));
		variables.put("name", name);
		variables.put("scheduled_date", scheduleDate);
		variables.put("scheduled_time", scheduleTime);
		variables.put("duration", timeLimit);
		variables.put("virtual_link", meetingUrl);

		MeetingDetails meetingDetails = new MeetingDetails();
		meetingDetails.setTrId(trid);
		meetingDetails.setEmail(toMail);
		meetingDetails.setMeetingId(meetingId);
		meetingDetails.setLevel(level);
		meetingDetails.setReschedule(reschedule);
		meetingDetails.setInterviewerMail(interviewerMail);

		String result = updateStatus_SendEmail(application, recruiter, level, variables, meetingDetails);
		resp.put("message", result);

		log.debug("<<<scheduleMeeting()");
		return resp;
	}

	// Updating the Application table with status_is and sending schedule mail
	private String updateStatus_SendEmail(Application application, String recruiter, int level,
			Map<String, Object> variables, MeetingDetails md) {

		boolean result1 = false;
		boolean result2 = false;		
		String message = "";
		String subject = "";
		String template = "";
		try {
						
			result1 = meetDAO.saveMeeting(md);

			if (getCurrentEnvironment()) {
				subject = "[NON-PROD] ";
			}

			if (level == 1001) {
				subject = subject + JumpConstatnts.INTERVIEWING_TEXT_1 + " [ " + application.getTrId() + " ]";
				template = "schedule1";
				application.setStatusId("20");
			} else if (level == 1002) {
				subject = subject + JumpConstatnts.INTERVIEWING_TEXT_2 + " [ " + application.getTrId() + " ]";
				template = "schedule2";
				application.setStatusId("80");
			} else if (level == 1003) {
				subject = subject + JumpConstatnts.INTERVIEWING_TEXT_HR + " [ " + application.getTrId() + " ]";
				template = "scheduleHR";
				application.setStatusId("110");
			} else if (level == 1004) {
				subject = subject + JumpConstatnts.INTERVIEWING_TEXT_CLIENT + " [ " + application.getTrId() + " ]";
				template = "scheduleClient";
				application.setStatusId("140");
			}
			result2 = recDao.updateApplicationStatus(recruiter, application);
			if (result1 && result2) {
				message = "Meeting & Application status is succeeded!";
			} else {
				message = "Application updation is failed!";
			}
			
			if(!md.isReschedule()) {
				emailService.sendEmail(application.getEmail(), recruiter, subject, template, variables);
			}
			

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}

		return message;

	}

	private boolean getCurrentEnvironment() {
		String[] activeEnv = environment.getActiveProfiles();
		return Stream.of(activeEnv).anyMatch(s -> s.contains(JumpConstatnts.DEV));
	}

	private String formatDuration(Duration duration) {
		StringBuilder result = new StringBuilder();

		long hrs = duration.toHours();
		long mnts = duration.toMinutes();

		if (hrs > 0) {
			result.append(hrs).append("H ");
		}
		if (mnts > 0) {
			result.append(mnts).append("M");
		}
		return result.toString().trim();
	}

	private boolean allEmailsAreTrainz(List<String> emails) {

		if (emails != null && emails.size()>0) {
			return emails.stream().allMatch(email -> email.endsWith("@trianz.com"));
		} else {
			return false;
		}
	}

}
