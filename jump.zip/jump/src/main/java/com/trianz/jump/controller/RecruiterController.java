package com.trianz.jump.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.JumpUtils;
import com.trianz.jump.model.Application;
import com.trianz.jump.services.JumpService;
import com.trianz.jump.services.StorageService;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("jump/recruiter")
public class RecruiterController {

	@Autowired
	private JumpService service;
	
	@Autowired
	private StorageService storageService;

	Logger log = LoggerFactory.getLogger(RecruiterController.class);

	// Get all the applications of a TR_ID
	@SuppressWarnings("unchecked")
	@GetMapping("{trId}")
	public ResponseEntity<Map<String, Object>> getApplicationsByTrId(Authentication auth, @PathVariable String trId) {
		log.debug(">>> getApplicationsByTrId()");
		try {			
			Map<String, Object> userInfo = JumpUtils.getUserDetailsWithRoles(auth);
			Map<String, String> userDetails = (Map<String, String>) userInfo.get("userDetails");
			String email = userDetails.get("email");
			
			List<String> roles = (List<String>) userInfo.get("roles");
			Map<String, Object> res = service.getApplicationsByTrId(trId, roles, email);

			log.debug("<<< getApplicationsByTrId()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("{trId}/{email}")
	public ResponseEntity<Map<String, Object>> getApplicationsByTrIdAndEmail(Authentication auth, @PathVariable String trId, 
			 @PathVariable String email) {
		log.debug(">>> getApplicationsByTrIdAndEmail()");
		try {
			Map<String, Object> res = service.getApplicationsByTrIdAndEmail(trId, email);

			log.debug("<<< getApplicationsByTrId()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
		}
	}

	// Update status/notes of an application
	@PutMapping("update-application")
	public ResponseEntity<Map<String, Object>> updateApplication(Authentication auth,
																 @RequestBody Application application) {
		log.debug(">>> updateApplication()");
		try {
			Map<String, String> recruiter = getUserDetails(auth);
			Map<String, Object> res = service.updateApplication(recruiter.get("name"), recruiter.get("email"), application);

			log.debug("<<< updateApplication()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
		}
	}

	// Get history of application status updates and notes updates
	@GetMapping("history")
	public ResponseEntity<Map<String, Object>> getApplicationHistory(@RequestParam String trId,
																	 @RequestParam String email) {
		log.debug(">>> getApplicationHistory()");
		try {
			Map<String, Object> res = service.getApplicationHistory(trId, email);
			
			log.debug("<<< getApplicationHistory()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}
	}
	
	// To download the profile associated with an applicantion
	@SuppressWarnings("unchecked")
	@GetMapping("/profile/{email}")
	public ResponseEntity<ByteArrayResource> downloadProfile(@PathVariable String email) {
		log.debug(">>> downloadProfile()");
		try {
			ResponseEntity<ByteArrayResource> res = storageService.downloadPrfile(email);
			
			log.debug("<<< downloadProfile()");
			return res;
		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}

	}
	
	@GetMapping("/export")
    public void exportDashboard(HttpServletResponse response, @RequestParam List<String> trs) throws IOException {
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=JumpApplications.xlsx");
        
        XSSFWorkbook workbook = service.exportDashboard(trs);

        try (ServletOutputStream outputStream = response.getOutputStream()) {
            workbook.write(outputStream);
            workbook.close();
        }

    }

	// To fetch the details of the logged in user
	private Map<String, String> getUserDetails(Authentication auth) {
		log.debug(">>> controller.getUserDetails()");
		
//		if(auth == null) 
//		{
//			Map<String, String> userDetails = new HashMap<>();
//			userDetails.put("email", "venkataramakrishna.v@trianz.com");
//			userDetails.put("name", "Venkata Vasamsetti");
//			
//			return userDetails;
//		}
		
		OidcUser user = (OidcUser) auth.getPrincipal();
		String email = user.getPreferredUsername().toLowerCase();
		String name = user.getName();
		
		// Remove (Trianz) from the user's name
		if(name.endsWith(JumpConstatnts.TRIANZ)) {
			name = name.substring(0, name.indexOf(JumpConstatnts.TRIANZ));
		}
		
		Map<String, String> userDetails = new HashMap<>();
		userDetails.put("email", email);
		userDetails.put("name", name);
		
		log.debug("<<< controller.getUserDetails()");
		return userDetails;
	}


}
