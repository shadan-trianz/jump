package com.trianz.jump.model;

public class HistoryNotesDTO {
	private String notes;
	private String lastUpdate;
	
	public HistoryNotesDTO(String notes, String lastUpdate) {
		super();
		this.notes = notes;
		this.lastUpdate = lastUpdate;
	}
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getLastUpdate() {
		return lastUpdate;
	}
	
	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	
}
