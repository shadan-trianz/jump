package com.trianz.jump.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.model.MeetingDTO;
import com.trianz.jump.model.MeetingDetails;

@Repository
public class MeetingDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private NamedParameterJdbcTemplate namedTemplate;
	

	private String meetingTable = "dbo.MEETING_DETAILS";
	
	private static String talentoView = "JUMP.dbo.vw_HRRFDetailJump";

	Logger log = LoggerFactory.getLogger(MeetingDAO.class);

	public boolean saveMeeting(MeetingDetails md) {
		log.debug(">>> dao.saveMeeting()");
		String sql = "INSERT INTO " + meetingTable + " (TR_ID, EMP_EMAILID, LEVEL_ID, "
				+ "MEETING_ID, PANEL_EMAILS) VALUES (?, ?, ?, ?, ?)";
		
		String panelEmails = md.getInterviewerMail().toString();
		panelEmails = panelEmails.substring(1, panelEmails.length()-1);
		

		log.debug("sql:" + sql);

		try {
			int res = jdbcTemplate.update(sql, md.getTrId(), md.getEmail(), md.getLevel(), md.getMeetingId(), panelEmails);

			log.debug("<<< dao.saveMeeting()");
			return res > 0;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to save the meeting details!");
		}
	}

	// Fetches Meeting ID	
	public MeetingDTO getMeeting(String trId, String empEmailId, int levelId) {

		log.debug(">>> dao.getMeeting()");

		String sql = "SELECT MEETING_ID, format(LST_UPD_DATE, 'dd-MM-yyyy HH:mm:ss') AS LST_UPD_DATE, PANEL_EMAILS FROM "
				+ meetingTable + " WHERE TR_ID=:trId AND EMP_EMAILID=:empEmailId AND LEVEL_ID=:levelId";		
		log.debug("SQL:" + sql);

		try {   
				MapSqlParameterSource parameters = new MapSqlParameterSource();
				parameters.addValue("trId", trId);
				parameters.addValue("empEmailId", empEmailId);
				parameters.addValue("levelId", levelId);
				
				MeetingDTO dto = namedTemplate.queryForObject(sql, parameters, new MeetingDTORowMapper());				
				
				return dto;					
			
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch the meeting id!");
		}

	}

	// Fetches Meeting ID
	public String removeMeeting(String meetingId) {

		log.debug(">>> dao.removeMeeting()");

		String sql = "DELETE FROM " + meetingTable + " WHERE MEETING_ID=?";

		try {
			int result = jdbcTemplate.update(sql, meetingId);
			log.debug("<<< dao.removeMeeting()");
			if (result > 0) {
				return "Successfully cancelled the meeting";
			} else {
				return "No Meeting ID Found";
			}

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to delete the meeting!");
		}

	}	
	
	public String getPanelEmailsByTrid(String hrrfNumber, int level){
		String sql = "";
		if(level==1001) {
			sql = "SELECT TECHPANELEmail FROM "+ talentoView + " WHERE HRRFNUMBER = ?"; 
			return jdbcTemplate.queryForObject(sql, String.class, hrrfNumber);
		}else if(level==1002) {
			sql = "SELECT SECONDTECHPANELEmail FROM "+ talentoView + " WHERE HRRFNUMBER = ?";			
			return jdbcTemplate.queryForObject(sql, String.class, hrrfNumber);
		}
		
		return "";
	}	
		
	private static class MeetingDTORowMapper implements RowMapper<MeetingDTO>{

		@Override
		public MeetingDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
			MeetingDTO dto = new MeetingDTO();
			dto.setMeetingId(rs.getString("MEETING_ID"));
			dto.setLastUpdate(rs.getString("LST_UPD_DATE"));
			String emails = rs.getString("PANEL_EMAILS");
			if(emails != null && !emails.isEmpty()) {				
				List<String> finalList = new ArrayList<>();
				for(String mail : Arrays.asList(emails.split(",")))
					finalList.add(mail.trim());
				dto.setPanelEmails(finalList);
			}else {
				dto.setPanelEmails(null);
			}
			return dto;
		}
		
	}
}
