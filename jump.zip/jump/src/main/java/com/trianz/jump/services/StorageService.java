package com.trianz.jump.services;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
public class StorageService {

	@Autowired
	private AmazonS3 s3Client;
	
	@Value("${bucketName}")
	private String bucketName;

	Logger log = LoggerFactory.getLogger(StorageService.class);

	public String uploadProfile(MultipartFile file, String email) {
		log.debug(">>> service.uploadProfile()");
		String fileName = email.substring(0, email.indexOf('@')) + ".pptx";
		String key = "profiles/" + fileName;

		try {
			File fileObj = convertMultiPartFileToFile(file);
			s3Client.putObject(new PutObjectRequest(bucketName, key, fileObj));
			fileObj.delete();
			
			log.debug("<<< service.uploadProfile()");
			return fileName;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to upload user profile.");
		}
	}

	@SuppressWarnings("rawtypes")
	public ResponseEntity downloadPrfile(String email) {
		log.debug(">>> service.downloadPrfile()");
		
		String fileName = email.substring(0, email.indexOf('@')) + ".pptx";
		String key = "profiles/" + fileName;

		try {
			S3Object s3Object = s3Client.getObject(bucketName, key);
			S3ObjectInputStream inputStream = s3Object.getObjectContent();

			byte[] data = IOUtils.toByteArray(inputStream);

			ByteArrayResource resource = new ByteArrayResource(data);			
			
			log.debug("<<< service.downloadPrfile()");
			
			return ResponseEntity.ok().contentLength(data.length).header("Content-type", "application/octet-stream")
					.header("Content-disposition", "attachment; filename=\"" + fileName + "\"").body(resource);

		} catch (IOException e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", "Unable to download user profile.");
			return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
		}
	}

	private File convertMultiPartFileToFile(MultipartFile file) {
		log.debug(">>> service.convertMultiPartFileToFile()");
		
		File convertedFile = new File(file.getOriginalFilename());
		try (FileOutputStream fos = new FileOutputStream(convertedFile)) {
			fos.write(file.getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		log.debug("<<< service.convertMultiPartFileToFile()");
		return convertedFile;
	}
}
