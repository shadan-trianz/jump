package com.trianz.jump.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.JumpUtils;
import com.trianz.jump.dao.TRDAO;
import com.trianz.jump.model.Feedback;
import com.trianz.jump.services.FeedbackService;

@RestController
@RequestMapping("jump/feedback")
public class FeedbackController {

	@Autowired
	private FeedbackService service;
	
	@Autowired
	private TRDAO trdao;

	Logger log = LoggerFactory.getLogger(FeedbackController.class);

	// Update feedback
	@PutMapping("update-feedback")
	public ResponseEntity<Map<String, Object>> updateFeedback(Authentication auth, @RequestBody Feedback feedback) {
		log.debug(">>> updateFeedback()");
		try {
			Map<String, String> interviewer = JumpUtils.getUserDetails(auth);
			Map<String, Object> res = service.updateFeedback(interviewer.get("name"), interviewer.get("email"),
					feedback);

			log.debug("<<< updateFeedback()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
		}
	}

	// Get history of the feedback
	
	@SuppressWarnings("unchecked")
	@GetMapping("history")
	public ResponseEntity<Map<String, Object>> getFeedbackHistory(@RequestParam String trId, @RequestParam String email,
			@RequestParam String level, Authentication auth) {
		log.debug(">>> getFeedbackHistory()");
		Map<String, Object> res = new HashMap<String, Object>();
		try {
			Map<String, Object> userInfo = JumpUtils.getUserDetailsWithRoles(auth);
			Map<String, String> userDetails = (Map<String, String>) userInfo.get("userDetails");
			String loggedInEmail = userDetails.get("email");
			
			List<String> roles = (List<String>) userInfo.get("roles");
			String panelLevel = trdao.getLevelByEmailAndTrid(trId, loggedInEmail);
			if (roles.contains(JumpConstatnts.RECRUITER) || roles.contains("HR") || 
					(panelLevel != null && ( panelLevel.contains("first") || panelLevel.contains("second") )))
				res = service.getFeedbackHistoryRecruiter(trId, email, level);

			log.debug("<<< getFeedbackHistory");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}
	}
}
