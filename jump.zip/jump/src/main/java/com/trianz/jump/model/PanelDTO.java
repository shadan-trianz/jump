package com.trianz.jump.model;

public class PanelDTO {
	
	private String email;
	private String trId;
	private String level;
	
	public PanelDTO(String trId, String email, String level) {
		super();
		this.email = email;
		this.trId = trId;
		this.setLevel(level);
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTrId() {
		return trId;
	}

	public void setTrId(String trId) {
		this.trId = trId;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
	
}
