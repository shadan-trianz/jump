package com.trianz.jump.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.core.oidc.user.OidcUser;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.trianz.jump.JumpUtils;
import com.trianz.jump.model.Application;
import com.trianz.jump.services.EmailService;
import com.trianz.jump.services.JumpService;
import com.trianz.jump.services.StorageService;

@RestController
@RequestMapping("jump/employee")
public class EmployeeController {

	@Autowired
	private JumpService service;
	
	@Autowired
	private EmailService emailService;

	@Autowired
	private StorageService storageService;

	Logger log = LoggerFactory.getLogger(EmployeeController.class);

	// Get the list of jobs applied by an employee
	@GetMapping
	public ResponseEntity<Map<String, Object>> getAppliedJobs(Authentication auth) {
		log.debug(">>> getAppliedJobs()");

		try {
			String email = getUserEmail(auth);
			Map<String, Object> res = service.getAppliedJobs(email);
			
			log.debug("<<< getAppliedJobs()");
			return new ResponseEntity<>(res, HttpStatus.OK);

		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> err = new HashMap<>();
			err.put("message", e.getMessage());
			return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
		}

	}

	// Processes the job application of an employee
	@PostMapping("apply")
	public ResponseEntity<Map<String, Object>> apply(@RequestBody Application emp) {
		log.debug(">>> apply()");
		try {
			Map<String, Object> res = service.apply(emp);

			log.debug("<<< apply()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> err = new HashMap<>();
			err.put("message", e.getMessage());
			return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
		}
	}
	

	// Get the roles of the logged in user
	@SuppressWarnings("unchecked")
	@GetMapping("roles")
	public ResponseEntity<Map<String, Object>> getUserRoles(Authentication auth) {
		log.debug(">>> getUserRoles()");
		try {
			Map<String, Object> res = JumpUtils.getUserDetailsWithRoles(auth);
			Map<String, Object> userDetails = (Map<String, Object>) res.get("userDetails");
			String email = (String) userDetails.get("email");
			int count = service.getTrsCount(email);
			if(count>0)
				res.put("showDashBoard", true);
			else
				res.put("showDashBoard", false);
			
			log.debug("<<< getUserRoles()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> res = new HashMap<>();
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
		}
	}

	// To upload the profile of an employee only in PPTX format
	@PostMapping("/profile")
	public ResponseEntity<Map<String, Object>> uploadProfile(@RequestParam(value = "file") MultipartFile file,
															 Authentication auth) {
		log.debug(">>> uploadProfile()");
		Map<String, Object> res = new HashMap<>();
		try {
			String email = getUserEmail(auth);
			String fileName = storageService.uploadProfile(file, email);
			res.put("fileName", fileName);
			res.put("message", "File uploaded successfully!");

			log.debug("<<< uploadProfile()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			res.put("message", e.getMessage());
			return new ResponseEntity<>(res, HttpStatus.BAD_REQUEST);
		}

	}

	// Download the profile of an employee
	@SuppressWarnings("unchecked")
	@GetMapping("/profile")
	public ResponseEntity<ByteArrayResource> downloadProfile(Authentication auth) {
		log.debug(">>> downloadProfile()");
		try {
			String email = getUserEmail(auth);
			ResponseEntity<ByteArrayResource> res = storageService.downloadPrfile(email);
			
			log.debug("<<< downloadProfile()");
			return res;
		} catch (Exception e) {
			log.error(e.getMessage());
			return null;
		}

	}
	
	
	// Employee can withdraw his application
	@PutMapping("/application")
	public ResponseEntity<Map<String, Object>> updateApplication(Authentication auth, @RequestParam String trId, @RequestParam int statusId) {
		log.debug(">>> updateApplication()");
		try {
			Map<String, String> userDetails = JumpUtils.getUserDetails(auth);
			Map<String, Object> res = service.updateApplicationByCandidate(userDetails.get("email"), trId, statusId);
			log.debug("<<< updateApplication()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> resp = new HashMap<>();
			resp.put("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	@GetMapping("/mobile")
	public  ResponseEntity<Map<String, String>> getUserPhoneNumber(Authentication auth){
		
		log.debug(">>> getUserPhoneNumber()");
		Map<String, String> resp = new HashMap<>();
		try {
			
			Map<String, String> userDetails = JumpUtils.getUserDetails(auth);
			String mobile = emailService.getUserPhoneNumber(userDetails.get("email"));
			
			resp.put("phone", mobile);
			
			log.debug("<<< getUserPhoneNumber()");
			
			return new ResponseEntity<>(resp, HttpStatus.OK);
			
		} catch (Exception e) {
			log.error(e.getMessage());
			resp.put("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
		
	}
	
	
	// To fetch the user details from the authentication
	private String getUserEmail(Authentication auth) {
		log.debug(">>> controller.getUserEmail()");
//		if(auth == null) return "venkataramakrishna.v@trianz.com";
		OidcUser userDetails = (OidcUser) auth.getPrincipal();
        String email = userDetails.getPreferredUsername().toLowerCase();
        
        log.debug("<<< controller.getUserEmail()");
        return email;
	}

}
