package com.trianz.jump.model;

public class Application {

	private String trId;
	private String empName;
	private String statusId;
	private String statusName;
	private String mobile;
	private String email;
	private String totalExperience;
	private String trianzExperience;
	private String notes;
	private String jobTitle;
	private String primarySkills;
	private String secondarySkills;
	private String location;
	private String appliedDate;
	private String recruiterName;
	private String jobDescription;
	private String level;
	
	public Application() {
		super();
	}

	public String getEmpName() {
		return empName;
	}


	public void setEmpName(String empName) {
		this.empName = empName;
	}


	public String getStatusName() {
		return statusName;
	}


	public void setStatusName(String status) {
		this.statusName = status;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getTotalExperience() {
		return totalExperience;
	}


	public void setTotalExperience(String experience) {
		this.totalExperience = experience;
	}


	public String getNotes() {
		return notes;
	}


	public void setNotes(String remarks) {
		this.notes = remarks;
	}

	public String getTrId() {
		return trId;
	}

	public void setTrId(String trId) {
		this.trId = trId;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getPrimarySkills() {
		return primarySkills;
	}

	public void setPrimarySkills(String primarySkills) {
		this.primarySkills = primarySkills;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getAppliedDate() {
		return appliedDate;
	}

	public void setAppliedDate(String appliedDate) {
		this.appliedDate = appliedDate;
	}

	public String getSecondarySkills() {
		return secondarySkills;
	}

	public void setSecondarySkills(String secondarySkills) {
		this.secondarySkills = secondarySkills;
	}

	public String getTrianzExperience() {
		return trianzExperience;
	}

	public void setTrianzExperience(String trianzExperience) {
		this.trianzExperience = trianzExperience;
	}

	public String getRecruiterName() {
		return recruiterName;
	}

	public void setRecruiterName(String recruiterName) {
		this.recruiterName = recruiterName;
	}

	public String getStatusId() {
		return statusId;
	}

	public void setStatusId(String statusId) {
		this.statusId = statusId;
	}


	@Override
	public String toString() {
		return "Application [trId=" + trId + ", empName=" + empName + ", statusId=" + statusId + ", statusName="
				+ statusName + ", mobile=" + mobile + ", email=" + email + ", totalExperience=" + totalExperience
				+ ", trianzExperience=" + trianzExperience + ", notes=" + notes + ", jobTitle=" + jobTitle
				+ ", primarySkills=" + primarySkills + ", secondarySkills=" + secondarySkills + ", location=" + location
				+ ", appliedDate=" + appliedDate + ", recruiterName=" + recruiterName
				+ "]";
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}
}
