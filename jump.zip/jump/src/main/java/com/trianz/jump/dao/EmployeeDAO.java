package com.trianz.jump.dao;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.model.Application;

@Repository
public class EmployeeDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(EmployeeDAO.class);

	private String applicationsTable = "dbo.APPLICATIONS";
	private static String talentoView = "JUMP.dbo.vw_HRRFDetailJump";

	// Get the list of jobs applied by an employee
	public List<Application> getAppliedJobs(String emailId) {
		log.debug(">>> dao.getAppliedJobs()");

		String sql = "SELECT TR_ID, EMP_EMAILID, RoleRequired, CLSTRJD,"
				+ " PRIMARY_SKILLS, SECONDARY_SKILLS, TOTAL_EXPERIENCE, TRIANZ_EXPERIENCE, LOCATION, APPLICATIONS.CRT_DATE, UPDATED_BY,"
				+ " APPLICATIONS.APPLICATION_STATUS_ID, APPLICATION_STATUS_VALUES.APPLICATION_STATUS_NAME FROM"
				+ " Applications INNER JOIN APPLICATION_STATUS_VALUES"
				+ " ON APPLICATIONS.APPLICATION_STATUS_ID=APPLICATION_STATUS_VALUES.APPLICATION_STATUS_ID"
				+ " INNER JOIN " + talentoView + " ON APPLICATIONS.TR_ID=" + talentoView + ".HRRFNUMBER"
				+ " WHERE EMP_EMAILID = ? ORDER BY APPLICATIONS.CRT_DATE DESC";

		log.debug("sql:" + sql);

		try {
			List<Application> appliedJobs = jdbcTemplate.query(sql, (rs, row) -> {
				Application cur = new Application();
				cur.setTrId(rs.getString("TR_ID"));
				cur.setEmail(rs.getString("EMP_EMAILID"));
				cur.setJobTitle(rs.getString("RoleRequired"));
				cur.setPrimarySkills(rs.getString("PRIMARY_SKILLS"));
				cur.setSecondarySkills(rs.getString("SECONDARY_SKILLS"));
				cur.setTotalExperience(rs.getString("TOTAL_EXPERIENCE"));
				cur.setTrianzExperience(rs.getString("TRIANZ_EXPERIENCE"));
				cur.setLocation(rs.getString("LOCATION"));
				cur.setAppliedDate(rs.getString("CRT_DATE"));
				cur.setRecruiterName(rs.getString("UPDATED_BY"));
				cur.setStatusId(rs.getString("APPLICATION_STATUS_ID"));
				cur.setStatusName(rs.getString("APPLICATION_STATUS_NAME"));
				cur.setJobDescription(rs.getString("CLSTRJD"));

				return cur;
			}, emailId);

			log.debug("<<< dao.getAppliedJobs()");
			return appliedJobs;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in fetching the applied jobs.");
		}
	}

	// Processes the job application of an employee
	public void apply(Application emp) {
		log.debug(">>> dao.apply()");
		String sql = "INSERT INTO " + applicationsTable + " (TR_ID, EMP_EMAILID, EMP_NAME, MOBILE, TOTAL_EXPERIENCE,"
				+ " TRIANZ_EXPERIENCE, LOCATION, PRIMARY_SKILLS, SECONDARY_SKILLS, APPLICATION_STATUS_ID)"
				+ " VALUES(?,?,?,?,?,?,?,?,?,?)";

		log.debug("sql:" + sql);

		try {
			jdbcTemplate.update(sql, emp.getTrId(), emp.getEmail(), emp.getEmpName(), emp.getMobile(),
					emp.getTotalExperience(), emp.getTrianzExperience(), emp.getLocation(), emp.getPrimarySkills(),
					emp.getSecondarySkills(), "1");

			log.debug("<<< dao.apply()");
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to apply to this job!");
		}
	}

	// Fetches count of applications by an employee
	public int getApplicationsCount(String email) {
		log.debug(">>> dao.getApplicationsCount()");

		String sql = "SELECT COUNT(*) FROM " + applicationsTable
				+ " WHERE APPLICATION_STATUS_ID IN (1,10,20,30,80,90,110,120,140,150,170)" + " AND EMP_EMAILID =  ?";
		log.debug("sql:" + sql);

		try {
			int count = jdbcTemplate.queryForObject(sql, Integer.class, email);

			log.debug("<<< dao.getApplicationsCount()");
			return count;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to get applications count");
		}
	}

	// Fetches count of the TRS by an email
	public int getTRsCount(String email) {
		log.debug(">>> dao.getTRsCount()");
		
		String updatedEmail = "'%" + email + "%'";

		String sql = "SELECT COUNT(*) FROM " + talentoView
				+ " WHERE HRRFCreatedDate>='2024-07-01 00:00:00.00' AND RequestType LIKE 'External' AND RequestStatus LIKE 'Resume Pending'"
				+ " AND (TECHPANELEmail LIKE "+ updatedEmail +" OR SECONDTECHPANELEmail LIKE "+ updatedEmail +" OR"
				+ " SubmittedBy LIKE "+updatedEmail+")";
		log.debug("sql:" + sql);

		try {
			int count = jdbcTemplate.queryForObject(sql, Integer.class);

			log.debug("<<< dao.getTRsCount()");
			return count;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to get TRs count");
		}
	}
	
	
	public String getLoggedInUserLocation(String email) {
		
		log.debug(">>> dao.getLoggedInUserLocation()");
		
		String updatedEmail = "'%" + email + "'";
		
		String sql = "SELECT LOCATION FROM "+ applicationsTable
					+ " WHERE EMP_EMAILID LIKE "+ updatedEmail;
		log.debug("sql:" + sql);
		
		try {
			String location = jdbcTemplate.queryForObject(sql, String.class);

			log.debug("<<< dao.getLoggedInUserLocation()");
			return location;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("User / Location is not available");
		}
		
		
	}
    
	public boolean updateApplication(String email, String trId, int statusId) {

		log.debug(">>> dao.updateApplication()");
		String sql1 = "SELECT APPLICATION_STATUS_ID FROM " + applicationsTable + " WHERE TR_ID=? AND EMP_EMAILID=?";
		String sql2 = "UPDATE " + applicationsTable + " SET APPLICATION_STATUS_ID=? WHERE TR_ID=? AND EMP_EMAILID=?";

		log.debug("SQL1= " + sql1);
		log.debug("SQL2= " + sql2);
		
		int res = 0;

		try {
			int dbStatusId = jdbcTemplate.queryForObject(sql1, Integer.class, trId, email);
			if (dbStatusId == 1 || dbStatusId == 10) {
				log.debug("SQL2= " + sql2);
				res = jdbcTemplate.update(sql2, statusId, trId, email);
			} else if (dbStatusId == 190) {
				log.debug("SQL2= " + sql2);
				res = jdbcTemplate.update(sql2, statusId, trId, email);
			}
			log.debug("<<< dao.updateApplication()");
			return res > 0;
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to Accept/Reject/Withdraw the application");
		}
	}

}
