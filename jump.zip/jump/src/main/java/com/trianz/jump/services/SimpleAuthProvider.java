package com.trianz.jump.services;

import java.net.URL;
import java.util.Collections;
import java.util.concurrent.CompletableFuture;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.microsoft.aad.msal4j.ClientCredentialFactory;
import com.microsoft.aad.msal4j.ClientCredentialParameters;
import com.microsoft.aad.msal4j.ConfidentialClientApplication;
import com.microsoft.aad.msal4j.IAuthenticationResult;
import com.microsoft.graph.authentication.IAuthenticationProvider;

import jakarta.annotation.PostConstruct;

@Service
public class SimpleAuthProvider implements IAuthenticationProvider {

	@Value("${azure.application.client-id}")
	private String clientId;

	@Value("${azure.application.tenant-id}")
	private String tenantId;

	private String url;

	Logger log = LoggerFactory.getLogger(SimpleAuthProvider.class);

	@PostConstruct
	public void init() {
		this.url = "https://login.microsoftonline.com/" + tenantId;
	}

	@Override
	public CompletableFuture<String> getAuthorizationTokenAsync(URL requestUrl) {
		try {
			return getAccessToken();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private CompletableFuture<String> getAccessToken() throws Exception {
		log.debug(">>> getAccessToken");
		ConfidentialClientApplication app = ConfidentialClientApplication
				.builder(clientId,
						ClientCredentialFactory.createFromSecret("46G8Q~BT1_yGb7QAwGBxNQJycgt.HLt0ovgcYcDj"))
				.authority(url).build();

		ClientCredentialParameters parameters = ClientCredentialParameters
				.builder(Collections.singleton("https://graph.microsoft.com/.default")).build();
		log.debug("<<< getAccessToken");
		return app.acquireToken(parameters).thenApply(IAuthenticationResult::accessToken);
	}

}
