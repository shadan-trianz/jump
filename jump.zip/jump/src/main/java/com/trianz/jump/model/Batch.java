package com.trianz.jump.model;

import java.sql.Timestamp;

public class Batch {

	private String batchId;
	private Timestamp startTime;
	
	public String getBatchId() {
		return batchId;
	}
	
	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}
	
	public Timestamp getStartTime() {
		return startTime;
	}
	
	public void setStartTime(Timestamp startTime) {
		this.startTime = startTime;
	}
	
	@Override
	public String toString() {
		return "Batch [batchId=" + batchId + ", startTime=" + startTime + "]";
	}
	
}
