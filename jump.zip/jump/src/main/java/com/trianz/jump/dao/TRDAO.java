package com.trianz.jump.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.trianz.jump.model.ActiveTrsDTO;
import com.trianz.jump.model.PanelDTO;
import com.trianz.jump.model.TR;

@Repository
public class TRDAO {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	Logger log = LoggerFactory.getLogger(TRDAO.class);

	private static String talentoView = "JUMP.dbo.vw_HRRFDetailJump";

	// Fetches active TRs for employees
	public Map<String, Object> getActiveTRs(String email, int page, String sortBy, String sortDir, String search,
			String key) {
		log.debug(">>> dao.getActiveTRs()");
		try {

			int grade = getGrade(email);
			Map<String, Object> resp = new HashMap<>();

			if (grade >= 0) {
				// Get query to fetch and count records based on the key values
				String[] queries = getActiveTrQueries(email, page, sortBy, sortDir, search, key, grade);

				List<ActiveTrsDTO> activeTRs = fetchActiveTRs(queries[0]);
				int trCount = getRecordsCount(queries[1]);

				resp.put("data", activeTRs);
				resp.put("dataCount", trCount);

			} else {
				resp.put("dataCount", 0);
			}

			log.debug("<<< dao.getActiveTRs()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public List<ActiveTrsDTO> fetchActiveTRs(String sql) {
		log.debug(">>> dao.fetchActiveTRs()");
		log.debug("sql:" + sql);

		try {

			List<ActiveTrsDTO> trList = jdbcTemplate.query(sql, (rs, row) -> {
				ActiveTrsDTO cur = new ActiveTrsDTO();
				cur.setTrId(rs.getString("HRRFNUMBER"));
				cur.setJobTitle(rs.getString("RoleRequired"));
				cur.setJobDescription(rs.getString("CLSTRJD"));
				cur.setPrimarySkills(rs.getString("CSKILL"));
				cur.setExperience(rs.getString("ExpFrom"));
				cur.setLocation(rs.getString("LocationName"));
				cur.setAccountName(rs.getString("AccountName"));
				cur.setPractice(rs.getString("Practice"));
				cur.setProjectName(rs.getString("ProjectName"));
				cur.setCanApply(rs.getString("TR_ID") == null);

				return cur;
			});

			log.debug("<<< dao.fetchActiveTRs()");
			return trList;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in fetching the TR details.");
		}
	}

	// Get filtered TRs based on search criteria
	@SuppressWarnings("unchecked")
	public Map<String, Object> getFilteredTRs(String email, int page, String trflag, String sortBy, String sortDir,
			String search, String key, List<String> roles) {
		log.debug(">>> dao.getFilteredTRs()");
		try {

			String trId = "";
			String level = "";
			List<String> tridList = new ArrayList<>();
			Map<String, Object> resp = new HashMap<>();
			Map<String, Object> panelInfoMap = new HashMap<>();
			List<PanelDTO> panelList1 = new ArrayList<>();

			boolean hasHr = roles.stream().anyMatch(role -> role.equalsIgnoreCase("hr"));
			boolean hasRecruiter = roles.stream().anyMatch(role -> role.equalsIgnoreCase("recruiter"));

			if (hasHr && hasRecruiter) {
				tridList = getTRsForRecruiter();
				trId = tridList.stream().map(val -> "'" + val + "'").collect(Collectors.joining(", "));
				level = "recruiter, hr";
			} else if (hasRecruiter) {
				tridList = getTRsForRecruiter();
				trId = tridList.stream().map(val -> "'" + val + "'").collect(Collectors.joining(", "));
				level = "recruiter";
			} else if (hasHr) {
				tridList = getTRsForHr();
				if (tridList != null && tridList.size() > 0) {
					trId = tridList.stream().map(val -> "'" + val + "'").collect(Collectors.joining(", "));

					panelInfoMap = getPanelInfo(email);
					panelList1 = (List<PanelDTO>) panelInfoMap.get("panelInfo");
					String panelTRId = "";
					if (panelList1.size() > 0) {
						if (panelList1.size() == 1) {
							for (PanelDTO panel : panelList1) {
								panelTRId = "'" + panel.getTrId() + "'";
							}
						} else {
							for (PanelDTO panel : panelList1) {
								tridList.add(panel.getTrId());
							}
							panelTRId = tridList.stream().map(val -> "'" + val + "'").collect(Collectors.joining(", "));
						}
					}
					if (panelTRId != null && !panelTRId.isEmpty()) {
						if (trId != null && !trId.isEmpty()) {
							trId = trId.concat(", " + panelTRId);
						} else {
							trId = panelTRId;
						}
						level = (String) panelInfoMap.get("level");
						level = level.concat(", HR");
					} else {
						level = "hr";
					}
				} else {
					resp.put("data", "");
					resp.put("dataCount", 0);
					resp.put("level", "hr");
					return resp;
				}
			} else {

				panelInfoMap = getPanelInfo(email);

				panelList1 = (List<PanelDTO>) panelInfoMap.get("panelInfo");
				level = (String) panelInfoMap.get("level");
				if (panelList1.size() > 0) {
					if (panelList1.size() == 1) {
						for (PanelDTO panel : panelList1) {
							trId = "'" + panel.getTrId() + "'";
						}
					} else {
						for (PanelDTO panel : panelList1) {
							tridList.add(panel.getTrId());
						}
						trId = tridList.stream().map(val -> "'" + val + "'").collect(Collectors.joining(", "));
					}
				} else {
					resp.put("data", "");
					resp.put("dataCount", 0);
					resp.put("level", level);
					return resp;
				}
			}
			// Get SQL query based on the search criteria
			String[] queries = getFilteredTRQueries(email, page, trflag, sortBy, sortDir, search, key, trId, level);

			List<TR> filteredTRs = fetchFilteredTRs(queries[0]);
			int count = getRecordsCount(queries[1]);

			resp.put("data", filteredTRs);
			resp.put("dataCount", count);
			resp.put("level", level);

			log.debug("<<< dao.getFilteredTRs()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Fetches TRs for recruiter dashboard
	public List<TR> fetchFilteredTRs(String sql) {
		log.debug(">>> dao.fetchFilteredTRs()");
		log.debug("sql:" + sql);

		try {
			List<TR> trList = jdbcTemplate.query(sql, (rs, row) -> {
				TR cur = new TR();
				cur.setTrId(rs.getString("TR_ID"));
				cur.setJobTitle(rs.getString("RoleRequired"));
				cur.setPrimarySkills(rs.getString("CSKILL"));
				cur.setExperience(rs.getString("ExpFrom"));
				cur.setLocation(rs.getString("LocationName"));
				cur.setGrade(rs.getString("Grade"));
				cur.setJobDescription(rs.getString("CLSTRJD"));
				cur.setFirstLevelTechPanel(rs.getString("TECHPANEL"));
				cur.setSecondLevelTechPanel(rs.getString("SECONDTECHPANEL"));
				cur.setApplicationsCount(rs.getString("APPLICATIONS_COUNT"));
				cur.setPractice(rs.getString("Practice"));
				cur.setProjectName(rs.getString("ProjectName"));
				cur.setAccountName(rs.getString("AccountName"));
				cur.setTechPanelEmail(rs.getString("TECHPANELEmail"));
				cur.setSecondtechPanelEmail(rs.getString("SECONDTECHPANELEmail"));
				return cur;
			});

			log.debug("<<< dao.fetchFilteredTRs()");
			return trList;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in fetching the TR details.");
		}
	}

	// To get the count of records
	public int getRecordsCount(String sql) {
		log.debug(">>> dao.getRecordsCount()");
		log.debug("sql:" + sql);

		try {
			int count = jdbcTemplate.queryForObject(sql, Integer.class);

			log.debug("<<< dao.getRecordsCount()");
			return count;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in getRecordsCount.");
		}
	}

	// Fetches details of a particular TR
	public TR getTRById(String id) {
		log.debug(">>> dao.getTRById()");

		String sql = "SELECT HRRFNUMBER, RoleRequired, OrganizationGroup, CLSTRJD, CSKILL, ExpFrom, Grade,"
				+ " LocationName, AccountName, Practice, ProjectName, TECHPANEL, SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail,"
				+ " FORMAT(AssignmentStartDate, 'dd-MM-yyyy') AS AssignmentStartDate FROM " + talentoView
				+ " WHERE HRRFNUMBER = ?";

		log.debug("sql:" + sql);
		try {
			TR data = jdbcTemplate.queryForObject(sql, (rs, row) -> {
				TR cur = new TR();
				cur.setTrId(rs.getString("HRRFNUMBER"));
				cur.setJobTitle(rs.getString("RoleRequired"));
				cur.setOrganizationGroup(rs.getString("OrganizationGroup"));
				cur.setJobDescription(rs.getString("CLSTRJD"));
				cur.setPrimarySkills(rs.getString("CSKILL"));
				cur.setExperience(rs.getString("ExpFrom"));
				cur.setGrade(rs.getString("Grade"));
				cur.setLocation(rs.getString("LocationName"));
				cur.setAccountName(rs.getString("AccountName"));
				cur.setFirstLevelTechPanel(rs.getString("TECHPANEL"));
				cur.setSecondLevelTechPanel(rs.getString("SECONDTECHPANEL"));
				cur.setPractice(rs.getString("Practice"));
				cur.setProjectName(rs.getString("ProjectName"));
				cur.setAssignmentStartDate(rs.getString("AssignmentStartDate"));
				cur.setTechPanelEmail(rs.getString("TECHPANELEmail"));
				cur.setSecondtechPanelEmail(rs.getString("SECONDTECHPANELEmail"));

				return cur;
			}, id);

			log.debug("<<< dao.getTRById()");
			return data;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("TR with the given id is not found.");
		}
	}

	// Retrieves job-name based on trid
	public String getRoleRequired(String trId) {

		log.debug(">>> dao.getRoleRequired()");

		String sql = "SELECT RoleRequired FROM " + talentoView + " WHERE HRRFNUMBER =  ?";
		log.debug("sql:" + sql);

		try {
			String name = jdbcTemplate.queryForObject(sql, String.class, trId);
			log.debug("<<< dao.getRoleRequired()");

			return name;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Couldn't find RoleRequired for " + trId);
		}

	}

	// Returns the query based on the search criteria
	private String[] getActiveTrQueries(String email, int page, String sortBy, String sortDir, String search,
			String key, int grade) {
		log.debug(">>> dao.getActiveTrQuery()");

		int offset = page * 10 - 10;

		String sql = "";
		String countSql = "";
		String filterSql = "";

		// Sort by column
		switch (sortBy.toLowerCase()) {
		case "position":
			sortBy = "RoleRequired";
			break;
		case "experience":
			sortBy = "ExpFrom";
			break;
		case "primaryskills":
			sortBy = "CSKILL";
			break;
		case "location":
			sortBy = "LocationName";
			break;
		case "projectname":
			sortBy = "ProjectName";
			break;
		default:
			sortBy = "HRRFNUMBER";
			break;
		}

		// Sorting in ascending or descending
		if (sortDir.equalsIgnoreCase("asc")) {
			sortDir = "ASC";
		} else {
			sortDir = "DESC";
		}

		String baseSql = "SELECT HRRFNUMBER, RoleRequired, OrganizationGroup, CLSTRJD, CSKILL, ExpFrom,"
				+ " LocationName, AccountName, Practice, ProjectName, TR_ID FROM " + talentoView
				+ " LEFT JOIN (SELECT TR_ID FROM APPLICATIONS WHERE EMP_EMAILID='" + email + "')T2"
				+ " ON HRRFNUMBER = TR_ID" + " WHERE RequestType='External' AND" + " RequestStatus='Resume Pending'"
				+ " AND GRADE IN (" + grade + "," + (grade + 1) + ")";

		String baseCountSql = "SELECT COUNT(*) from " + talentoView + " WHERE RequestType='External'"
				+ " AND RequestStatus='Resume Pending' AND GRADE IN (" + grade + "," + (grade + 1) + ")";

		String offsetSql = " ORDER BY " + sortBy + " " + sortDir + " OFFSET " + offset
				+ " ROWS FETCH NEXT 10 ROWS ONLY";

		// GET ACTIVE TRs For Open Roles
		if (search == null) {

			sql = baseSql + offsetSql;
			countSql = baseCountSql;

		}
		// Search based on TR_ID
		else if (search.equalsIgnoreCase("trId")) {

			filterSql = " AND HRRFNUMBER LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql;

		}
		// Search based on JOB_TITLE
		else if (search.equalsIgnoreCase("position")) {

			filterSql = " AND RoleRequired LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql;

		}
		// Search based on PRIMARY SKILLS
		else if (search.equalsIgnoreCase("skill")) {

			filterSql = " AND CSKILL LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql;

		}

		log.debug("<<< dao.getActiveTrQuery()");
		return new String[] { sql, countSql };
	}

	// Returns query for filtered TRs based on search criteria
	private String[] getFilteredTRQueries(String email, int page, String trflag, String sortBy, String sortDir,
			String search, String key, String trId, String level) {
		log.debug(">>> dao.getFilteredTRsQuery()");

		// Sort by column
		switch (sortBy.toLowerCase()) {
		case "position":
			sortBy = "RoleRequired";
			break;
		case "grade":
			sortBy = "Grade";
			break;
		case "experience":
			sortBy = "ExpFrom";
			break;
		case "primaryskills":
			sortBy = "CSKILL";
			break;
		case "location":
			sortBy = "LocationName";
			break;
		case "projectname":
			sortBy = "ProjectName";
			break;
		case "applicationscount":
			sortBy = "APPLICATIONS_COUNT";
			break;
		default:
			sortBy = "TR_ID";
			break;
		}

		// Sorting in ascending or descending
		if (sortDir.equalsIgnoreCase("asc")) {
			sortDir = "ASC";
		} else {
			sortDir = "DESC";
		}

		int offset = page * 10 - 10;
		String offsetSql = " ORDER BY " + sortBy + " " + sortDir + " OFFSET " + offset
				+ " ROWS FETCH NEXT 10 ROWS ONLY";

		// Filter for OPEN TRs
		String trflagSql = " WHERE RequestStatus IN ('Resume Pending')";
		// Filter for CLOSED TRs
		if (trflag.equalsIgnoreCase("closed")) {
			trflagSql = " WHERE RequestStatus IN ('Fulfilled', 'Cancelled')";
		}

		// If search query is there
		if (search != null) {
			return getSearchQuery(offsetSql, trflagSql, search, key, trId, level);
		}

		String baseSql = "";
		String countSql = "";

		if (level.toLowerCase().contains("recruiter")) {

			baseSql = "SELECT TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
					+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice, COUNT(*) AS APPLICATIONS_COUNT"
					+ " FROM APPLICATIONS JOIN " + talentoView + " ON TR_ID = HRRFNUMBER" + trflagSql
					+ "  GROUP BY TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade,"
					+ " CLSTRJD, TECHPANEL, SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice";

			countSql = "SELECT COUNT(*) FROM" + " (SELECT COUNT(*) AS C FROM APPLICATIONS" + " JOIN " + talentoView
					+ " ON TR_ID = HRRFNUMBER" + trflagSql + " GROUP BY TR_ID) AS subquery";

		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSql(trflagSql, trId);
			countSql = getCountSql(trflagSql, trId);
		}

		String sql = baseSql + offsetSql;

		log.debug("<<< dao.getFilteredTRsQuery()");
		return new String[] { sql, countSql };
	}

	// Returns query for filtered TRs based on search criteria
	private String[] getSearchQuery(String offsetSql, String trflagSql, String search, String key, String trId,
			String level) {
		log.debug(">>> dao.getSearchQuery()");

		String baseSql = "";
		String baseCountSql = "";

		if (level.toLowerCase().contains("recruiter")) {
			baseSql = "SELECT TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
					+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice, COUNT(*) AS"
					+ " APPLICATIONS_COUNT FROM APPLICATIONS JOIN " + talentoView + " ON TR_ID = HRRFNUMBER"
					+ trflagSql;

			baseCountSql = "SELECT COUNT(*) FROM" + " (SELECT COUNT(*) AS C FROM APPLICATIONS" + " JOIN " + talentoView
					+ " ON TR_ID = HRRFNUMBER" + trflagSql;

			offsetSql = " GROUP BY TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
					+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice"
					+ offsetSql;

		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && !level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& level.toLowerCase().contains("trowner") && !level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		} else if (!level.toLowerCase().contains("first") && level.toLowerCase().contains("second")
				&& !level.toLowerCase().contains("trowner") && level.toLowerCase().contains("hr")) {
			baseSql = getBaseSqlForSearch(trflagSql, trId);
			baseCountSql = getBaseCountSqlForSearch(trflagSql, trId);
			offsetSql = getOffsetSqlForSearch(offsetSql);
		}

		String sql = "";
		String countSql = "";
		String filterSql = "";

		// Search based on TR_ID
		if (search.equalsIgnoreCase("trid")) {

			filterSql = " AND TR_ID LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql + " GROUP BY TR_ID) AS subquery";

		}

		// Search based on JOB_TITLE
		else if (search.equalsIgnoreCase("position")) {

			filterSql = " AND RoleRequired LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql + " GROUP BY TR_ID) AS subquery";

		}

		// Search based on PRIMARY SKILLS
		else if (search.equalsIgnoreCase("skill")) {

			filterSql = " AND CSKILL LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql + " GROUP BY TR_ID) AS subquery";

		}

		// Search based on GRADE
		else if (search.equalsIgnoreCase("grade")) {

			filterSql = " AND GRADE LIKE '%" + key + "%'";
			sql = baseSql + filterSql + offsetSql;
			countSql = baseCountSql + filterSql + " GROUP BY TR_ID) AS subquery";

		}

		log.debug("<<< dao.getSearchQuery()");

		return new String[] { sql, countSql };
	}

	// Fetches Grade and Indicator
	public int getGrade(String email) {

		log.debug(">>> dao.getGrade()");

		String updatedEmail = "%" + email;

		Integer result = 0;
		String sql = "SELECT JUMP.dbo.fn_GetEmployeeGrade(?)";

		try {

			log.debug("SQL= " + sql);

			result = jdbcTemplate.queryForObject(sql, Integer.class, updatedEmail);
			int val = (result != null) ? result.intValue() : -1;
			log.debug("<<< dao.getGrade()");
			return val;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch the Grade!");
		}

	}

	public String getPanelMembersEmail(String trId, int level) {

		log.debug(">>> dao.getPanelMembersEmail()");

		String sql = "";

		switch (level) {
		case 1001:
			sql = "SELECT TECHPANELEmail FROM " + talentoView + " JOIN dbo.APPLICATIONS ON TR_ID = HRRFNUMBER "
					+ "WHERE RequestStatus IN ('Resume Pending') AND RequestType LIKE 'External' AND "
					+ "TR_ID=? GROUP BY TECHPANELEmail";
			break;
		case 1002:
			sql = "SELECT SECONDTECHPANELEmail FROM " + talentoView + " JOIN dbo.APPLICATIONS ON TR_ID = HRRFNUMBER "
					+ "WHERE RequestStatus IN ('Resume Pending') AND RequestType LIKE 'External' AND "
					+ "TR_ID=? GROUP BY SECONDTECHPANELEmail";
			break;
		}

		try {
			String email = jdbcTemplate.queryForObject(sql, String.class, trId);
			log.debug("<<< dao.getPanelMembersEmail()");
			return email;
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch panel member email.");
		}
	}

	public String getLevelByEmailAndTrid(String trId, String email) {

		log.debug(">>> dao.getLevelByEmailAndTrid()");
		String level = "";
		String updatedEmail = "%" + email + "%";

		String sql1 = "SELECT TECHPANELEmail FROM " + talentoView
				+ " WHERE HRRFNUMBER LIKE ? AND TECHPANELEmail LIKE ?";
		String sql2 = "SELECT SECONDTECHPANELEmail FROM " + talentoView
				+ " WHERE HRRFNUMBER LIKE ? AND SECONDTECHPANELEmail LIKE ?";
		String sql3 = "SELECT SubmittedBy FROM " + talentoView + " WHERE HRRFNUMBER LIKE ? AND SubmittedBy LIKE ?";

		log.debug("SQL1= " + sql1);
		log.debug("SQL2= " + sql2);
		log.debug("SQL2= " + sql3);
		try {
			List<String> techPanel1 = jdbcTemplate.query(sql1, (rs, rowNum) -> rs.getString("TECHPANELEmail"), trId,
					updatedEmail);
			List<String> techPanel2 = jdbcTemplate.query(sql2, (rs, rowNum) -> rs.getString("SECONDTECHPANELEmail"),
					trId, updatedEmail);
			List<String> trOwner = jdbcTemplate.query(sql3, (rs, rowNum) -> rs.getString("SubmittedBy"), trId, updatedEmail);

			String email1 = techPanel1.isEmpty() ? "" : techPanel1.get(0).toLowerCase();
			String email2 = techPanel2.isEmpty() ? "" : techPanel2.get(0).toLowerCase();
			String email3 = trOwner.isEmpty() ? "" : trOwner.get(0).toLowerCase();
			email = email.toLowerCase();

			if ( (email1 != null && !email1.isEmpty()) || (email2 != null && !email2.isEmpty()) || (email3 != null && !email3.isEmpty())) {
				if (email1.contains(email) && email2.contains(email) && email3.contains(email))
					level = "first, second, trowner";
				else if (email1.contains(email) && email2.contains(email)
						&& !email3.contains(email))
					level = "first, second";
				else if (email1.contains(email) && !email2.contains(email)
						&& email3.contains(email))
					level = "first, trowner";
				else if (!email1.contains(email) && email2.contains(email)
						&& email3.contains(email))
					level = "second, trowner";
				else if (email1.contains(email) && !email2.contains(email)
						&& !email3.contains(email))
					level = "first";
				else if (!email1.contains(email) && email2.contains(email)
						&& !email3.contains(email))
					level = "second";
				else if (!email1.contains(email) && !email2.contains(email)
						&& email3.contains(email))
					level = "trowner";
			}

			log.debug("<<< dao.getLevelByEmailAndTrid()");
			return level;
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch panel member email.");
		}
	}

	private Map<String, Object> getPanelInfo(String email) {
		log.debug(">>> dao.getPanelInfo()");
		Map<String, Object> panelMap = new HashMap<String, Object>();
		List<PanelDTO> panelInfo1;
		List<PanelDTO> panelInfo2;
		List<PanelDTO> panelInfo3;
		List<PanelDTO> trOwner;
		String updatedEmail = "'%" + email + "%'";

		String sql1 = "SELECT HRRFNUMBER AS TR_ID, TECHPANELEmail AS EMAIL FROM " + talentoView + " WHERE "
				+ "RequestType LIKE 'External' AND RequestStatus IN ('Resume Pending') AND HRRFCreatedDate>='2024-07-01 00:00:00.00' "
				+ "AND TECHPANELEmail LIKE " + updatedEmail;

		String sql2 = "SELECT HRRFNUMBER AS TR_ID, SECONDTECHPANELEmail AS EMAIL FROM " + talentoView + " WHERE "
				+ "RequestType LIKE 'External' AND RequestStatus IN ('Resume Pending') AND HRRFCreatedDate>='2024-07-01 00:00:00.00' "
				+ "AND SECONDTECHPANELEmail LIKE " + updatedEmail;

		String sql3 = "SELECT HRRFNUMBER AS TR_ID, SubmittedBy AS EMAIL FROM " + talentoView + " WHERE "
				+ "RequestType LIKE 'External' AND RequestStatus IN ('Resume Pending') AND HRRFCreatedDate>='2024-07-01 00:00:00.00' "
				+ "AND SubmittedBy LIKE " + updatedEmail;

		log.debug("SQL= " + sql1);
		log.debug("SQL= " + sql2);
		log.debug("SQL3= " + sql3);
		try {

			panelInfo1 = jdbcTemplate.query(sql1, (rs, row) -> {
				PanelDTO cur = new PanelDTO(rs.getString("TR_ID"), rs.getString("EMAIL"), "first");
				return cur;
			});

			panelInfo2 = jdbcTemplate.query(sql2, (rs, row) -> {
				PanelDTO cur = new PanelDTO(rs.getString("TR_ID"), rs.getString("EMAIL"), "second");
				return cur;
			});

			trOwner = jdbcTemplate.query(sql3, (rs, row) -> {
				PanelDTO cur = new PanelDTO(rs.getString("TR_ID"), rs.getString("EMAIL"), "trowner");
				return cur;
			});

			log.debug("<<< dao.getPanelInfo()()");
			if (!panelInfo1.isEmpty() && !panelInfo2.isEmpty() && !trOwner.isEmpty()) {
				panelInfo3 = new ArrayList<>(panelInfo1);
				panelInfo3.addAll(panelInfo2);
				panelInfo3.addAll(trOwner);
				panelMap.put("panelInfo", panelInfo3);
				panelMap.put("level", "trowner, first, second");
				return panelMap;
			} else if (!panelInfo1.isEmpty() && !panelInfo2.isEmpty() && trOwner.isEmpty()) {
				panelInfo3 = new ArrayList<>(panelInfo1);
				panelInfo3.addAll(panelInfo2);
				panelMap.put("panelInfo", panelInfo3);
				panelMap.put("level", "first, second");
				return panelMap;
			} else if (!panelInfo1.isEmpty() && panelInfo2.isEmpty() && !trOwner.isEmpty()) {
				panelInfo3 = new ArrayList<>(panelInfo1);
				panelInfo3.addAll(trOwner);
				panelMap.put("panelInfo", panelInfo3);
				panelMap.put("level", "trowner, first");
				return panelMap;
			} else if (panelInfo1.isEmpty() && !panelInfo2.isEmpty() && !trOwner.isEmpty()) {
				panelInfo3 = new ArrayList<>(panelInfo2);
				panelInfo3.addAll(trOwner);
				panelMap.put("panelInfo", panelInfo3);
				panelMap.put("level", "trowner, second");
				return panelMap;
			} else if (!panelInfo1.isEmpty() && panelInfo2.isEmpty() && trOwner.isEmpty()) {
				panelMap.put("panelInfo", panelInfo1);
				panelMap.put("level", "first");
				return panelMap;
			} else if (panelInfo1.isEmpty() && !panelInfo2.isEmpty() && trOwner.isEmpty()) {
				panelMap.put("panelInfo", panelInfo2);
				panelMap.put("level", "second");
				return panelMap;
			} else if (panelInfo1.isEmpty() && panelInfo2.isEmpty() && !trOwner.isEmpty()) {
				panelMap.put("panelInfo", trOwner);
				panelMap.put("level", "trowner");
				return panelMap;
			} else {
				panelMap.put("panelInfo", new ArrayList<PanelDTO>());
				panelMap.put("level", "");
				return panelMap;
			}
		} catch (DataAccessException e) {
			log.error(e.getMessage());
			throw new RuntimeException("Unable to fetch tech panel details.");
		}
	}

	// Fetches TRs whose Application status is second level selected or above
	private List<String> getTRsForHr() {

		log.debug(">>> dao.getTRsForHr()");
		List<String> trIds = new ArrayList<>();

		String sql = "SELECT TR_ID FROM dbo.APPLICATIONS WHERE APPLICATION_STATUS_ID>=90 AND APPLICATION_STATUS_ID!=210";

		log.debug("SQL= " + sql);

		try {
			trIds = jdbcTemplate.queryForList(sql, String.class);
			log.debug("<<< dao.getTRsForHr()");
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in getting TRIDs.");
		}
		return trIds;
	}

	// Fetches All TRs for Recruiter
	private List<String> getTRsForRecruiter() {
		log.debug(">>> dao.getTRsForRecruiter()");
		List<String> trIds = new ArrayList<>();

		String sql = "SELECT TR_ID FROM dbo.APPLICATIONS";

		log.debug("SQL= " + sql);

		try {
			trIds = jdbcTemplate.queryForList(sql, String.class);
			log.debug("<<< dao.getTRsForRecruiter()");
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException("Error in getting all TRIDs.");
		}
		return trIds;
	}

	private String getBaseSql(String trflagSql, String trId) {

		return "SELECT TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
				+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice, COUNT(*) AS APPLICATIONS_COUNT"
				+ " FROM APPLICATIONS JOIN " + talentoView + " ON TR_ID = HRRFNUMBER" + trflagSql + " AND TR_ID IN ("
				+ trId + ")" + "  GROUP BY TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade,"
				+ " CLSTRJD, TECHPANEL, SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice";
	}

	private String getCountSql(String trflagSql, String trId) {
		return "SELECT COUNT(*) FROM" + " (SELECT COUNT(*) AS C FROM APPLICATIONS" + " JOIN " + talentoView
				+ " ON TR_ID = HRRFNUMBER" + trflagSql + " AND TR_ID IN (" + trId + ") GROUP BY TR_ID) AS subquery";
	}

	private String getBaseSqlForSearch(String trflagSql, String trId) {
		return "SELECT TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
				+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice, COUNT(*) AS"
				+ " APPLICATIONS_COUNT FROM APPLICATIONS JOIN " + talentoView + " ON TR_ID = HRRFNUMBER" + trflagSql
				+ " AND TR_ID IN (" + trId + ")";
	}

	private String getBaseCountSqlForSearch(String trflagSql, String trId) {

		return "SELECT COUNT(*) FROM" + " (SELECT COUNT(*) AS C FROM APPLICATIONS" + " JOIN " + talentoView
				+ " ON TR_ID = HRRFNUMBER" + trflagSql + " AND TR_ID IN (" + trId + ")";

	}

	private String getOffsetSqlForSearch(String offsetSql) {

		return " GROUP BY TR_ID, RoleRequired, CSKILL, ExpFrom, LocationName, Grade, CLSTRJD, TECHPANEL,"
				+ " SECONDTECHPANEL, TECHPANELEmail, SECONDTECHPANELEmail, AccountName, ProjectName, Practice"
				+ offsetSql;
	}
}
