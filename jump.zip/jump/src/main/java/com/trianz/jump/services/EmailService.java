package com.trianz.jump.services;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.azure.identity.ClientSecretCredential;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.microsoft.graph.authentication.TokenCredentialAuthProvider;
import com.microsoft.graph.models.BodyType;
import com.microsoft.graph.models.EmailAddress;
import com.microsoft.graph.models.ItemBody;
import com.microsoft.graph.models.Message;
import com.microsoft.graph.models.Recipient;
import com.microsoft.graph.models.User;
import com.microsoft.graph.models.UserSendMailParameterSet;
import com.microsoft.graph.requests.GraphServiceClient;

import jakarta.annotation.PostConstruct;
import okhttp3.Request;



@Service
public class EmailService {
	
	@Value("${azure.application.client-id}")
	private String clientId;
	
	@Value("${azure.application.tenant-id}")
	private String tenantId;
	
	@Value("${azure.application.client-secret}")
	private String clientSecret;
	
	@Value("${spring.mail.username}")
	private String fromEmail;
	
	@Autowired
	private TemplateEngine templateEngine;
	
	private GraphServiceClient<Request> graphClient;
	
	Logger log = LoggerFactory.getLogger(EmailService.class);
	
	@PostConstruct
	public void init() {
		ClientSecretCredential clientSecretCredential = new ClientSecretCredentialBuilder()
														.clientId(clientId)
														.tenantId(tenantId)
														.clientSecret(clientSecret)
														.build();
		TokenCredentialAuthProvider authProvider = new TokenCredentialAuthProvider(
				Collections.singletonList("https://graph.microsoft.com/.default"), clientSecretCredential);
		
		graphClient = GraphServiceClient.builder()
					  .authenticationProvider(authProvider)
					  .buildClient();
	}
	
	public void sendEmail(String toMail, String ccMail, String subject, String templateName, Map<String, Object> variables) {
		log.debug(">>> emailService.sendEmail()");
		
		   Context context = new Context();
	       context.setVariables(variables);
	        
	       String body = templateEngine.process(templateName, context);
			
			Message message = new Message();
			ItemBody itemBody = new ItemBody();
		itemBody.contentType = BodyType.HTML;
		itemBody.content = body;
		
		message.subject = subject;
		message.body = itemBody;
		
		if(toMail.equals(ccMail)) {
			message.toRecipients = getToRecipients(toMail);
		}else {
			if(ccMail != null && !ccMail.isEmpty())
				message.ccRecipients = getCcRecipients(ccMail);
			message.toRecipients = getToRecipients(toMail);			
		}		
		
		graphClient.users(fromEmail).sendMail(UserSendMailParameterSet.newBuilder()
				.withMessage(message)
				.withSaveToSentItems(true)
				.build())
				.buildRequest()
				.post();	
		
		log.debug("<<< emailService.sendEmail()");
	}
	
	public String getUserPhoneNumber(String email) {
		log.debug(">>> emailService.getUserPhoneNumber()");
		
		User user = graphClient.users(email)
					.buildRequest()
					.select("mobilePhone")
					.get();
		
		log.debug("<<< emailService.getUserPhoneNumber()");
		return user.mobilePhone;
		
	}
	
	private LinkedList<Recipient> getToRecipients(String toMail){
		log.debug(">>> emailService.getToRecipients()");
		
		LinkedList<Recipient> toRecipients = new LinkedList<>();
		EmailAddress emailAddress1 = new EmailAddress();
		Recipient recipient1 = new Recipient();
		
		emailAddress1.address = toMail;
		recipient1.emailAddress = emailAddress1;
		toRecipients.add(recipient1);
		
		log.debug("<<< emailService.getToRecipients()");
		return toRecipients;
	}
	
	private LinkedList<Recipient> getCcRecipients(String ccMail){
		log.debug(">>> emailService.getCcRecipients()");
		
		LinkedList<Recipient> ccRecipients = new LinkedList<>();
		EmailAddress emailAddress2 = new EmailAddress();
		Recipient recipient2 = new Recipient();
		
		emailAddress2.address = ccMail;
		recipient2.emailAddress = emailAddress2;
		ccRecipients.add(recipient2);
		
		log.debug("<<< emailService.getCcRecipients()");
		return ccRecipients;
	}

}
