package com.trianz.jump.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.trianz.jump.JumpUtils;
import com.trianz.jump.model.MeetingDetails;
import com.trianz.jump.services.MeetingService;

@RestController
@RequestMapping("jump/meetings")
public class MeetingController {

	@Autowired
	private MeetingService teamsMeetingService;

	Logger log = LoggerFactory.getLogger(MeetingController.class);

	@PostMapping("/schedule")
	public ResponseEntity<Map<String, String>> scheduleMeeting(Authentication auth, @RequestBody MeetingDetails meetingDetails) {

		log.debug(">>> scheduleMeeting()");

		try {
			Map<String, String> recruiter = JumpUtils.getUserDetails(auth);
			Map<String, String> res = teamsMeetingService.scheduleMeeting(meetingDetails.getTrId(),
					meetingDetails.getEmail(), recruiter.get("email"), meetingDetails.getInterviewerMail(),
					meetingDetails.getLevel(), meetingDetails.getStart_date(), meetingDetails.getEnd_date(), meetingDetails.isReschedule());

			log.debug("<<< scheduleMeeting()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, String> resp = new HashMap<>();
			resp.put("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping("/meeting")
	public ResponseEntity<Map<String, Object>> getMeeting(@RequestParam String trId, 
			@RequestParam String email, @RequestParam int level, Authentication auth) {
		log.debug(">>> getMeeting()");

		try {
			JumpUtils.getUserDetails(auth);
			Map<String, Object> res = teamsMeetingService.getMeeting(trId, email, level);
			log.debug("<<< getMeeting()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, Object> resp = new HashMap<>();
			resp.put("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}

	}

	@DeleteMapping("/invite")
	public ResponseEntity<Map<String, String>> removeMeeting(Authentication auth, @RequestParam String meetingId) {
		log.debug(">>> removeMeeting()");

		try {
			JumpUtils.getUserDetails(auth);
			Map<String, String> res = teamsMeetingService.removeMeeting(meetingId);
			log.debug("<<< removeMeeting()");
			return new ResponseEntity<>(res, HttpStatus.OK);
		} catch (Exception e) {
			log.error(e.getMessage());
			Map<String, String> resp = new HashMap<>();
			resp.put("error", e.getMessage());
			return new ResponseEntity<>(resp, HttpStatus.BAD_REQUEST);
		}

	}
}