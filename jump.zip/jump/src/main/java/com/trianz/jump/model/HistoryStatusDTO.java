package com.trianz.jump.model;

public class HistoryStatusDTO {
	private String applicationStatusId;
	private String applicationStatusName;
	private String lastUpdate;
	
	public HistoryStatusDTO(String applicationStatusId, String applicationStatusName, String lastUpdate) {
		super();
		this.applicationStatusId = applicationStatusId;
		this.applicationStatusName = applicationStatusName;
		this.lastUpdate = lastUpdate;
	}

	public String getApplicationStatusId() {
		return applicationStatusId;
	}

	public void setApplicationStatusId(String applicationStatusId) {
		this.applicationStatusId = applicationStatusId;
	}

	public String getApplicationStatusName() {
		return applicationStatusName;
	}

	public void setApplicationStatusName(String applicationStatusName) {
		this.applicationStatusName = applicationStatusName;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
}
