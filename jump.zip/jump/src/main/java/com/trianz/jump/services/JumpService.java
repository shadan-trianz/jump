package com.trianz.jump.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.dao.EmployeeDAO;
import com.trianz.jump.dao.RecruiterDAO;
import com.trianz.jump.dao.TRDAO;
import com.trianz.jump.model.Application;
import com.trianz.jump.model.HistoryNotesDTO;
import com.trianz.jump.model.HistoryStatusDTO;
import com.trianz.jump.model.TR;

@Service
public class JumpService {

	@Autowired
	private TRDAO trDao;

	@Autowired
	private EmployeeDAO empDao;

	@Autowired
	private RecruiterDAO recDao;

	@Autowired
	private EmailService emailService;

	Logger log = LoggerFactory.getLogger(JumpService.class);

	@Autowired
	private Environment environment;

	// Methods for TR Controller: start
	// Fetches active TRs for employees
	public Map<String, Object> getActiveTRs(String email, int page, String sortBy, String sortDir, String search,
			String key) {
		log.debug(">>> service.getActiveTRs()");
		try {

			Map<String, Object> resp = trDao.getActiveTRs(email, page, sortBy, sortDir, search, key);

			int appCount = empDao.getApplicationsCount(email);

			resp.put("applicationsCount", appCount);
			resp.put("message", "success");

			log.debug("<<< service.getActiveTRs()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get filtered TRs based on search criteria
	public Map<String, Object> getFilteredTRs(String email, int page, String trflag, String sortBy, String sortDir,
			String search, String key, List<String> roles) {
		log.debug(">>> service.getFilteredTRs()");
		try {
			Map<String, Object> resp = trDao.getFilteredTRs(email, page, trflag, sortBy, sortDir, search, key, roles);

			resp.put("message", "success");

			log.debug("<<< service.getFilteredTRs()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get details a specific TR by ID
	public Map<String, Object> getTRById(String id) {
		log.debug(">>> service.getTRById()");

		try {
			TR data = trDao.getTRById(id);

			Map<String, Object> resp = new HashMap<>();
			resp.put("message", "success");
			resp.put("data", data);

			log.debug("<<< service.getTRById()");
			return resp;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Methods for TR Controller: end

	// Methods for Employee Controller: start
	// Processes the job application of an employee
	public Map<String, Object> apply(Application emp) {
		log.debug(">>> service.apply()");

		String message = "";
		String subject = "";
		try {
			// Check if TR_ID exists
			TR tr = trDao.getTRById(emp.getTrId());
			if (tr == null) {
				message = "TR Id is not valid!";
			} else {
				empDao.apply(emp);
				message = "Successfully applied to the job.";

				if (getCurrentEnvironment()) {
					subject = "[NON-PROD] ";
				}

				String name = emp.getEmail();
				name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
				name = name.substring(0, 1).toUpperCase() + name.substring(1);

				subject = subject + JumpConstatnts.APPLIED_TEXT + " [ " + emp.getTrId() + " ]";
				String job = trDao.getRoleRequired(emp.getTrId());

				Map<String, Object> variables = new HashMap<>();
				variables.put("jobTitle", job);
				variables.put("name", name);
				emailService.sendEmail(emp.getEmail(), emp.getEmail(), subject, "applied", variables);
			}

			Map<String, Object> resp = new HashMap<>();
			resp.put("message", message);

			log.debug("<<< service.apply()");
			return resp;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get all the jobs applied by an employee
	public Map<String, Object> getAppliedJobs(String email) {
		log.debug(">>> service.getAppliedJobs()");

		try {
			List<Application> appliedJobs = empDao.getAppliedJobs(email);

			Map<String, Object> resp = new HashMap<>();
			resp.put("message", "success");
			resp.put("data", appliedJobs);

			log.debug("<<< service.getAppliedJobs()");
			return resp;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Methods for Employee Controller: end

	// Methods for Recruiter Controller: start
	public Map<String, Object> getApplicationsByTrId(String trId, List<String> roles, String email) {
		log.debug(">>> service.getApplicationsByTrId()");

		String message = "";
		try {
			Map<String, Object> resp = new HashMap<>();
			String level = trDao.getLevelByEmailAndTrid(trId, email);
			List<Application> applications = recDao.getApplicationsByTrId(trId, roles, level);
			if (applications.isEmpty()) {
				message = "No data found!";
			} else {

				// Get application status list
				List<Map<String, Object>> appStatusList = recDao.getAppStatusList();
				resp.put("appStatusList", appStatusList);
				boolean hasHr = roles.stream().anyMatch(role -> role.equalsIgnoreCase("hr"));
				boolean hasRecruiter = roles.stream().anyMatch(role -> role.equalsIgnoreCase("recruiter"));
				if (hasRecruiter) {
					resp.put("level", "recruiter");
				} else if (hasHr) {
					resp.put("level", "hr");
				}

				message = "success";
			}

			resp.put("message", message);
			resp.put("data", applications);

			log.debug("<<< service.getApplicationsByTrId()");
			return resp;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Updates the status or notes of an application
	public Map<String, Object> updateApplication(String recruiterName, String recruiterEmail, Application application) {
		log.debug(">>> service.updateApplication()");

		String message = "";
		String subject = "";
		String template = "";
		try {
			boolean result = false;

			// Update status
			if (application.getStatusId() != null && !application.getStatusId().isEmpty()) {
				result = recDao.updateApplicationStatus(recruiterName, application);
				message = "Successfully updated the application status!";

				String name = application.getEmail();
				name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
				name = name.substring(0, 1).toUpperCase() + name.substring(1);

				String status = application.getStatusId();
				String job = trDao.getRoleRequired(application.getTrId());

				if (getCurrentEnvironment()) {
					subject = "[NON-PROD] ";
				}

				if (status.equals("1")) {
					log.info("You've already applied to this position");
				} else if (status.equals("190")) {
					log.info("Position Offered to you.");
				} else if (status.equals("200")) {
					log.info("Your relieving is confirmed");
				} else {

					Map<String, Object> variables = new HashMap<>();
					if (status.equals("10")) {
						subject = subject + JumpConstatnts.IN_PROCESS_TEXT + " [ " + application.getTrId() + " ]";
						template = "inprocess";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("40")) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_1 + " [ " + application.getTrId() + " ]";
						template = "reject";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("100")) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_2 + " [ " + application.getTrId() + " ]";
						template = "reject";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("130")) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_HR + " [ " + application.getTrId() + " ]";
						template = "rejectHR";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("companyName", "TBD");
					} else if (status.equals("160")) {
						subject = subject + JumpConstatnts.REJECTED_TEXT_CLIENT + " [ " + application.getTrId() + " ]";
						template = "rejectClient";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("companyName", "TBD");
					} else if (status.equals("30")) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_1 + " [ " + application.getTrId() + " ]";
						template = "select";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("level", "Level 1");
					} else if (status.equals("90")) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_2 + " [ " + application.getTrId() + " ]";
						template = "select";
						variables.put("jobTitle", job);
						variables.put("name", name);
						variables.put("level", "Level 2");
					} else if (status.equals("120")) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_HR + job + " [ " + application.getTrId()
								+ " ]";
						template = "selectHR";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("150")) {
						subject = subject + JumpConstatnts.SELECTED_TEXT_CLIENT + " [ " + application.getTrId() + " ]";
						template = "selectClient";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("60")) {
						subject = subject + JumpConstatnts.CLOSED_TEXT + " [ " + application.getTrId() + " ]";
						template = "closed";
						variables.put("jobTitle", job);
						variables.put("name", name);
					} else if (status.equals("180")) {
						subject = subject + JumpConstatnts.OFFER_REJECTION_ACKNOWLEDGE + job;
						template = "offerRejection";
						variables.put("jobTitle", job);
						variables.put("companyName", "TBD");
					} else if (status.equals("170")) {
						subject = subject + JumpConstatnts.OFFER_ACCEPTANCE + job;
						template = "offerAccepted";
						variables.put("jobTitle", job);
						variables.put("companyName", "TBD");
						variables.put("name", name);
						variables.put("start_date", "TBD");
						variables.put("hrContact", "TBD");
						variables.put("contactInfo", "TBD");
					}

					emailService.sendEmail(application.getEmail(), recruiterEmail, subject, template, variables);
				}

			}

			// Update notes
			else if (application.getNotes() != null && !application.getNotes().isEmpty()) {
				result = recDao.updateApplicationNotes(recruiterName, application);
				message = "Successfully added the application notes!";
			}
			if (!result)
				message = "Unsuccessfull! Application with the given TR ID and EMAIL ID doesn't exist.";

			Map<String, Object> res = new HashMap<>();
			res.put("message", message);

			log.debug("<<< service.updateApplication()");
			return res;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	// Get history of application status updates and notes updates
	public Map<String, Object> getApplicationHistory(String trId, String email) {
		log.debug(">>> service.getApplicationHistory()");

		try {
			// Get status history
			List<HistoryStatusDTO> statusHist = recDao.getStatusHistory(trId, email);

			// Get notes history
			List<HistoryNotesDTO> notesHist = recDao.getNotesHistory(trId, email);

			Map<String, Object> resp = new HashMap<>();
			resp.put("notesHist", notesHist);
			resp.put("statusHist", statusHist);
			resp.put("message", "success");

			log.debug("<<< service.getApplicationHistory()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public Map<String, Object> updateApplicationByCandidate(String email, String trId, int statusId) {

		log.debug(">>> service.updateApplicationByCandidate()");
		String message = "";
		String subject = "";
		String template = "";
		Map<String, Object> variables = new HashMap<>();
		try {

			boolean result = false;

			if (email != null && trId != null) {
				if (!email.isEmpty() && !trId.isEmpty()) {

					result = empDao.updateApplication(email, trId, statusId);

					if (result) {

						if (getCurrentEnvironment()) {
							subject = "[NON-PROD] ";
						}

						String name = email;
						name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
						name = name.substring(0, 1).toUpperCase() + name.substring(1);

						String job = trDao.getRoleRequired(trId);
						if (statusId == 210) {
							subject = subject + JumpConstatnts.WITHDRAW_TEXT + " [ " + trId + " ]";
							template = "withdraw";
							variables.put("jobTitle", job);
							variables.put("name", name);
						} else if (statusId == 170) {
							subject = subject + JumpConstatnts.OFFER_ACCEPTANCE + " [ " + trId + " ]";
							template = "offerAccepted";
							variables.put("jobTitle", job);
							variables.put("name", name);
							variables.put("companyName", "TBD");
							variables.put("start_date", "TBD");
							variables.put("hrContact", "TBD");
							variables.put("contactInfo", "TBD");

						} else if (statusId == 180) {
							subject = subject + JumpConstatnts.OFFER_REJECTION_ACKNOWLEDGE + " [ " + trId + " ]";
							template = "offerRejection";
							variables.put("jobTitle", job);
							variables.put("companyName", "TBD");

						}

						emailService.sendEmail(email, "", subject, template, variables);
					}
					message = "Successfully updated the application status.";
				}
			}

			if (!result)
				message = "Unsuccessful! Unable to update the application.";

			Map<String, Object> res = new HashMap<>();
			res.put("message", message);
			log.debug("<<< service.updateApplicationByCandidate()");
			return res;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public int getTrsCount(String email) {
		log.debug(">>> service.getTrsCount()");
		int count = empDao.getTRsCount(email);
		log.debug("<<< service.getTrsCount()");
		return count;
	}

	public String getLoggedInUserLocation(String email) {
		log.debug(">>> service.getLoggedInUserLocation()");
		String location = empDao.getLoggedInUserLocation(email);
		log.debug("<<< service.getLoggedInUserLocation()");
		return location;
	}

	private boolean getCurrentEnvironment() {
		String[] activeEnv = environment.getActiveProfiles();
		return Stream.of(activeEnv).anyMatch(s -> s.contains(JumpConstatnts.DEV));
	}

	public Map<String, Object> getApplicationsByTrIdAndEmail(String trId, String email) {
		log.debug(">>> service.getApplicationsByTrIdAndEmail()");
		try {

			List<Application> application = recDao.getApplicationsByTrIdAndEmail(trId, email);

			Map<String, Object> resp = new HashMap<>();
			resp.put("application", application);
			resp.put("message", "success");

			log.debug("<<< service.getApplicationsByTrIdAndEmail()");
			return resp;
		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}

	public XSSFWorkbook exportDashboard(List<String> trs) {
		log.debug(">>> service.exportDashboard()");
		List<Map<String, Object>> listUsers = recDao.exportDashboard(trs);

		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Applications");

		// Create header row
		XSSFRow headerRow = sheet.createRow(0);
		if (!listUsers.isEmpty()) {
			Map<String, Object> headerMap = listUsers.get(0);
			int headerColCount = 0;
			for (String key : headerMap.keySet()) {
				headerRow.createCell(headerColCount++).setCellValue(key);
			}
		}

		// Fill data rows
		int rowCount = 1;
		for (Map<String, Object> userMap : listUsers) {
			XSSFRow row = sheet.createRow(rowCount++);
			int colCount = 0;
			for (Object value : userMap.values()) {
				row.createCell(colCount++).setCellValue(value != null ? value.toString() : "");
			}
		}

		return workbook;
	}

}
