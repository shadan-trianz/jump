package com.trianz.jump.services;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.SchedulingConfigurer;
import org.springframework.scheduling.config.ScheduledTaskRegistrar;
import org.springframework.scheduling.support.CronTrigger;
import org.springframework.stereotype.Component;

import com.trianz.jump.JumpConstatnts;
import com.trianz.jump.dao.JobScheduleDAO;
import com.trianz.jump.model.Batch;
import com.trianz.jump.model.FulfilledCandidate;

@Component
public class JobScheduleService implements SchedulingConfigurer {

	@Autowired
	private JobScheduleDAO jobDao;

	@Autowired
	private EmailService emailService;

	Logger log = LoggerFactory.getLogger(JobScheduleService.class);

	@Override
	public void configureTasks(ScheduledTaskRegistrar taskRegistrar) {
		log.debug(">>> jobScheduleService.configureTasks()");
		// Fetches the latest cron expression from db & updates the cron job time
		taskRegistrar.setScheduler(Executors.newSingleThreadScheduledExecutor());
		taskRegistrar.addTriggerTask(
				this::selectedApplicantsJob,
				triggerContext -> {
					String cronEx = jobDao.getCronTime();
					CronTrigger cronTrigger = new CronTrigger(cronEx);
					return cronTrigger.nextExecution(triggerContext);
				}
		);
		log.debug("<<< jobScheduleService.configureTasks()");
	}
		
	public void selectedApplicantsJob() {
		log.debug("***********JOB STARTED****************");
		log.debug(">>> jobScheduleService.selectedApplicantsJob()");

		// GET THE START TIME OF THE LAST STATUS WITH - P, R, F
		Batch currentBatch = jobDao.getPendingJob();

		Timestamp endTime = new Timestamp(System.currentTimeMillis());

		try {
			// SET THE END TIME TO CURRENT TIME & STATUS TO RUNNING
			jobDao.updateCurrentBatch(currentBatch.getBatchId(), endTime, "R");

			// PROCESS THE SCHEDULED JOB
			boolean isProcessed = processApplicants(currentBatch.getStartTime(), endTime);

			// IF SUCCESS, SET THE STATUS TO SUCCESS & INSERT NEW ENTRY WITH START TIME AND
			// STATUS PENDING
			if (isProcessed) {
				jobDao.updateCurrentBatch(currentBatch.getBatchId(), endTime, "S");

				// INCREASE THE START TIME OF NEXT BATCH TO AVOID OVERLAP
				endTime = new Timestamp(endTime.getTime() + 1);
				jobDao.createNewBatch(endTime);
			}
			
			log.debug("<<< jobScheduleService.selectedApplicantsJob()");
			log.debug("************JOB COMPLETED**********");
			// IF EXCEPTION, SET THE STATUS TO FAIL
		} catch (Exception e) {
			log.error(e.getMessage());
			jobDao.updateCurrentBatch(currentBatch.getBatchId(), endTime, "F");
		}
	}

	private boolean processApplicants(Timestamp startTime, Timestamp endTime) {
		log.debug(">>> jobScheduleService.processApplicants()");
		try {
			// If Selected by JUMP
			// Get the list of TRs whose status updated to SELECTED b/w start & endtime
			List<String> jumpSelected = jobDao.getJumpSelectedCandidates(startTime, endTime);

			// Get the list of candidates whose TR status was updated to CANCELLED/FULFILLED
			// on Talento
			List<String> talentoSelected = jobDao.getTalentoUpdatedCandidates();
			jumpSelected.addAll(talentoSelected);

			if (!jumpSelected.isEmpty()) {
				startTime = new Timestamp(System.currentTimeMillis());
				
				// Update the status of other active applications of the above TRs to FULFILLED
				jumpSelected.forEach((item) -> jobDao.updateStatusToFulfilled(item));

				// Get the list of candidates whose status changed to FULFILLED & notify them
				List<FulfilledCandidate> fulfilledCandidates = jobDao.getFulfilledCandidates(startTime);

				// Send email to each candidate
				fulfilledCandidates.forEach((item) -> {
					log.debug("Application closed for: "+(item.toString()));
					String name = item.getEmail();
					name = name.replaceAll("((@.*)|[^a-zA-Z])+", " ").trim().replaceAll("\\s.*", "");
					name = name.substring(0, 1).toUpperCase() + name.substring(1);
					
					String subject2 = JumpConstatnts.FULL_FILLED_TEXT + " [ " + item.getTrId() + " ]";
					Map<String, Object> variables = new HashMap<>();
					variables.put("jobTitle", item.getPosition());
					variables.put("name", name);
					emailService.sendEmail(item.getEmail(), item.getEmail(), subject2, "fulfilled", variables);
				});
			}
			log.debug("<<< jobScheduleService.processApplicants()");
			return true;

		} catch (Exception e) {
			log.error(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
	}
}
