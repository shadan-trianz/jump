package com.trianz.jump.model;

public class HistoryFeedbackRecruiterDTO {
	
	private String feedback;
	private String lastUpdate;
	private String updatedBy;
	private double rating;
	
	public HistoryFeedbackRecruiterDTO(String feedback, String updatedBy, double rating, String lastUpdate) {
		super();
		this.feedback = feedback;
		this.updatedBy = updatedBy;
		this.lastUpdate = lastUpdate;
		this.setRating(rating);
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}
	
}
