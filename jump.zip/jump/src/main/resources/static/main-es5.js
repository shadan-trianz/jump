(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
    /***/
    0:
    /*!***************************!*\
      !*** multi ./src/main.ts ***!
      \***************************/

    /*! no static exports found */

    /***/
    function _(module, exports, __webpack_require__) {
      module.exports = __webpack_require__(
      /*! C:\Users\shadan.asad\git\jump\jump-ui\src\main.ts */
      "zUnb");
      /***/
    },

    /***/
    "4KHl":
    /*!***********************************!*\
      !*** ./src/app/graphql.module.ts ***!
      \***********************************/

    /*! exports provided: createApollo, GraphQLModule */

    /***/
    function KHl(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "createApollo", function () {
        return createApollo;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "GraphQLModule", function () {
        return GraphQLModule;
      });
      /* harmony import */


      var apollo_cache_inmemory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! apollo-cache-inmemory */
      "K/JX");
      /* harmony import */


      var _fragmentTypes_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./fragmentTypes.json */
      "BGFr");

      var _fragmentTypes_json__WEBPACK_IMPORTED_MODULE_1___namespace = /*#__PURE__*/__webpack_require__.t(
      /*! ./fragmentTypes.json */
      "BGFr", 1); // const uri = 'https://pulsedev.trianz.com/pulseMock';


      var uri = 'https://pulsedev.trianz.com/pulseapi'; // <-- add the URL of the GraphQL server here

      function createApollo(httpLink) {
        var fragmentMatcher = new apollo_cache_inmemory__WEBPACK_IMPORTED_MODULE_0__["IntrospectionFragmentMatcher"]({
          introspectionQueryResultData: _fragmentTypes_json__WEBPACK_IMPORTED_MODULE_1___namespace
        });
        return {
          link: httpLink.create({
            uri: uri
          }),
          cache: new apollo_cache_inmemory__WEBPACK_IMPORTED_MODULE_0__["InMemoryCache"]({
            fragmentMatcher: fragmentMatcher
          })
        };
      }

      var GraphQLModule = function GraphQLModule() {
        _classCallCheck(this, GraphQLModule);
      };
      /***/

    },

    /***/
    "AytR":
    /*!*****************************************!*\
      !*** ./src/environments/environment.ts ***!
      \*****************************************/

    /*! exports provided: environment */

    /***/
    function AytR(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "environment", function () {
        return environment;
      });

      var environment = {
        production: false,
        mode: "uat",
        projectName: "Pulse – The Trianz Digital Workplace",
        androidApp: "https://trianz365.sharepoint.com/:f:/s/TrianzPulse/EtWsiaGyWXxLhcQO5z0b2hgBlYKbTv-jXXHPxnW1RkfEQg?e=3cxXfV",
        iosApp: "https://apps.apple.com/in/app/pulse-digital-workplace/id1551907040",
        siteUrl: 'http://localhost:4200/',
        spHomeUrl: '',
        plannerapiUrl: "https://planneruat.trianz.com/plannerapi/",
        redirectUri: "http://localhost:4200/",
        apiUrl: "https://pulse.trianz.com/pulseapi/",
        SPUrl: "https://trianz365.sharepoint.com/",
        baseUrl: "https://pulseuat.trianz.com/",
        pulseUrl: "sites/Pulseuat",
        wGridSpaceId: '2827aec3-e6c9-4daa-ab79-5aba4a1b9ffa',
        wGridCompanyCode: 'trianz',
        wGridAuthUrl: 'https://pulseworkgrid.azurewebsites.net',
        wGridClientId: '437bc102-5a7a-45db-a3f2-942e2062c534',
        wGridTenantId: 'a27f6b6b-dc28-48c2-a138-ddf0f11455f1',
        wGridVersion: 'v2',
        wGridToolBarId: 'Test',
        wGridDisabled: false,
        plusUrl: "https://uat-plus.trianz.com/",
        auth: {
          clientId: "437bc102-5a7a-45db-a3f2-942e2062c534",
          authority: "https://login.microsoftonline.com/a27f6b6b-dc28-48c2-a138-ddf0f11455f1",
          redirectUri: "http://localhost:4200/",
          loadFrameTimeout: 10000
        },
        cache: {
          cacheLocation: "localStorage",
          storeAuthStateInCookie: false
        },
        blobConfig: {
          account: "spapulseuatwus",
          container: "resources",
          sas: "sp=racwdl&st=2022-08-08T10:56:36Z&se=2023-12-21T18:56:36Z&sip=0.0.0.0-255.255.255.255&spr=https&sv=2021-06-08&sr=c&sig=lr5p%2B6i5mbwRqpXo5fmLAi8Ehz9SgvEOgn9yvswVn1M%3D"
        }
      };
      /***/
    },

    /***/
    "B8j8":
    /*!*******************************************!*\
      !*** ./src/app/providers/jump.service.ts ***!
      \*******************************************/

    /*! exports provided: JumpService */

    /***/
    function B8j8(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JumpService", function () {
        return JumpService;
      });
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var JumpService = /*#__PURE__*/function () {
        function JumpService(http) {
          _classCallCheck(this, JumpService);

          this.http = http;
          this.apiUrl = '/jump/'; //'http://localhost:8080/jump/'

          this.jobDetailsSubject = new rxjs__WEBPACK_IMPORTED_MODULE_1__["BehaviorSubject"](null);
          this.jobDetails$ = this.jobDetailsSubject.asObservable();
          this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_1__["Subject"]();
        }

        _createClass(JumpService, [{
          key: "getDemo",
          value: function getDemo() {
            var headers = new _angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpHeaders"]().set('Access-Control-Allow-Origin', 'https://jumpuat.trianz.com');
            return this.http.get('https://jumpuat.trianz.com/jump/tr/active', {
              headers: headers
            });
          } // TR related APIS

        }, {
          key: "getActiveData",
          value: function getActiveData() {
            return this.http.get(this.apiUrl + 'tr');
          }
        }, {
          key: "getDashboardData",
          value: function getDashboardData() {
            return this.http.get(this.apiUrl + 'employee/roles');
          }
        }, {
          key: "getNotesHistory",
          value: function getNotesHistory(trId, emailId) {
            return this.http.get(this.apiUrl + 'recruiter/history?trId=' + trId + '&email=' + emailId);
          }
        }, {
          key: "getTrFilteredData",
          value: function getTrFilteredData(page, user, statusId) {
            var baseUrl = this.apiUrl + 'tr?page=' + page;

            if (user != 'all') {
              baseUrl += '&assignedTo=' + user;
            }

            if (statusId != 0) {
              baseUrl += '&status=' + statusId;
            }

            return this.http.get(baseUrl);
          }
        }, {
          key: "getTrSearchData",
          value: function getTrSearchData(page, skill, searchTerm) {
            return this.http.get(this.apiUrl + 'tr?page=' + page + '&search=' + skill + '&key=' + encodeURIComponent(searchTerm));
          }
        }, {
          key: "getImportTrDetails",
          value: function getImportTrDetails(trId) {
            return this.http.get(this.apiUrl + 'tr/import/' + trId);
          }
        }, {
          key: "getTrDataById",
          value: function getTrDataById(trId) {
            return this.http.get(this.apiUrl + 'tr/' + trId);
          }
        }, {
          key: "createTR",
          value: function createTR(trData) {
            return this.http.post("".concat(this.apiUrl, "tr"), trData);
          }
        }, {
          key: "updateTR",
          value: function updateTR(trData) {
            return this.http.put("".concat(this.apiUrl, "tr"), trData);
          }
        }, {
          key: "getApplicationsListByTr",
          value: function getApplicationsListByTr(trId) {
            return this.http.get("".concat(this.apiUrl, "recruiter/") + trId);
          }
        }, {
          key: "updateNotes",
          value: function updateNotes(trData) {
            return this.http.put("".concat(this.apiUrl, "recruiter/update-application"), trData);
          } // open roles
          // getActiveRolesData(email_id): Observable<any> {
          //   return this.http.get<any>(this.apiUrl+'tr/active?email='+email_id);
          // }

        }, {
          key: "getActiveRolesData",
          value: function getActiveRolesData(page) {
            return this.http.get("".concat(this.apiUrl, "tr/active?page=").concat(page));
          }
        }, {
          key: "getRolesSearchData",
          value: function getRolesSearchData(page, skill, searchTerm) {
            return this.http.get(this.apiUrl + 'tr/active?page=' + page + '&search=' + skill + '&key=' + encodeURIComponent(searchTerm));
          } // employee related api

        }, {
          key: "getEmployeeData",
          value: function getEmployeeData() {
            return this.http.get(this.apiUrl + 'employee');
          }
        }, {
          key: "applyJob",
          value: function applyJob(userData) {
            return this.http.post("".concat(this.apiUrl, "employee/apply"), userData);
          }
        }, {
          key: "uploadAttachment",
          value: function uploadAttachment(formData) {
            return this.http.post("".concat(this.apiUrl, "employee/profile"), formData);
          }
        }, {
          key: "downloadAttachment",
          value: function downloadAttachment(empId) {
            return this.http.get(this.apiUrl + 'employee/profile/' + empId);
          }
        }, {
          key: "getTalento",
          value: function getTalento() {
            return this.http.get('https://talento.trianz.com/');
          }
        }, {
          key: "setJobDetails",
          value: function setJobDetails(details) {
            this.destroy$.next();
            this.destroy$.complete();
            this.jobDetailsSubject.next(details);
          }
        }]);

        return JumpService;
      }();

      JumpService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵdefineInjectable"]({
        factory: function JumpService_Factory() {
          return new JumpService(_angular_core__WEBPACK_IMPORTED_MODULE_2__["ɵɵinject"](_angular_common_http__WEBPACK_IMPORTED_MODULE_0__["HttpClient"]));
        },
        token: JumpService,
        providedIn: "root"
      });
      /***/
    },

    /***/
    "BGFr":
    /*!************************************!*\
      !*** ./src/app/fragmentTypes.json ***!
      \************************************/

    /*! exports provided: __schema, default */

    /***/
    function BGFr(module) {
      module.exports = JSON.parse("{\"__schema\":{\"types\":[{\"kind\":\"UNION\",\"name\":\"ErrorSchemaTest\",\"possibleTypes\":[{\"name\":\"ErrorTest\"},{\"name\":\"ErrorDetails\"}]}]}}");
      /***/
    },

    /***/
    "HJCg":
    /*!******************************************************!*\
      !*** ./src/app/job-details/job-details.component.ts ***!
      \******************************************************/

    /*! exports provided: JobDetailsComponent */

    /***/
    function HJCg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JobDetailsComponent", function () {
        return JobDetailsComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! sweetalert2 */
      "PSD3");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_3__);
      /* harmony import */


      var _ascii_validator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../ascii.validator */
      "PGEX");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs */
      "qCKp");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! rxjs/operators */
      "kU1M");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! moment */
      "wd/R");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_7__);

      var JobDetailsComponent = /*#__PURE__*/function () {
        function JobDetailsComponent(fb, activatedroute, router, utility, jumpService) {
          _classCallCheck(this, JobDetailsComponent);

          this.fb = fb;
          this.activatedroute = activatedroute;
          this.router = router;
          this.utility = utility;
          this.jumpService = jumpService;
          this.applyNowModelClose = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
          this.closeApplyButton = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
          this.visibleItems = [];
          this.pages = [];
          this.searchTerm = '';
          this.currentPage = 1;
          this.itemsPerPage = 10;
          this.selectedJob = [];
          this.statusOptions = [];
          this.selectedStatuses = new Set();
          this.isDialogOpen = false;
          this.isApply = false;
          this.candidates = [];
          this.filteredCandidates = [];
          this.showJobDetails = true;
          this.fileName = "";
          this.destroy$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
          this.notesHistory = [];
          this.statusHistory = [];
          this.getMyProfile();
        }

        _createClass(JobDetailsComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            var _a, _b;

            this.frmEditProfile = this.fb.group({
              fname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              // lname: new FormControl(),
              email: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              phoneNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              location: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              primaryskill: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              secondaryskill: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              experience: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              trianzExperience: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](),
              fileName: [(_a = this.file) === null || _a === void 0 ? void 0 : _a.name]
            });
            this.filteredCandidates = this.candidates;

            if (this.jobDetails) {
              this.jobId = this.jobDetails.link;
              this.getJobs(this.jobId);

              if (((_b = this.jobDetails) === null || _b === void 0 ? void 0 : _b.category) == 'dashboard') {
                this.getApplicationsList(this.jobId);
              }

              this.selectedCategory = this.jobDetails.category;
            }

            this.selectedCategory = localStorage.getItem('category');
            this.jumpService.jobDetails$.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["takeUntil"])(this.destroy$)).subscribe(function (details) {
              if (details != null) {
                _this.getJobs(details);
              }
            });
          }
        }, {
          key: "ngOnChanges",
          value: function ngOnChanges(changes) {
            var _a;

            if ((_a = changes.applyNowBtnClick) === null || _a === void 0 ? void 0 : _a.currentValue) {
              this.createForm();
              $("#application").modal("show");
            }
          }
        }, {
          key: "getFormattedDate",
          value: function getFormattedDate(currentDate) {
            return moment__WEBPACK_IMPORTED_MODULE_7___default()(currentDate, 'DD-MM-YYYY HH:mm:ss').format('DD-MM-YYYY hh:mm A');
          }
        }, {
          key: "closeModal",
          value: function closeModal() {
            this.file = "";
            this.fileName = "";
            this.warningMessage = "";
            this.frmEditProfile.controls["fileName"].reset();
            this.fileInput.nativeElement.value = '';
            this.applyNowModelClose.emit(false);
          }
        }, {
          key: "createForm",
          value: function createForm() {
            var _this2 = this;

            var userInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";

            var _a;

            userInfo = this.userInfo;
            this.frmEditProfile = this.fb.group({
              fname: [userInfo.name, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_4__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(99)]],
              // lname: [userInfo.lastname, [Validators.required, asciiValidator(),Validators.maxLength(99)]],
              email: [userInfo.email, [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
              phoneNumber: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].pattern(/^[5-9]\d{9}$/)]],
              location: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(99)]],
              experience: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].max(99)]],
              trianzExperience: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].max(99), this.trianzExperienceValidator()]],
              primaryskill: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_4__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(500)]],
              secondaryskill: ["", [Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_4__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(500)]],
              fileName: [(_a = this.file) === null || _a === void 0 ? void 0 : _a.name, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"] === null || _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"] === void 0 ? void 0 : _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            });
            this.frmEditProfile.get('experience').valueChanges.subscribe(function () {
              _this2.frmEditProfile.get('trianzExperience').updateValueAndValidity();
            });
          }
        }, {
          key: "trianzExperienceValidator",
          value: function trianzExperienceValidator() {
            var _this3 = this;

            return function (control) {
              var _a, _b;

              var totalExperience = (_b = (_a = _this3.frmEditProfile) === null || _a === void 0 ? void 0 : _a.get('experience')) === null || _b === void 0 ? void 0 : _b.value;
              var trianzExperience = control.value;
              return trianzExperience > totalExperience ? {
                experienceMismatch: true
              } : null;
            };
          }
        }, {
          key: "getMyProfile",
          value: function getMyProfile() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var userInfo;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      userInfo = localStorage.getItem('userDetails');
                      this.userInfo = JSON.parse(userInfo);
                      if (this.userInfo) this.createForm();

                    case 3:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "getJobs",
          value: function getJobs(jobId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this4 = this;

              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      this.loading = true;
                      this.jumpService.getTrDataById(jobId).subscribe(function (data) {
                        var _a;

                        _this4.selectedJob = [];
                        var trsArray = data === null || data === void 0 ? void 0 : data.data;

                        if (trsArray) {
                          trsArray.primarySkillsArray = (_a = trsArray === null || trsArray === void 0 ? void 0 : trsArray.primarySkills) === null || _a === void 0 ? void 0 : _a.split(',').map(function (skill) {
                            return skill.trim();
                          }); // trsArray.DesirableSkills = trsArray?.gthSkills?.split(',').map(skill => skill.trim());

                          _this4.selectedJob = trsArray;
                        }

                        _this4.loading = false;
                      }, function (error) {
                        _this4.loading = false;
                        console.error('Error fetching data', error);
                      });

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "uploadFile",
          value: function uploadFile(event) {
            this.imageFlag = true;
            var reader = new FileReader();
            var file = event.target.files[0];
            this.file = file;
            var fileExtension = file.name.split('.').pop().toLowerCase();

            if (file && fileExtension == 'pptx' || fileExtension == 'ppt') {
              this.warningMessage = "";

              if (event.target.files && event.target.files[0]) {
                reader.readAsDataURL(file);

                reader.onload = function () {};

                this.uploadResume();
              }
            } else {
              this.warningMessage = "Only PPT files are allowed.";
              this.frmEditProfile.controls["fileName"].reset();
              this.file = "";
            }
          }
        }, {
          key: "openFileInput",
          value: function openFileInput() {
            var fileInput = document.querySelector('input[type="file"]');
            fileInput === null || fileInput === void 0 ? void 0 : fileInput.click();
          }
        }, {
          key: "uploadResume",
          value: function uploadResume() {
            var _this5 = this;

            var formData = new FormData();
            formData.append('file', this.file);
            this.jumpService.uploadAttachment(formData).subscribe(function (response) {
              sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                icon: 'success',
                title: "File uploaded successfully!"
              });

              _this5.frmEditProfile.controls["fileName"].setValue(_this5.file.name);

              _this5.fileName = response === null || response === void 0 ? void 0 : response.fileName;
            }, function (error) {
              var _a;

              sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                icon: 'error',
                title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
              });

              _this5.frmEditProfile.controls["fileName"].reset();

              _this5.file = "";
            });
          }
        }, {
          key: "closeJobRole",
          value: function closeJobRole(home) {
            $("#welcome").modal("hide");
            $("#application").modal("hide");
            this.closeApplyButton.emit(false);

            if (home) {
              this.file = "";
              this.fileName = "";
              this.isApply = true;
            }
          }
        }, {
          key: "updateJob",
          value: function updateJob() {
            var _a;

            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var jobId, title, firstName, lastName, email, location, experience, phoneNumber;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      if ((_a = this.file) === null || _a === void 0 ? void 0 : _a.name) {
                        this.warningMessage = "";
                        jobId = this.selectedJob.ID;
                        title = "Node.js";
                        firstName = this.frmEditProfile.controls["fname"].value; // lastName=this.frmEditProfile.controls["lname"].value;

                        email = this.frmEditProfile.controls["email"].value;
                        location = this.frmEditProfile.controls["location"].value;
                        experience = this.frmEditProfile.controls["experience"].value;
                        phoneNumber = this.frmEditProfile.controls["phoneNumber"].value;
                      } else {
                        this.warningMessage = "Please attach the resume";
                      }

                    case 1:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "saveJob",
          value: function saveJob() {
            var _this6 = this;

            this.loading = true;
            var updateData = {
              "trId": this.jobId,
              "email": this.frmEditProfile.controls["email"].value,
              "empName": this.frmEditProfile.controls["fname"].value,
              "mobile": this.frmEditProfile.controls["phoneNumber"].value,
              "trianzExperience": this.frmEditProfile.controls["trianzExperience"].value,
              "totalExperience": this.frmEditProfile.controls["experience"].value,
              "location": this.frmEditProfile.controls["location"].value,
              "primarySkills": this.frmEditProfile.controls["primaryskill"].value,
              "secondarySkills": this.frmEditProfile.controls["secondaryskill"].value
            };
            this.jumpService.applyJob(updateData).subscribe(function (response) {
              _this6.loading = false;
              $("#application").modal("hide");
              $("#welcome").modal("show");

              _this6.frmEditProfile.controls["fileName"].reset();

              _this6.file = "";
            }, function (error) {
              var _a;

              sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                icon: 'error',
                title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
              });
              _this6.loading = false;
            });
          } // candidates list

        }, {
          key: "applyFilter",
          value: function applyFilter() {
            var _this7 = this;

            this.filteredCandidates = this.candidates.filter(function (candidate) {
              return _this7.selectedStatuses.size === 0 || _this7.selectedStatuses.has(candidate.status);
            });
          }
        }, {
          key: "onStatusChange",
          value: function onStatusChange(status, isChecked) {
            if (isChecked) {
              this.selectedStatuses.add(status);
            } else {
              this.selectedStatuses["delete"](status);
            }

            this.applyFilter();
          }
        }, {
          key: "downloadDocument",
          value: function downloadDocument(email) {
            var url = email ? 'https://jumpuat.trianz.com/jump/recruiter/profile/' + email : 'https://jumpuat.trianz.com/jump/employee/profile';
            var anchor = document.createElement('a');
            anchor.href = url;
            anchor.download = '';
            anchor.click();
          }
        }, {
          key: "openStatusDialog",
          value: function openStatusDialog(item) {
            this.currentItem = item;
            this.selectedStatus = item.statusId;
            this.email = item === null || item === void 0 ? void 0 : item.email;
            this.isDialogOpen = true;
          }
        }, {
          key: "cancel",
          value: function cancel() {
            this.isDialogOpen = false;
          }
        }, {
          key: "changeStatus",
          value: function changeStatus() {
            var _this8 = this;

            if (this.currentItem.statusId == this.selectedStatus) {
              this.isDialogOpen = false;
            } else {
              var trData = {
                "trId": this.jobId,
                "email": this.email,
                "statusId": this.selectedStatus
              };
              this.jumpService.updateNotes(trData).subscribe(function (response) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                  icon: 'success',
                  title: 'Status changed successfully!'
                });
                _this8.email = '';

                _this8.getApplicationsList(_this8.jobId);

                _this8.isDialogOpen = false;
              }, function (error) {
                var _a;

                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                  icon: 'error',
                  title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
                });
              });
            }
          }
        }, {
          key: "closeNotes",
          value: function closeNotes() {
            $("#notes").modal("hide");
          }
        }, {
          key: "closeHistoryModal",
          value: function closeHistoryModal() {
            $("#history").modal("hide");
          }
        }, {
          key: "clickOpenCarousel",
          value: function clickOpenCarousel() {
            this.showJobDetails = !this.showJobDetails;
          } // pagiation and search

        }, {
          key: "search",
          value: function search() {
            this.currentPage = 1;
            this.updatePagination();
          }
        }, {
          key: "updatePagination",
          value: function updatePagination() {
            this.totalPages = Math.ceil(this.candidates.length / this.itemsPerPage);
            this.pages = Array.from({
              length: this.totalPages
            }, function (_, i) {
              return i + 1;
            });
            this.updateVisibleItems();
          }
        }, {
          key: "updateVisibleItems",
          value: function updateVisibleItems() {
            var startIndex = (this.currentPage - 1) * this.itemsPerPage;
            var endIndex = startIndex + this.itemsPerPage;
            this.startItem = startIndex + 1;
            this.endItem = Math.min(endIndex, this.candidates.length);
            this.visibleItems = this.candidates.slice(startIndex, endIndex);
          }
        }, {
          key: "setPage",
          value: function setPage(page) {
            this.currentPage = page;
            this.updateVisibleItems();
          }
        }, {
          key: "nextPage",
          value: function nextPage() {
            if (this.currentPage < this.totalPages) {
              this.currentPage++;
              this.updateVisibleItems();
            }
          }
        }, {
          key: "prevPage",
          value: function prevPage() {
            if (this.currentPage > 1) {
              this.currentPage--;
              this.updateVisibleItems();
            }
          }
        }, {
          key: "getApplicationsList",
          value: function getApplicationsList(jobId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var _this9 = this;

              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      this.jumpService.getApplicationsListByTr(jobId).subscribe(function (data) {
                        var colorArr = ['#fce5cd', '#d9ead3', '#c9daf8', '#f4cccc', '#e6e6e6', '#fff2cc', '#d9d2e9'];
                        var textColors = ['#e69138', '#6aa84f', '#3c78d8', '#cc0000', '#999999', '#e69138', '#6a329f'];
                        var statusColorMap = {
                          1: colorArr[0],
                          10: colorArr[1],
                          20: colorArr[2],
                          30: colorArr[3],
                          40: colorArr[4],
                          50: colorArr[5],
                          60: colorArr[6]
                        };
                        var statusTextColorMap = {
                          1: textColors[0],
                          10: textColors[1],
                          20: textColors[2],
                          30: textColors[3],
                          40: textColors[4],
                          50: textColors[5],
                          60: textColors[6]
                        };
                        data.data.forEach(function (application) {
                          application.color = statusColorMap[application.statusId];
                          application.textColor = statusTextColorMap[application.statusId];
                        });
                        _this9.statusOptions = data === null || data === void 0 ? void 0 : data.appStatusList;
                        _this9.candidates = data.data;

                        _this9.search();
                      });

                      (function (error) {
                        _this9.loading = false;
                        console.error('Error fetching data', error);
                      });

                    case 2:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "openNotes",
          value: function openNotes(data) {
            this.notesComments = data.notes;
            this.changeComment = data === null || data === void 0 ? void 0 : data.notes;
            this.email = data.email;
          }
        }, {
          key: "saveNotes",
          value: function saveNotes() {
            var _this10 = this;

            if (this.changeComment == this.notesComments) {
              $("#notes").modal("hide");
            } else {
              var trData = {
                "trId": this.jobId,
                "email": this.email,
                "notes": this.notesComments
              };
              this.jumpService.updateNotes(trData).subscribe(function (response) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                  icon: 'success',
                  title: 'Notes  updated successfully!'
                });
                _this10.notesComments = '';

                _this10.getApplicationsList(_this10.jobId);

                $("#notes").modal("hide");
              }, function (error) {
                var _a;

                console.error('Error creating TR', error);
                sweetalert2__WEBPACK_IMPORTED_MODULE_3___default.a.fire({
                  icon: 'error',
                  title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
                });
              });
            }
          }
        }, {
          key: "getDynamicHref",
          value: function getDynamicHref(trNumber) {
            return "https://talento.trianz.com/ProposeAssociate/ProposeAssociate/".concat(trNumber, "?hrrfno=").concat(trNumber);
          }
        }, {
          key: "getNotesHistory",
          value: function getNotesHistory(candidate) {
            var _this11 = this;

            this.loading = true;
            this.candidateName = candidate.empName;
            this.jumpService.getNotesHistory(this.jobId, candidate === null || candidate === void 0 ? void 0 : candidate.email).subscribe(function (data) {
              _this11.notesHistory = data === null || data === void 0 ? void 0 : data.notesHist;
              _this11.statusHistory = data === null || data === void 0 ? void 0 : data.statusHist;
              _this11.loading = false;
            }, function (error) {
              _this11.loading = false;
            });
          }
        }, {
          key: "ngOnDestroy",
          value: function ngOnDestroy() {
            this.destroy$.next();
            this.destroy$.complete();
          }
        }, {
          key: "openEmpData",
          value: function openEmpData(data) {
            this.empData = data;
          }
        }, {
          key: "closeEmpDataModal",
          value: function closeEmpDataModal() {
            this.empData = "";
            $("#candidateModal").modal("hide");
          }
        }, {
          key: "closeJob",
          value: function closeJob() {
            this.file = "";
            this.fileName = "";
            this.warningMessage = "";
            this.frmEditProfile.controls["fileName"].reset();
            this.fileInput.nativeElement.value = '';
            this.applyNowModelClose.emit(false);
            $("#application").modal("hide");
          }
        }]);

        return JobDetailsComponent;
      }();
      /***/

    },

    /***/
    "MAAT":
    /*!******************************************************************!*\
      !*** ./src/app/job-mobility/job-mobility.component.ngfactory.js ***!
      \******************************************************************/

    /*! exports provided: RenderType_JobMobilityComponent, View_JobMobilityComponent_0, View_JobMobilityComponent_Host_0, JobMobilityComponentNgFactory */

    /***/
    function MAAT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RenderType_JobMobilityComponent", function () {
        return RenderType_JobMobilityComponent;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_JobMobilityComponent_0", function () {
        return View_JobMobilityComponent_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_JobMobilityComponent_Host_0", function () {
        return View_JobMobilityComponent_Host_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JobMobilityComponentNgFactory", function () {
        return JobMobilityComponentNgFactory;
      });
      /* harmony import */


      var _job_mobility_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./job-mobility.component.scss.shim.ngstyle */
      "vEWE");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../../../node_modules/@angular/material/tabs/index.ngfactory */
      "Pwwu");
      /* harmony import */


      var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/material/tabs */
      "M9ds");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "omvX");
      /* harmony import */


      var _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../job-details/job-details.component.ngfactory */
      "sPRM");
      /* harmony import */


      var _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../job-details/job-details.component */
      "HJCg");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _providers_utility_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! ../providers/utility.service */
      "lxz4");
      /* harmony import */


      var _providers_jump_service__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! ../providers/jump.service */
      "B8j8");
      /* harmony import */


      var _job_mobility_component__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! ./job-mobility.component */
      "SDTg");
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles_JobMobilityComponent = [_job_mobility_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];

      var RenderType_JobMobilityComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({
        encapsulation: 0,
        styles: styles_JobMobilityComponent,
        data: {
          "animation": [{
            type: 7,
            name: "detailExpand",
            definitions: [{
              type: 0,
              name: "collapsed",
              styles: {
                type: 6,
                styles: {
                  height: "0px",
                  minHeight: "0",
                  display: "none"
                },
                offset: null
              },
              options: undefined
            }, {
              type: 0,
              name: "expanded",
              styles: {
                type: 6,
                styles: {
                  height: "*"
                },
                offset: null
              },
              options: undefined
            }, {
              type: 1,
              expr: "expanded <=> collapsed",
              animation: [{
                type: 4,
                styles: null,
                timings: "25ms cubic-bezier(0.4, 0.0, 0.2, 1)"
              }],
              options: null
            }],
            options: {}
          }]
        }
      });

      function View_JobMobilityComponent_1(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "tooltip-text"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["Logged in as : ", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.userName;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_3(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.changeTabClick(_v.parent.context.index) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.context.$implicit.label;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_6(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "dropdown-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.selectOption(_v.context.$implicit, "dashboard") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, [" ", " "]))], null, function (_ck, _v) {
          var currVal_0 = _v.context.$implicit.label;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_7(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_9(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-down"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_10(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_11(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 5, "li", [["class", "nav-item"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 4, "a", [["aria-controls", "view"], ["aria-selected", "false"], ["class", "nav-link"], ["data-toggle", "tab"], ["id", "view-vertical-tab"], ["role", "tab"], ["style", "padding:10px;"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](3, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "span", [["style", "padding: 0px;\n                                  width: 80px;\n                                  white-space: normal; word-break: break-all;\n                                  overflow: hidden;\n                                  text-overflow: ellipsis;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = "nav-link";

          var currVal_1 = _ck(_v, 3, 0, _co.viewDashboardDetails == 2);

          _ck(_v, 2, 0, currVal_0, currVal_1);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_2 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 4, 0, currVal_2);

          var currVal_3 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 5, 0, currVal_3);
        });
      }

      function View_JobMobilityComponent_13(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" First Level Panel: "]))], null, null);
      }

      function View_JobMobilityComponent_14(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, [" ", " "]))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.parent.context.$implicit == null ? null : _v.parent.parent.context.$implicit.firstLevelTechPanel;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_15(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Second Level Panel: "]))], null, null);
      }

      function View_JobMobilityComponent_16(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, [" ", " "]))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.parent.context.$implicit == null ? null : _v.parent.parent.context.$implicit.secondLevelTechPanel;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_17(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "row mt-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "col-11"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "textarea", [["class", "form-control input-div mb-2"], ["cols", "30"], ["readonly", ""], ["rows", "15"], ["style", "background-color: #ffffff;font-size: 13px;width: 104%;border: none;padding: 0px;resize: none;"]], [[8, "value", 0]], null, null, null, null))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.parent.context.$implicit == null ? null : _v.parent.parent.context.$implicit.jobDescription;

          _ck(_v, 2, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_12(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 32, "div", [["class", ""], ["style", "padding-top: 5px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 31, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 24, "div", [["class", "col-3"], ["style", "height: 360px;overflow-y:auto"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skills: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "span", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](6, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Project Name: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](10, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Account Name: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](14, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Practice: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](18, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_13)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](20, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_14)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](22, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_15)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](24, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_16)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](26, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 5, "div", [["class", "d-flex col-10 justify-content-between"], ["style", "margin-left: -34px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Description :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_17)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](32, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var currVal_4 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.firstLevelTechPanel;

          _ck(_v, 20, 0, currVal_4);

          var currVal_5 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.firstLevelTechPanel;

          _ck(_v, 22, 0, currVal_5);

          var currVal_6 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.secondLevelTechPanel;

          _ck(_v, 24, 0, currVal_6);

          var currVal_7 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.secondLevelTechPanel;

          _ck(_v, 26, 0, currVal_7);

          var currVal_8 = (_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.jobDescription) || (_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.jobDescription) != null;

          _ck(_v, 32, 0, currVal_8);
        }, function (_ck, _v) {
          var currVal_0 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.primarySkills;

          _ck(_v, 6, 0, currVal_0);

          var currVal_1 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.projectName;

          _ck(_v, 10, 0, currVal_1);

          var currVal_2 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.accountName;

          _ck(_v, 14, 0, currVal_2);

          var currVal_3 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.practice;

          _ck(_v, 18, 0, currVal_3);
        });
      }

      function View_JobMobilityComponent_20(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 5, "div", [], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.openStatusDialog(_v.parent.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 4, "span", [["class", "badge badge-open status status-dialog"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgStyle"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          ngStyle: [0, "ngStyle"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](3, {
          "background-color": 0,
          "color": 1
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 0, "i", [["class", "bx bx-edit status-edit status-dialog"]], null, null, null, null, null))], function (_ck, _v) {
          var currVal_0 = _ck(_v, 3, 0, _v.parent.context.$implicit.color, _v.parent.context.$implicit.textColor);

          _ck(_v, 2, 0, currVal_0);
        }, function (_ck, _v) {
          var currVal_1 = _v.parent.context.$implicit.statusName;

          _ck(_v, 4, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_22(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, "option", [], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 147456, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgSelectOption"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"]]], {
          value: [0, "value"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 147456, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_x"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], [8, null]], {
          value: [0, "value"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](3, null, ["", ""]))], function (_ck, _v) {
          var currVal_0 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_id;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_id;

          _ck(_v, 2, 0, currVal_1);
        }, function (_ck, _v) {
          var currVal_2 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_name;

          _ck(_v, 3, 0, currVal_2);
        });
      }

      function View_JobMobilityComponent_21(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 7, "select", [["class", "status-dialog"], ["style", "height: 32px;"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "change"], [null, "blur"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("change" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 1).onChange($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 1).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_2 = (_co.selectedStatus = $event) !== false;
            ad = pd_2 && ad;
          }

          if ("change" === en) {
            var pd_3 = _co.changeStatus() !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](3, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_22)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_7 = _co.selectedStatus;

          _ck(_v, 3, 0, currVal_7);

          var currVal_8 = _co.statusOptions;

          _ck(_v, 7, 0, currVal_8);
        }, function (_ck, _v) {
          var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassUntouched;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassTouched;

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassPristine;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassDirty;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassValid;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassInvalid;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).ngClassPending;

          _ck(_v, 0, 0, currVal_0, currVal_1, currVal_2, currVal_3, currVal_4, currVal_5, currVal_6);
        });
      }

      function View_JobMobilityComponent_19(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 22, "tr", [], [[2, "last-item", null]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "td", [["class", "display-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "a", [["href", "javascript:void(0)"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.openEmpData(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](3, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "td", [["class", "secondary-skill-ellipsis"], ["style", "width: 159px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 1, "td", [["class", "secondary-skill-ellipsis"], ["style", "width: 178px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](7, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](9, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 1, "td", [["style", "padding-left: 30px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](11, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 1, "td", [["style", "padding-left: 30px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](13, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 4, "td", [["style", "width:164px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_20)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](16, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_21)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](18, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 3, "td", [["style", "width: 40px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 2, "div", [["class", "icon-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "div", [["class", "icon-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.downloadDocument(_v.context.$implicit.email) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 0, "i", [["class", "bx bx-download icon"], ["data-placement", "bottom"], ["data-toggle", "tooltip"], ["style", "color: #212529f0;"], ["title", "Download Profile"]], null, null, null, null, null))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_9 = _co.currentItem != _v.context.$implicit;

          _ck(_v, 16, 0, currVal_9);

          var currVal_10 = _co.currentItem == _v.context.$implicit;

          _ck(_v, 18, 0, currVal_10);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.index == _co.visibleItems.length - 1;

          _ck(_v, 0, 0, currVal_0);

          var currVal_1 = _v.context.$implicit.empName;

          _ck(_v, 3, 0, currVal_1);

          var currVal_2 = _v.context.$implicit.primarySkills;

          _ck(_v, 4, 0, currVal_2);

          var currVal_3 = _v.context.$implicit.primarySkills;

          _ck(_v, 5, 0, currVal_3);

          var currVal_4 = _v.context.$implicit.secondarySkills;

          _ck(_v, 6, 0, currVal_4);

          var currVal_5 = _v.context.$implicit.secondarySkills;

          _ck(_v, 7, 0, currVal_5);

          var currVal_6 = _v.context.$implicit == null ? null : _v.context.$implicit.location;

          _ck(_v, 9, 0, currVal_6);

          var currVal_7 = _v.context.$implicit.totalExperience;

          _ck(_v, 11, 0, currVal_7);

          var currVal_8 = _v.context.$implicit == null ? null : _v.context.$implicit.trianzExperience;

          _ck(_v, 13, 0, currVal_8);
        });
      }

      function View_JobMobilityComponent_23(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "tr", [["class", "m-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "p", [["class", "m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["No Records found"]))], null, null);
      }

      function View_JobMobilityComponent_25(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "li", [["class", "page-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.setApplyPage(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](2, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 3, "span", [], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          ngClass: [0, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](5, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](6, null, ["", ""]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = "page-item";

          var currVal_1 = _ck(_v, 2, 0, _co.currentApplicationsPage === _v.context.$implicit);

          _ck(_v, 1, 0, currVal_0, currVal_1);

          var currVal_2 = _ck(_v, 5, 0, _co.currentApplicationsPage === _v.context.$implicit);

          _ck(_v, 4, 0, currVal_2);
        }, function (_ck, _v) {
          var currVal_3 = _v.context.$implicit;

          _ck(_v, 6, 0, currVal_3);
        });
      }

      function View_JobMobilityComponent_24(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 10, "ul", [["class", "pagination"], ["style", "margin-top: 4px;margin-bottom: 0px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "li", [["class", "page-item prev-page"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.prevApplyPage() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](3, {
          "disabled": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 0, "i", [["class", "bx bx-chevron-left"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_25)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 3, "li", [["class", "page-item next-page"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](8, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](9, {
          "disabled": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.nextApplyPage() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = "page-item prev-page";

          var currVal_1 = _ck(_v, 3, 0, _co.currentApplicationsPage === 1);

          _ck(_v, 2, 0, currVal_0, currVal_1);

          var currVal_2 = _co.pages;

          _ck(_v, 6, 0, currVal_2);

          var currVal_3 = "page-item next-page";

          var currVal_4 = _ck(_v, 9, 0, _co.currentApplicationsPage === _co.totalPages || _co.totalPages == 0);

          _ck(_v, 8, 0, currVal_3, currVal_4);
        }, null);
      }

      function View_JobMobilityComponent_18(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 27, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 26, "div", [["class", "mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 23, "table", [["class", "table m-0"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 17, "thead", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 16, "tr", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Total Exp"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Exp"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "th", [["style", "padding-left: 52px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Status "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "th", [["style", "padding-left:2px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Profile"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 4, "tbody", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_19)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](23, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_23)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](25, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_24)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](27, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.applicationsList;

          _ck(_v, 23, 0, currVal_0);

          var currVal_1 = !(_co.applicationsList == null ? null : _co.applicationsList.length);

          _ck(_v, 25, 0, currVal_1);

          var currVal_2 = !_co.isDialogOpen && (_co.candidates == null ? null : _co.candidates.length) > 5;

          _ck(_v, 27, 0, currVal_2);
        }, null);
      }

      function View_JobMobilityComponent_28(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.candidateTabClick(_v.parent.context.index) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.context.$implicit.label;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_30(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applied Date : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_29(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 42, "div", [["class", "row"], ["style", "margin-top: 10px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Name : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Email : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](10, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Mobile : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](15, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](16, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](20, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Total Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](25, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 3, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](30, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_30)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](32, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](33, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](34, 0, null, null, 1, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](37, 0, null, null, 0, "textarea", [["class", "form-control text-desc"], ["cols", "3"], ["readonly", ""], ["rows", "2"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 1, "div", [["class", "mt-2"], ["style", "font-size: 13px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](41, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 0, "textarea", [["class", "form-control text-desc"], ["cols", "3"], ["readonly", ""], ["rows", "2"]], [[8, "value", 0]], null, null, null, null))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_6 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 32, 0, currVal_6);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 5, 0, currVal_0);

          var currVal_1 = _co.empData == null ? null : _co.empData.email;

          _ck(_v, 10, 0, currVal_1);

          var currVal_2 = _co.empData == null ? null : _co.empData.mobile;

          _ck(_v, 15, 0, currVal_2);

          var currVal_3 = _co.empData == null ? null : _co.empData.location;

          _ck(_v, 20, 0, currVal_3);

          var currVal_4 = _co.empData == null ? null : _co.empData.totalExperience;

          _ck(_v, 25, 0, currVal_4);

          var currVal_5 = _co.empData == null ? null : _co.empData.trianzExperience;

          _ck(_v, 30, 0, currVal_5);

          var currVal_7 = _co.empData == null ? null : _co.empData.primarySkills;

          _ck(_v, 37, 0, currVal_7);

          var currVal_8 = _co.empData == null ? null : _co.empData.secondarySkills;

          _ck(_v, 42, 0, currVal_8);
        });
      }

      function View_JobMobilityComponent_32(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_33(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes cannot exceed 2000 characters"]))], null, null);
      }

      function View_JobMobilityComponent_31(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 14, "div", [["class", "row"], ["style", "margin-top: 0px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_32)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 8, "div", [["class", "col-12 form-group"], ["style", "padding-left: 24px;padding-right: 25px;padding-top: 17px;padding-bottom: 1px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 5, "textarea", [["class", "form-control text-desc notes-border"], ["cols", "50"], ["rows", "11"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 5)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_4 = (_co.notesComments = $event) !== false;
            ad = pd_4 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](9, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_33)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](11, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 2, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "button", [["class", "btn mr-1 float-right save-btn"], ["type", "submit"]], [[8, "disabled", 0]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.saveNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Save"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.isLoading;

          _ck(_v, 2, 0, currVal_0);

          var currVal_8 = _co.notesComments;

          _ck(_v, 7, 0, currVal_8);

          var currVal_9 = (_co.notesComments == null ? null : _co.notesComments.length) > 2000;

          _ck(_v, 11, 0, currVal_9);
        }, function (_ck, _v) {
          var _co = _v.component;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassUntouched;

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassTouched;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassPristine;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassDirty;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassValid;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassInvalid;

          var currVal_7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 9).ngClassPending;

          _ck(_v, 4, 0, currVal_1, currVal_2, currVal_3, currVal_4, currVal_5, currVal_6, currVal_7);

          var currVal_10 = _co.notesComments == "" || (_co.notesComments == null ? null : _co.notesComments.length) > 2000 || _co.changeComment == _co.notesComments || _co.isLoading;

          _ck(_v, 13, 0, currVal_10);
        });
      }

      function View_JobMobilityComponent_35(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "progress-line"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "div", [["class", "progress"], ["style", "height: 100%;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_36(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 8, "div", [["class", "step"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "bullet"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["-"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 5, "div", [["class", "details"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](7, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 0, "div", [], null, null, null, null, null))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.$implicit.applicationStatusName;

          _ck(_v, 5, 0, currVal_0);

          var currVal_1 = _co.getFormattedDate(_v.context.$implicit.lastUpdate);

          _ck(_v, 7, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_37(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "notes-progress-line"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "div", [["class", "notes-progress"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_38(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "textarea", [["class", "text-desc"], ["cols", "50"], ["readonly", ""], ["rows", "3"], ["style", "border-radius: 5px;width:98%"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "div", [["class", "note-date mb-4 mr-2"], ["style", "float: right;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.$implicit.notes;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.getFormattedDate(_v.context.$implicit.lastUpdate);

          _ck(_v, 4, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_34(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 19, "div", [["class", "row mt-2 ml-1"], ["style", "margin-top: 15px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 9, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 8, "div", [["class", "progress-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "div", [["class", "progress-title"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applicant Status"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 5, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_35)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 2, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_36)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 8, "div", [["class", "col-8"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 1, "div", [["class", "progress-title"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes History"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 5, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_37)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](16, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 2, "div", [["class", "ml-2"], ["style", "width: 98%;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_38)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](19, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.statusHistory == null ? null : _co.statusHistory.length;

          _ck(_v, 7, 0, currVal_0);

          var currVal_1 = _co.statusHistory;

          _ck(_v, 10, 0, currVal_1);

          var currVal_2 = _co.notesHistory == null ? null : _co.notesHistory.length;

          _ck(_v, 16, 0, currVal_2);

          var currVal_3 = _co.notesHistory;

          _ck(_v, 19, 0, currVal_3);
        }, null);
      }

      function View_JobMobilityComponent_27(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 16777216, null, null, 11, "mat-tab", [["id", "detailsMatTab"]], null, null, null, _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["View_MatTab_0"], _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["RenderType_MatTab"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 770048, [[6, 4], [3, 4]], 2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTab"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], [2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TAB_GROUP"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 7, {
          templateLabel: 0
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](335544320, 8, {
          _explicitContent: 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_28)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 16384, [[7, 4], [4, 4]], 0, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabLabel"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_29)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_31)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](9, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_34)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](11, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          _ck(_v, 1, 0);

          var currVal_0 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == 0;

          _ck(_v, 7, 0, currVal_0);

          var currVal_1 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == 1;

          _ck(_v, 9, 0, currVal_1);

          var currVal_2 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == 2;

          _ck(_v, 11, 0, currVal_2);
        }, null);
      }

      function View_JobMobilityComponent_26(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["style", "margin-top: -5px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 5, "mat-tab-group", [["class", "mat-tab-group"], ["style", "width: 100%;"]], [[2, "mat-tab-group-dynamic-height", null], [2, "mat-tab-group-inverted-header", null]], [[null, "selectedIndexChange"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("selectedIndexChange" === en) {
            var pd_0 = (_co.selectedDetailsIndex = $event) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["View_MatTabGroup_0"], _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["RenderType_MatTabGroup"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](6144, null, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TAB_GROUP"], null, [_angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabGroup"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](3, 3325952, null, 1, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabGroup"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], [2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TABS_CONFIG"]], [2, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["ANIMATION_MODULE_TYPE"]]], {
          selectedIndex: [0, "selectedIndex"]
        }, {
          selectedIndexChange: "selectedIndexChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 6, {
          _allTabs: 1
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_27)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_2 = _co.selectedDetailsIndex;

          _ck(_v, 3, 0, currVal_2);

          var currVal_3 = _co.detailTabs;

          _ck(_v, 6, 0, currVal_3);
        }, function (_ck, _v) {
          var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 3).dynamicHeight;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 3).headerPosition === "below";

          _ck(_v, 1, 0, currVal_0, currVal_1);
        });
      }

      function View_JobMobilityComponent_39(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "tr", [["class", "m-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "p", [["class", "m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["No Records found"]))], null, null);
      }

      function View_JobMobilityComponent_8(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 48, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 21, "tr", [["style", "cursor: pointer;"]], [[2, "last-item", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.toggleDashboardRow(_v.context.index, _v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 4, "td", [["style", "width: 10px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_9)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_10)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "td", [["style", "width: 98px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](8, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"], ["style", "width: 162px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](10, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "td", [["style", "padding-left: 28px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](12, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "td", [["style", "width: 129px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](14, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](16, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](18, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "td", [["style", "padding-left: 28px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](20, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"], ["style", "width: 162px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](22, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 23, "tr", [["style", "background-color: #d1e1f4;"]], [[24, "@detailExpand", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 22, "td", [["class", "container"], ["colspan", "9"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 21, "div", [["class", "tab-vertical"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 12, "ul", [["class", "nav nav-tabs"], ["id", "dashbaordTab"], ["role", "tablist"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 4, "li", [["class", "nav-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.showDashboardDetails() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 3, "a", [["aria-controls", "home"], ["aria-selected", "true"], ["class", "nav-link"], ["data-toggle", "tab"], ["id", "home-vertical-tab"], ["role", "tab"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](29, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](30, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 4, "li", [["class", "nav-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.showApplications() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](33, 0, null, null, 3, "a", [["aria-controls", "profile"], ["aria-selected", "false"], ["class", "nav-link"], ["data-toggle", "tab"], ["id", "profile-vertical-tab"], ["role", "tab"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](34, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](35, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applications"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_11)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](38, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 7, "div", [["class", "tab-content dashboard-details"], ["id", "dashboardTabContent"], ["style", "overflow-y: auto !important;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 6, "div", [["aria-labelledby", "home-vertical-tab"], ["class", "tab-pane fade show active"], ["role", "tabpanel"]], [[8, "id", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_12)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](42, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_18)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](44, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_26)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](46, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_39)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](48, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.expandedDashboardRow === _v.context.index;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.expandedDashboardRow !== _v.context.index;

          _ck(_v, 6, 0, currVal_2);

          var currVal_15 = "nav-link";

          var currVal_16 = _ck(_v, 30, 0, _co.viewDashboardDetails == 0);

          _ck(_v, 29, 0, currVal_15, currVal_16);

          var currVal_17 = "nav-link";

          var currVal_18 = _ck(_v, 35, 0, _co.viewDashboardDetails == 1);

          _ck(_v, 34, 0, currVal_17, currVal_18);

          var currVal_19 = _co.viewDashboardDetails == 2;

          _ck(_v, 38, 0, currVal_19);

          var currVal_21 = _co.viewDashboardDetails == 0;

          _ck(_v, 42, 0, currVal_21);

          var currVal_22 = _co.viewDashboardDetails == 1;

          _ck(_v, 44, 0, currVal_22);

          var currVal_23 = _co.viewDashboardDetails == 2;

          _ck(_v, 46, 0, currVal_23);

          var currVal_24 = !(_co.jobsList == null ? null : _co.jobsList.length);

          _ck(_v, 48, 0, currVal_24);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.index == _co.jobsList.length - 1;

          _ck(_v, 1, 0, currVal_0);

          var currVal_3 = _v.context.$implicit == null ? null : _v.context.$implicit.trId;

          _ck(_v, 8, 0, currVal_3);

          var currVal_4 = _v.context.$implicit.jobTitle;

          _ck(_v, 9, 0, currVal_4);

          var currVal_5 = _v.context.$implicit == null ? null : _v.context.$implicit.jobTitle;

          _ck(_v, 10, 0, currVal_5);

          var currVal_6 = _v.context.$implicit == null ? null : _v.context.$implicit.grade;

          _ck(_v, 12, 0, currVal_6);

          var currVal_7 = _v.context.$implicit == null ? null : _v.context.$implicit.experience;

          _ck(_v, 14, 0, currVal_7);

          var currVal_8 = _v.context.$implicit.primarySkills;

          _ck(_v, 15, 0, currVal_8);

          var currVal_9 = _v.context.$implicit == null ? null : _v.context.$implicit.primarySkills;

          _ck(_v, 16, 0, currVal_9);

          var currVal_10 = _v.context.$implicit == null ? null : _v.context.$implicit.location;

          _ck(_v, 18, 0, currVal_10);

          var currVal_11 = _v.context.$implicit == null ? null : _v.context.$implicit.applicationsCount;

          _ck(_v, 20, 0, currVal_11);

          var currVal_12 = _v.context.$implicit.projectName;

          _ck(_v, 21, 0, currVal_12);

          var currVal_13 = _v.context.$implicit == null ? null : _v.context.$implicit.projectName;

          _ck(_v, 22, 0, currVal_13);

          var currVal_14 = _co.expandedDashboardRow == _v.context.index ? "expanded" : "collapsed";

          _ck(_v, 23, 0, currVal_14);

          var currVal_20 = _co.showId;

          _ck(_v, 40, 0, currVal_20);
        });
      }

      function View_JobMobilityComponent_41(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item disabled"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["..."]))], null, null);
      }

      function View_JobMobilityComponent_42(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item"]], [[2, "active", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToDashboardPage(_co.totalPagesperGrid) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage === _co.totalPagesperGrid;

          _ck(_v, 0, 0, currVal_0);

          var currVal_1 = _co.totalPagesperGrid;

          _ck(_v, 1, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_40(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 10, "ul", [["class", "pagination"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "li", [["class", "page-item prev-page"]], [[2, "disabled", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToDashboardPage(_co.currentPage - 1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "i", [["class", "bx bx-chevron-left"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "li", [["class", "page-item"]], [[2, "active", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToDashboardPage(1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["1"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_41)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_42)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](8, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "li", [["class", "page-item next-page"]], [[2, "disabled", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToDashboardPage(_co.currentPage + 1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"]], null, null, null, null, null))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_2 = _co.currentPage < _co.totalPagesperGrid - 2;

          _ck(_v, 6, 0, currVal_2);

          var currVal_3 = _co.totalPagesperGrid >= 2;

          _ck(_v, 8, 0, currVal_3);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage === 1;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = _co.currentPage === 1;

          _ck(_v, 3, 0, currVal_1);

          var currVal_4 = _co.currentPage === _co.totalPagesperGrid || _co.totalPagesperGrid == 0;

          _ck(_v, 9, 0, currVal_4);
        });
      }

      function View_JobMobilityComponent_5(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 50, "div", [["class", "col-12 ml-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 49, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 20, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 19, "div", [["class", "d-flex ml-auto mr-3 mt-1"], ["id", "main-table"]], null, [["document", "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("document:click" === en) {
            var pd_0 = _co.onDocumentClick($event) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, [[1, 0], ["dropdownWrapper", 1]], null, 18, "div", [["class", "input-group"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 7, "div", [["class", "input-group-prepend"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 1, "button", [["class", "btn  dropdown-toggle"], ["style", "font-size:13px;padding-top: 13px;"], ["type", "button"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.toggleDropdown() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](7, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 4, "div", [["class", "dropdown-menu"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](9, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](10, {
          "show": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_6)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](12, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 9, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 5, "input", [["class", "form-control input-search"], ["placeholder", "Search..."], ["style", "background-color: #ffffff;font-size:13px;border: none;"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "input"], [null, "keyup.enter"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 15)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 15).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 15)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 15)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_4 = (_co.searchTerm = $event) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _co.refreshData($event, "dashboard") !== false;
            ad = pd_5 && ad;
          }

          if ("keyup.enter" === en) {
            var pd_6 = _co.searchItem("Dashboard") !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](15, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](17, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](19, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 2, "div", [["class", "input-group-append"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "span", [["class", "search"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 0, "i", [["class", "bx bx-search"], ["style", "cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.searchItem("Dashboard") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 27, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_7)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](25, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 22, "table", [["class", "table m-0 mb-3"], ["style", "width:98.7%"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 18, "thead", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 17, "tr", [["style", "border-top:1px solid var(--Gray-200, #E4E7EC)"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 0, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["TR #"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Position"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](34, 0, null, null, 1, "th", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Grade"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 1, "th", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applied"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Project Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](46, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_8)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](48, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_40)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](50, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = "dropdown-menu";

          var currVal_2 = _ck(_v, 10, 0, _co.dropdownVisible);

          _ck(_v, 9, 0, currVal_1, currVal_2);

          var currVal_3 = _co.searchOptions;

          _ck(_v, 12, 0, currVal_3);

          var currVal_11 = _co.searchTerm;

          _ck(_v, 17, 0, currVal_11);

          var currVal_12 = _co.loading;

          _ck(_v, 25, 0, currVal_12);

          var currVal_13 = _co.jobsList;

          _ck(_v, 48, 0, currVal_13);

          var currVal_14 = _co.dashboardTotalJobs > 10;

          _ck(_v, 50, 0, currVal_14);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedOption.label;

          _ck(_v, 7, 0, currVal_0);

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassUntouched;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassTouched;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassPristine;

          var currVal_7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassDirty;

          var currVal_8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassValid;

          var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassInvalid;

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 19).ngClassPending;

          _ck(_v, 14, 0, currVal_4, currVal_5, currVal_6, currVal_7, currVal_8, currVal_9, currVal_10);
        });
      }

      function View_JobMobilityComponent_43(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["class", "mt-1 col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["class", "ml-2 mt-3 navigation-link"], ["src", "../../assets/images/ArrowUUpLeft.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.clickDashboardTable() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "h4", [["class", "mt-3 ml-2"], ["style", "color: #000000;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", " Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "app-job-details", [], null, null, null, _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["View_JobDetailsComponent_0"], _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["RenderType_JobDetailsComponent"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 770048, null, 0, _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_8__["JobDetailsComponent"], [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"], _providers_utility_service__WEBPACK_IMPORTED_MODULE_10__["UtilityService"], _providers_jump_service__WEBPACK_IMPORTED_MODULE_11__["JumpService"]], {
          jobDetails: [0, "jobDetails"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.selectedJob;

          _ck(_v, 6, 0, currVal_1);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.link;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_4(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "row matTab"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_5)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_43)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.isShowTable;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = !_co.isShowTable;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_46(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "dropdown-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.selectOption(_v.context.$implicit, "open-roles") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, [" ", " "]))], null, function (_ck, _v) {
          var currVal_0 = _v.context.$implicit.label;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_47(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_49(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-down"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_50(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_52(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "row mt-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "col-11"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "textarea", [["class", "form-control input-div mb-2"], ["cols", "30"], ["readonly", ""], ["rows", "14"], ["style", "background-color: #ffffff;font-size: 13px;width: 103%;border: none;padding: 0px;resize: none;"]], [[8, "value", 0]], null, null, null, null))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.parent.context.$implicit == null ? null : _v.parent.parent.context.$implicit.jobDescription;

          _ck(_v, 2, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_51(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 24, "div", [["class", ""], ["style", "padding-top: 5px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 23, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 16, "div", [["class", "col-3"], ["style", "height: 343px;overflow-y:auto"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skills: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "span", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](6, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Project Name: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](10, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Account Name: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](14, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Practice: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](18, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 5, "div", [["class", "d-flex col-10 justify-content-between"], ["style", "margin-left: -14px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Description :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_52)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](24, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var currVal_4 = (_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.jobDescription) || (_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.jobDescription) != null;

          _ck(_v, 24, 0, currVal_4);
        }, function (_ck, _v) {
          var currVal_0 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.primarySkills;

          _ck(_v, 6, 0, currVal_0);

          var currVal_1 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.projectName;

          _ck(_v, 10, 0, currVal_1);

          var currVal_2 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.accountName;

          _ck(_v, 14, 0, currVal_2);

          var currVal_3 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.practice;

          _ck(_v, 18, 0, currVal_3);
        });
      }

      function View_JobMobilityComponent_54(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_56(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Employee name is required. "]))], null, null);
      }

      function View_JobMobilityComponent_55(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_56)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["fname"].errors == null ? null : _co.frmEditProfile.controls["fname"].errors.required;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobMobilityComponent_57(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobMobilityComponent_58(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Employee Name cannot exceed 99 characters. "]))], null, null);
      }

      function View_JobMobilityComponent_60(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Phone number is required. "]))], null, null);
      }

      function View_JobMobilityComponent_61(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Phone number is not valid. "]))], null, null);
      }

      function View_JobMobilityComponent_59(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_60)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_61)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["phoneNumber"].errors == null ? null : _co.frmEditProfile.controls["phoneNumber"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["phoneNumber"].errors.pattern || _co.frmEditProfile.controls["phoneNumber"].errors.maxlength;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_63(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Email is required. "]))], null, null);
      }

      function View_JobMobilityComponent_64(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Provide valid email. "]))], null, null);
      }

      function View_JobMobilityComponent_62(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_63)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_64)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["email"].errors == null ? null : _co.frmEditProfile.controls["email"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["email"].errors == null ? null : _co.frmEditProfile.controls["email"].errors.pattern;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_66(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Total experience is required. "]))], null, null);
      }

      function View_JobMobilityComponent_65(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_66)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["experience"].errors == null ? null : _co.frmEditProfile.controls["experience"].errors.required;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobMobilityComponent_67(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Experience cannot be more than 99 years. "]))], null, null);
      }

      function View_JobMobilityComponent_69(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience is required. "]))], null, null);
      }

      function View_JobMobilityComponent_70(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience cannot be more than 99 years. "]))], null, null);
      }

      function View_JobMobilityComponent_71(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience should be less than or equal to Total experience. "]))], null, null);
      }

      function View_JobMobilityComponent_68(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_69)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_70)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_71)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.max;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.experienceMismatch;

          _ck(_v, 6, 0, currVal_2);
        }, null);
      }

      function View_JobMobilityComponent_72(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Location is required. "]))], null, null);
      }

      function View_JobMobilityComponent_73(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Location cannot exceed 99 characters. "]))], null, null);
      }

      function View_JobMobilityComponent_74(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skill is required. "]))], null, null);
      }

      function View_JobMobilityComponent_75(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobMobilityComponent_76(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary skill cannot exceed 500 characters. "]))], null, null);
      }

      function View_JobMobilityComponent_77(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobMobilityComponent_78(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Secondary skill cannot exceed 500 characters. "]))], null, null);
      }

      function View_JobMobilityComponent_79(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "a", [["href", "javascript:void(0)"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.downloadDocument("") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.fileName;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_80(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "mt-1 text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.warningMessage;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_53(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 149, "form", [["class", "formClass"], ["novalidate", ""]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "submit"], [null, "reset"]], function (_v, en, $event) {
          var ad = true;

          if ("submit" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).onSubmit($event) !== false;
            ad = pd_0 && ad;
          }

          if ("reset" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).onReset() !== false;
            ad = pd_1 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_y"], [], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 540672, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"], [[8, null], [8, null]], {
          form: [0, "form"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_54)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 139, "div", [["class", "row mt-1"], ["style", "font-size:13px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 16, "div", [["class", "form-group col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Employee Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 5, "input", [["class", "form-details form-control"], ["formControlName", "fname"], ["id", "txtFirstname"], ["placeholder", "*Employee name"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 14)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 14).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 14)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 14)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](14, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](16, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](18, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_55)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](20, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_57)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](22, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_58)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](24, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 15, "div", [["class", "form-group col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Phone Number"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 8, "input", [["class", "form-details form-control"], ["formControlName", "phoneNumber"], ["id", "phoneNumber"], ["maxlength", "10"], ["min", "0"], ["placeholder", "*PhoneNumber"], ["type", "number"]], [[1, "maxlength", 0], [2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 32).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 32).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 32).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](31, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](32, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](33, 540672, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["MaxLengthValidator"], [], {
          maxlength: [0, "maxlength"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALIDATORS"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["MaxLengthValidator"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](36, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALIDATORS"]], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](38, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_59)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](40, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](41, 0, null, null, 12, "div", [["class", "form-group col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Email ID"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](46, 0, null, null, 5, "input", [["aria-describedby", "emailHelp"], ["class", "form-details form-control"], ["formControlName", "email"], ["id", "exampleInputEmail1"], ["placeholder", "*Email Address"], ["readonly", ""], ["type", "email"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 47)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 47).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 47)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 47)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](47, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](49, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](51, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_62)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](53, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](54, 0, null, null, 15, "div", [["class", "form-group col-4 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](55, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](57, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](59, 0, null, null, 6, "input", [["class", "form-details form-control"], ["formControlName", "experience"], ["id", "experience"], ["min", "1"], ["placeholder", "*Experience"], ["type", "number"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 60)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 60).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 60)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 60)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 61).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 61).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 61).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](60, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](61, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](63, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](65, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_65)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](67, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_67)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](69, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](70, 0, null, null, 13, "div", [["class", "form-group col-4 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](71, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Experience"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](73, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](75, 0, null, null, 6, "input", [["class", "form-details form-control"], ["formControlName", "trianzExperience"], ["id", "experience"], ["min", "0"], ["placeholder", "*Trianz Experience"], ["type", "number"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 76)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 76).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 76)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 76)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 77).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 77).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 77).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](76, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](77, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](79, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](81, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_68)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](83, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](84, 0, null, null, 14, "div", [["class", "form-group col-4 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](85, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](87, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](89, 0, null, null, 5, "input", [["class", "form-details form-control"], ["formControlName", "location"], ["id", "location"], ["placeholder", "*Location"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 90)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 90).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 90)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 90)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](90, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](92, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](94, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_72)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](96, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_73)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](98, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](99, 0, null, null, 16, "div", [["class", "form-group col-4 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](100, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](102, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](104, 0, null, null, 5, "input", [["class", "form-details form-control"], ["formControlName", "primaryskill"], ["id", "primary"], ["placeholder", "*Primary Skill"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 105)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 105).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 105)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 105)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](105, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](107, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](109, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_74)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](111, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_75)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](113, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_76)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](115, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](116, 0, null, null, 12, "div", [["class", "form-group col-4 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](117, 0, null, null, 1, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](119, 0, null, null, 5, "input", [["class", "form-details form-control"], ["formControlName", "secondaryskill"], ["id", "secondary"], ["placeholder", "Secondary Skill"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 120)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 120).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 120)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 120)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](120, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](122, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](124, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_77)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](126, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_78)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](128, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](129, 0, null, null, 0, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](130, 0, null, null, 16, "div", [["class", "form-group col-12 "]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](131, 0, null, null, 2, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](132, 0, null, null, 1, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*Attach the resume .pptx format"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](134, 0, null, null, 10, "div", [["class", "file-input-container mt-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](135, 0, [[2, 0], ["fileInput", 1]], null, 0, "input", [["accept", ".ppt,.pptx"], ["id", "imageUpload"], ["style", "display: none;"], ["type", "file"]], null, [[null, "change"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("change" === en) {
            var pd_0 = _co.uploadFile($event) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](136, 0, null, null, 1, "label", [["class", "custom-file-upload"], ["for", "imageUpload"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Choose File "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](138, 0, null, null, 6, "label", [["class", "continue-box d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](139, 0, null, null, 2, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_79)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](141, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](142, 0, null, null, 2, "a", [["class", "btn-download"], ["download", ""], ["href", "../../assets/images/Sample Profile.pptx"], ["style", "margin-left: 116px;border:none;border-radius: 6px;padding: 1px;height: 21px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](143, 0, null, null, 0, "i", [["class", "bx bx-download"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Download Sample Resume "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_80)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](146, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](147, 0, null, null, 2, "div", [["class", "float-right mb-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](148, 0, null, null, 1, "button", [["class", "btn save-btn"], ["type", "submit"]], [[8, "disabled", 0]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.saveJob(_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.trId) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Submit"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_7 = _co.frmEditProfile;

          _ck(_v, 2, 0, currVal_7);

          var currVal_8 = _co.isLoading;

          _ck(_v, 6, 0, currVal_8);

          var currVal_16 = "fname";

          _ck(_v, 16, 0, currVal_16);

          var currVal_17 = _co.frmEditProfile.controls["fname"].hasError("required") && _co.frmEditProfile.controls["fname"].touched;

          _ck(_v, 20, 0, currVal_17);

          var currVal_18 = _co.frmEditProfile.get("fname").hasError("nonAscii");

          _ck(_v, 22, 0, currVal_18);

          var currVal_19 = _co.frmEditProfile.get("fname").errors == null ? null : _co.frmEditProfile.get("fname").errors.maxlength;

          _ck(_v, 24, 0, currVal_19);

          var currVal_28 = "10";

          _ck(_v, 33, 0, currVal_28);

          var currVal_29 = "phoneNumber";

          _ck(_v, 36, 0, currVal_29);

          var currVal_30 = _co.frmEditProfile.controls["phoneNumber"].invalid && _co.frmEditProfile.controls["phoneNumber"].touched;

          _ck(_v, 40, 0, currVal_30);

          var currVal_38 = "email";

          _ck(_v, 49, 0, currVal_38);

          var currVal_39 = _co.frmEditProfile.controls["email"].invalid && _co.frmEditProfile.controls["email"].touched;

          _ck(_v, 53, 0, currVal_39);

          var currVal_47 = "experience";

          _ck(_v, 63, 0, currVal_47);

          var currVal_48 = _co.frmEditProfile.controls["experience"].invalid && _co.frmEditProfile.controls["experience"].touched;

          _ck(_v, 67, 0, currVal_48);

          var currVal_49 = _co.frmEditProfile.controls["experience"].errors == null ? null : _co.frmEditProfile.controls["experience"].errors.max;

          _ck(_v, 69, 0, currVal_49);

          var currVal_57 = "trianzExperience";

          _ck(_v, 79, 0, currVal_57);

          var currVal_58 = _co.frmEditProfile.controls["trianzExperience"].invalid && _co.frmEditProfile.controls["trianzExperience"].touched;

          _ck(_v, 83, 0, currVal_58);

          var currVal_66 = "location";

          _ck(_v, 92, 0, currVal_66);

          var currVal_67 = _co.frmEditProfile.get("location").hasError("required") && _co.frmEditProfile.get("location").touched;

          _ck(_v, 96, 0, currVal_67);

          var currVal_68 = _co.frmEditProfile.get("location").errors == null ? null : _co.frmEditProfile.get("location").errors.maxlength;

          _ck(_v, 98, 0, currVal_68);

          var currVal_76 = "primaryskill";

          _ck(_v, 107, 0, currVal_76);

          var currVal_77 = _co.frmEditProfile.get("primaryskill").hasError("required") && _co.frmEditProfile.get("primaryskill").touched;

          _ck(_v, 111, 0, currVal_77);

          var currVal_78 = _co.frmEditProfile.get("primaryskill").hasError("nonAscii");

          _ck(_v, 113, 0, currVal_78);

          var currVal_79 = _co.frmEditProfile.get("primaryskill").errors == null ? null : _co.frmEditProfile.get("primaryskill").errors.maxlength;

          _ck(_v, 115, 0, currVal_79);

          var currVal_87 = "secondaryskill";

          _ck(_v, 122, 0, currVal_87);

          var currVal_88 = _co.frmEditProfile.get("secondaryskill").hasError("nonAscii");

          _ck(_v, 126, 0, currVal_88);

          var currVal_89 = _co.frmEditProfile.get("secondaryskill").errors == null ? null : _co.frmEditProfile.get("secondaryskill").errors.maxlength;

          _ck(_v, 128, 0, currVal_89);

          var currVal_90 = _co.fileName;

          _ck(_v, 141, 0, currVal_90);

          var currVal_91 = _co.warningMessage;

          _ck(_v, 146, 0, currVal_91);
        }, function (_ck, _v) {
          var _co = _v.component;

          var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassUntouched;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassTouched;

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassPristine;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassDirty;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassValid;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassInvalid;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassPending;

          _ck(_v, 0, 0, currVal_0, currVal_1, currVal_2, currVal_3, currVal_4, currVal_5, currVal_6);

          var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassUntouched;

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassTouched;

          var currVal_11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassPristine;

          var currVal_12 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassDirty;

          var currVal_13 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassValid;

          var currVal_14 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassInvalid;

          var currVal_15 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 18).ngClassPending;

          _ck(_v, 13, 0, currVal_9, currVal_10, currVal_11, currVal_12, currVal_13, currVal_14, currVal_15);

          var currVal_20 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 33).maxlength ? _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 33).maxlength : null;

          var currVal_21 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassUntouched;

          var currVal_22 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassTouched;

          var currVal_23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassPristine;

          var currVal_24 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassDirty;

          var currVal_25 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassValid;

          var currVal_26 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassInvalid;

          var currVal_27 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 38).ngClassPending;

          _ck(_v, 30, 0, currVal_20, currVal_21, currVal_22, currVal_23, currVal_24, currVal_25, currVal_26, currVal_27);

          var currVal_31 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassUntouched;

          var currVal_32 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassTouched;

          var currVal_33 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassPristine;

          var currVal_34 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassDirty;

          var currVal_35 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassValid;

          var currVal_36 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassInvalid;

          var currVal_37 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 51).ngClassPending;

          _ck(_v, 46, 0, currVal_31, currVal_32, currVal_33, currVal_34, currVal_35, currVal_36, currVal_37);

          var currVal_40 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassUntouched;

          var currVal_41 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassTouched;

          var currVal_42 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassPristine;

          var currVal_43 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassDirty;

          var currVal_44 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassValid;

          var currVal_45 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassInvalid;

          var currVal_46 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 65).ngClassPending;

          _ck(_v, 59, 0, currVal_40, currVal_41, currVal_42, currVal_43, currVal_44, currVal_45, currVal_46);

          var currVal_50 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassUntouched;

          var currVal_51 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassTouched;

          var currVal_52 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassPristine;

          var currVal_53 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassDirty;

          var currVal_54 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassValid;

          var currVal_55 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassInvalid;

          var currVal_56 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 81).ngClassPending;

          _ck(_v, 75, 0, currVal_50, currVal_51, currVal_52, currVal_53, currVal_54, currVal_55, currVal_56);

          var currVal_59 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassUntouched;

          var currVal_60 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassTouched;

          var currVal_61 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassPristine;

          var currVal_62 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassDirty;

          var currVal_63 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassValid;

          var currVal_64 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassInvalid;

          var currVal_65 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 94).ngClassPending;

          _ck(_v, 89, 0, currVal_59, currVal_60, currVal_61, currVal_62, currVal_63, currVal_64, currVal_65);

          var currVal_69 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassUntouched;

          var currVal_70 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassTouched;

          var currVal_71 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassPristine;

          var currVal_72 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassDirty;

          var currVal_73 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassValid;

          var currVal_74 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassInvalid;

          var currVal_75 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 109).ngClassPending;

          _ck(_v, 104, 0, currVal_69, currVal_70, currVal_71, currVal_72, currVal_73, currVal_74, currVal_75);

          var currVal_80 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassUntouched;

          var currVal_81 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassTouched;

          var currVal_82 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassPristine;

          var currVal_83 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassDirty;

          var currVal_84 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassValid;

          var currVal_85 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassInvalid;

          var currVal_86 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 124).ngClassPending;

          _ck(_v, 119, 0, currVal_80, currVal_81, currVal_82, currVal_83, currVal_84, currVal_85, currVal_86);

          var currVal_92 = !_co.frmEditProfile.valid || _co.isLoading;

          _ck(_v, 148, 0, currVal_92);
        });
      }

      function View_JobMobilityComponent_82(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["You already applied to this role "]))], null, null);
      }

      function View_JobMobilityComponent_83(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["You have reached the maximum limit of 5 applications, so you can't apply for other roles."]))], null, null);
      }

      function View_JobMobilityComponent_81(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["style", "height: 100px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_82)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_83)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = !(_v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.canApply) && _co.applicationsCount <= 4;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.applicationsCount >= 5;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_84(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "tr", [["class", "m-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "p", [["class", "m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["No Records found"]))], null, null);
      }

      function View_JobMobilityComponent_48(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 44, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 19, "tr", [["style", "cursor: pointer;"]], [[2, "last-item", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.toggleRow(_v.context.index) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 4, "td", [["style", "width: 10px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_49)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_50)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "td", [["style", "width: 98px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](8, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"], ["style", "width: 162px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](10, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "td", [["style", "padding-left: 29px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](12, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "td", [["style", "width: 130px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](14, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](16, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](18, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"], ["style", "width: 162px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](20, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 21, "tr", [["style", "background-color: #d1e1f4;"]], [[24, "@detailExpand", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 20, "td", [["class", "container"], ["colspan", "9"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 19, "div", [["class", "tab-vertical"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 10, "ul", [["class", "nav nav-tabs"], ["id", "myTab3"], ["role", "tablist"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 4, "li", [["class", "nav-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.showDetails() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 3, "a", [["aria-controls", "home"], ["aria-selected", "true"], ["class", "nav-link"], ["data-toggle", "tab"], ["href", "#home-vertical"], ["id", "home-vertical-tab"], ["role", "tab"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](27, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](28, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 4, "li", [["class", "nav-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.applyJob() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 3, "a", [["aria-controls", "profile"], ["aria-selected", "false"], ["class", "nav-link"], ["data-toggle", "tab"], ["href", "#profile-vertical"], ["id", "profile-vertical-tab"], ["role", "tab"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](32, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](33, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Apply"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](35, 0, null, null, 7, "div", [["class", "tab-content open-roles-details"], ["id", "myTabContent3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 6, "div", [["aria-labelledby", "home-vertical-tab"], ["class", "tab-pane fade show active"], ["role", "tabpanel"]], [[8, "id", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_51)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](38, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_53)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](40, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_81)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](42, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_84)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](44, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.expandedRow === _v.context.index;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.expandedRow !== _v.context.index;

          _ck(_v, 6, 0, currVal_2);

          var currVal_14 = "nav-link";

          var currVal_15 = _ck(_v, 28, 0, !_co.showApplyDetails);

          _ck(_v, 27, 0, currVal_14, currVal_15);

          var currVal_16 = "nav-link";

          var currVal_17 = _ck(_v, 33, 0, _co.showApplyDetails);

          _ck(_v, 32, 0, currVal_16, currVal_17);

          var currVal_19 = !_co.showApplyDetails;

          _ck(_v, 38, 0, currVal_19);

          var currVal_20 = _co.userInfo && _co.showApplyDetails && _co.applicationsCount <= 4 && (_v.context.$implicit == null ? null : _v.context.$implicit.canApply);

          _ck(_v, 40, 0, currVal_20);

          var currVal_21 = _co.showApplyDetails && (_co.applicationsCount >= 5 || !(_v.context.$implicit == null ? null : _v.context.$implicit.canApply));

          _ck(_v, 42, 0, currVal_21);

          var currVal_22 = !(_co.visibleItems == null ? null : _co.visibleItems.length);

          _ck(_v, 44, 0, currVal_22);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.index == _co.visibleItems.length - 1;

          _ck(_v, 1, 0, currVal_0);

          var currVal_3 = _v.context.$implicit == null ? null : _v.context.$implicit.trId;

          _ck(_v, 8, 0, currVal_3);

          var currVal_4 = _v.context.$implicit.jobTitle;

          _ck(_v, 9, 0, currVal_4);

          var currVal_5 = _v.context.$implicit == null ? null : _v.context.$implicit.jobTitle;

          _ck(_v, 10, 0, currVal_5);

          var currVal_6 = _v.context.$implicit == null ? null : _v.context.$implicit.grade;

          _ck(_v, 12, 0, currVal_6);

          var currVal_7 = _v.context.$implicit == null ? null : _v.context.$implicit.experience;

          _ck(_v, 14, 0, currVal_7);

          var currVal_8 = _v.context.$implicit == null ? null : _v.context.$implicit.primarySkills;

          _ck(_v, 15, 0, currVal_8);

          var currVal_9 = _v.context.$implicit == null ? null : _v.context.$implicit.primarySkills;

          _ck(_v, 16, 0, currVal_9);

          var currVal_10 = _v.context.$implicit == null ? null : _v.context.$implicit.location;

          _ck(_v, 18, 0, currVal_10);

          var currVal_11 = _v.context.$implicit.projectName;

          _ck(_v, 19, 0, currVal_11);

          var currVal_12 = _v.context.$implicit == null ? null : _v.context.$implicit.projectName;

          _ck(_v, 20, 0, currVal_12);

          var currVal_13 = _co.expandedRow == _v.context.index ? "expanded" : "collapsed";

          _ck(_v, 21, 0, currVal_13);

          var currVal_18 = _co.showId;

          _ck(_v, 36, 0, currVal_18);
        });
      }

      function View_JobMobilityComponent_87(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item disabled"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["..."]))], null, null);
      }

      function View_JobMobilityComponent_86(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_87)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage > 3;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobMobilityComponent_88(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item"]], [[2, "active", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToPage(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, [" ", " "]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage === _v.context.$implicit;

          _ck(_v, 0, 0, currVal_0);

          var currVal_1 = _v.context.$implicit;

          _ck(_v, 1, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_90(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item disabled"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["..."]))], null, null);
      }

      function View_JobMobilityComponent_89(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_90)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage < _co.totalPages - 2;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobMobilityComponent_91(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "li", [["class", "page-item"]], [[2, "active", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToPage(_co.totalPages) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage === _co.totalPages;

          _ck(_v, 0, 0, currVal_0);

          var currVal_1 = _co.totalPages;

          _ck(_v, 1, 0, currVal_1);
        });
      }

      function View_JobMobilityComponent_85(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 14, "ul", [["class", "pagination"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "li", [["class", "page-item prev-page"]], [[2, "disabled", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToPage(_co.currentPage - 1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "i", [["class", "bx bx-chevron-left"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "li", [["class", "page-item"]], [[2, "active", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToPage(1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["1"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_86)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_88)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](8, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_89)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_91)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](12, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "li", [["class", "page-item next-page"]], [[2, "disabled", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.goToPage(_co.currentPage + 1) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"]], null, null, null, null, null))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_2 = _co.totalPages > 6;

          _ck(_v, 6, 0, currVal_2);

          var currVal_3 = _co.getDisplayedPages();

          _ck(_v, 8, 0, currVal_3);

          var currVal_4 = _co.totalPages > 6;

          _ck(_v, 10, 0, currVal_4);

          var currVal_5 = _co.totalPages >= 2;

          _ck(_v, 12, 0, currVal_5);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.currentPage === 1;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = _co.currentPage === 1;

          _ck(_v, 3, 0, currVal_1);

          var currVal_6 = _co.currentPage === _co.totalPages || _co.totalPages == 0;

          _ck(_v, 13, 0, currVal_6);
        });
      }

      function View_JobMobilityComponent_45(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 46, "div", [["class", "col-12 ml-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 19, "div", [["class", "d-flex mr-3  float-right"], ["id", "open"]], null, [["document", "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("document:click" === en) {
            var pd_0 = _co.onDocumentClick($event) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, [[1, 0], ["dropdownWrapper", 1]], null, 18, "div", [["class", "input-group"], ["style", "height: 37px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 7, "div", [["class", "input-group-prepend"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "button", [["class", "btn  dropdown-toggle"], ["style", "font-size:13px;padding-top: 13px;"], ["type", "button"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.toggleDropdown() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 4, "div", [["class", "dropdown-menu"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](8, {
          "show": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_46)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 9, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 5, "input", [["class", "form-control input-search"], ["placeholder", "Search..."], ["style", "background-color: #ffffff;font-size:13px;border:none"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "input"], [null, "keyup.enter"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 13)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_4 = (_co.searchTerm = $event) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _co.refreshData($event, "open-roles") !== false;
            ad = pd_5 && ad;
          }

          if ("keyup.enter" === en) {
            var pd_6 = _co.searchOpenRoleItem() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](13, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](15, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](17, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 2, "div", [["class", "input-group-append"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "span", [["class", "search"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 0, "i", [["class", "bx bx-search"], ["style", "cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.searchOpenRoleItem() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 25, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_47)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](23, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 20, "table", [["class", "table m-0 mb-3"], ["style", "width:98.7%"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 16, "thead", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 15, "tr", [["style", "border-top:1px solid var(--Gray-200, #E4E7EC)"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 0, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["TR #"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Position"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Grade "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](34, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Project Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_48)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](44, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_85)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](46, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = "dropdown-menu";

          var currVal_2 = _ck(_v, 8, 0, _co.dropdownVisible);

          _ck(_v, 7, 0, currVal_1, currVal_2);

          var currVal_3 = _co.searchOptions;

          _ck(_v, 10, 0, currVal_3);

          var currVal_11 = _co.searchTerm;

          _ck(_v, 15, 0, currVal_11);

          var currVal_12 = _co.loading;

          _ck(_v, 23, 0, currVal_12);

          var currVal_13 = _co.visibleItems;

          _ck(_v, 44, 0, currVal_13);

          var currVal_14 = _co.openrolesTotalJobs > 10;

          _ck(_v, 46, 0, currVal_14);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedOption.label;

          _ck(_v, 5, 0, currVal_0);

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassUntouched;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassTouched;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassPristine;

          var currVal_7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassDirty;

          var currVal_8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassValid;

          var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassInvalid;

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 17).ngClassPending;

          _ck(_v, 12, 0, currVal_4, currVal_5, currVal_6, currVal_7, currVal_8, currVal_9, currVal_10);
        });
      }

      function View_JobMobilityComponent_93(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "button", [["class", "btn apply-btn"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.applynowbtnClick() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Apply now"]))], null, null);
      }

      function View_JobMobilityComponent_92(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 10, "div", [["class", "mt-1 col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 7, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 3, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["class", "ml-2 mt-3 navigation-link"], ["src", "../../assets/images/ArrowUUpLeft.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.clickOpenrolesData() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "h4", [["class", "mt-3 ml-2"], ["style", "color: #000000;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", " Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 2, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_93)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](8, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "app-job-details", [], null, [[null, "applyNowModelClose"], [null, "closeApplyButton"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("applyNowModelClose" === en) {
            var pd_0 = _co.closeModel($event) !== false;
            ad = pd_0 && ad;
          }

          if ("closeApplyButton" === en) {
            var pd_1 = _co.closeApply($event) !== false;
            ad = pd_1 && ad;
          }

          return ad;
        }, _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["View_JobDetailsComponent_0"], _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["RenderType_JobDetailsComponent"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](10, 770048, null, 0, _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_8__["JobDetailsComponent"], [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"], _providers_utility_service__WEBPACK_IMPORTED_MODULE_10__["UtilityService"], _providers_jump_service__WEBPACK_IMPORTED_MODULE_11__["JumpService"]], {
          jobDetails: [0, "jobDetails"],
          applyNowBtnClick: [1, "applyNowBtnClick"]
        }, {
          applyNowModelClose: "applyNowModelClose",
          closeApplyButton: "closeApplyButton"
        })], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.applyButton;

          _ck(_v, 8, 0, currVal_1);

          var currVal_2 = _co.selectedJob;
          var currVal_3 = _co.selectApplynow;

          _ck(_v, 10, 0, currVal_2, currVal_3);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.link;

          _ck(_v, 5, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_44(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "row matTab"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_45)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_92)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.isOpenRolesHidden;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = !_co.isOpenRolesHidden;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_97(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-down"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_98(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"], ["style", "border: 1px solid #d3d3d3; border-radius: 50%; padding: 1px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_99(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "row mt-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "col-11"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "textarea", [["class", "form-control input-div"], ["cols", "30"], ["readonly", ""], ["rows", "15"], ["style", "background-color: #ffffff;font-size: 13px;padding:0px;width: 104%;border:none;resize: none;"]], [[8, "value", 0]], null, null, null, null))], null, function (_ck, _v) {
          var currVal_0 = _v.parent.context.$implicit == null ? null : _v.parent.context.$implicit.jobDescription;

          _ck(_v, 2, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_100(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "tr", [["class", "m-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "p", [["class", "m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["No Records found"]))], null, null);
      }

      function View_JobMobilityComponent_96(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 55, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 26, "tr", [["style", "cursor:pointer;"]], [[2, "last-item", null]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.toggleMyApplicationsRow(_v.context.index) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 4, "td", [["style", "width: 10px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_97)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_98)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 2, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](9, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"], ["style", "width: 162px;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](11, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 1, "td", [["class", "primary-skill-ellipsis"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](13, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 1, "td", [["style", "padding-left: 28px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](15, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](16, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](17, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 2, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](19, null, ["", ""])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵppd"](20, 2), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](22, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 4, "td", [["style", "margin-top: 9px;\n                          margin-left: 2px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 3, "span", [["class", "badge badge-custom"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](25, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgStyle"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          ngStyle: [0, "ngStyle"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](26, {
          "background-color": 0,
          "color": 1
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](27, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 25, "tr", [["style", "background-color: #d1e1f4;"]], [[24, "@detailExpand", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 24, "td", [["class", "container"], ["colspan", "9"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 23, "div", [["class", "tab-vertical"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 3, "ul", [["class", "nav nav-tabs"], ["id", "myTab3"], ["role", "tablist"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 2, "li", [["class", "nav-item"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](33, 0, null, null, 1, "a", [["aria-controls", "home"], ["aria-selected", "true"], ["class", "nav-link active"], ["data-toggle", "tab"], ["href", "#apply-home"], ["id", "home-vertical-tab"], ["role", "tab"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](35, 0, null, null, 18, "div", [["class", "tab-content dashboard-details"], ["id", "myApplicationTabContent"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 17, "div", [["aria-labelledby", "home-vertical-tab"], ["class", "tab-pane fade show active"], ["id", "apply-home"], ["role", "tabpanel"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](37, 0, null, null, 16, "div", [["class", ""], ["style", "padding-top: 5px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 15, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 8, "div", [["class", "col-3"], ["style", "height: 360px;overflow-y:auto"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skills: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 1, "span", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](43, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 1, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Secondary Skills: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](46, 0, null, null, 1, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](47, null, [" ", " "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](48, 0, null, null, 5, "div", [["class", "d-flex col-10 justify-content-between"], ["style", "margin-left: -24px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](49, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](50, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Description :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_99)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](53, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_100)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](55, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.expandedApplicationsRow === _v.context.index;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.expandedApplicationsRow !== _v.context.index;

          _ck(_v, 6, 0, currVal_2);

          var currVal_12 = _ck(_v, 26, 0, _v.context.$implicit.color, _v.context.$implicit.textColor);

          _ck(_v, 25, 0, currVal_12);

          var currVal_17 = (_v.context.$implicit == null ? null : _v.context.$implicit.jobDescription) || (_v.context.$implicit == null ? null : _v.context.$implicit.jobDescription) != null;

          _ck(_v, 53, 0, currVal_17);

          var currVal_18 = !(_co.myApplicationsTable == null ? null : _co.myApplicationsTable.length);

          _ck(_v, 55, 0, currVal_18);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.index == _co.myApplicationsTable.length - 1;

          _ck(_v, 1, 0, currVal_0);

          var currVal_3 = _v.context.$implicit == null ? null : _v.context.$implicit.trId;

          _ck(_v, 9, 0, currVal_3);

          var currVal_4 = _v.context.$implicit.jobTitle;

          _ck(_v, 10, 0, currVal_4);

          var currVal_5 = _v.context.$implicit == null ? null : _v.context.$implicit.jobTitle;

          _ck(_v, 11, 0, currVal_5);

          var currVal_6 = _v.context.$implicit.primarySkills;

          _ck(_v, 12, 0, currVal_6);

          var currVal_7 = _v.context.$implicit == null ? null : _v.context.$implicit.primarySkills;

          _ck(_v, 13, 0, currVal_7);

          var currVal_8 = _v.context.$implicit == null ? null : _v.context.$implicit.totalExperience;

          _ck(_v, 15, 0, currVal_8);

          var currVal_9 = _v.context.$implicit == null ? null : _v.context.$implicit.location;

          _ck(_v, 17, 0, currVal_9);

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵunv"](_v, 19, 0, _ck(_v, 20, 0, _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v.parent.parent.parent.parent, 0), _v.context.$implicit == null ? null : _v.context.$implicit.appliedDate, "dd-MM-yyyy"));

          _ck(_v, 19, 0, currVal_10);

          var currVal_11 = _v.context.$implicit == null ? null : _v.context.$implicit.recruiterName;

          _ck(_v, 22, 0, currVal_11);

          var currVal_13 = _v.context.$implicit.statusName;

          _ck(_v, 27, 0, currVal_13);

          var currVal_14 = _co.expandedApplicationsRow == _v.context.index ? "expanded" : "collapsed";

          _ck(_v, 28, 0, currVal_14);

          var currVal_15 = _v.context.$implicit == null ? null : _v.context.$implicit.primarySkills;

          _ck(_v, 43, 0, currVal_15);

          var currVal_16 = _v.context.$implicit == null ? null : _v.context.$implicit.secondarySkills;

          _ck(_v, 47, 0, currVal_16);
        });
      }

      function View_JobMobilityComponent_95(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 25, "div", [["class", "col-12 ml-2 mt-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "div", [["style", "color: rgb(33, 37, 41); font-size: 16px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 23, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 22, "table", [["class", "table mb-3"], ["id", "myTable"], ["style", "width:98%;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 18, "thead", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 17, "tr", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 0, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["TR #"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Position"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applied Date"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Recruiter"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Status"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 2, "tbody", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_96)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](25, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.myApplicationsTable;

          _ck(_v, 25, 0, currVal_0);
        }, null);
      }

      function View_JobMobilityComponent_101(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["class", "mt-1 col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "d-flex"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["class", "ml-2 mt-3 navigation-link"], ["src", "../../assets/images/ArrowUUpLeft.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.clickMyApplicationsData() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "h4", [["class", "mt-3 ml-2"], ["style", "color: #000000;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", " Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 1, "app-job-details", [], null, null, null, _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["View_JobDetailsComponent_0"], _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["RenderType_JobDetailsComponent"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 770048, null, 0, _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_8__["JobDetailsComponent"], [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_9__["Router"], _providers_utility_service__WEBPACK_IMPORTED_MODULE_10__["UtilityService"], _providers_jump_service__WEBPACK_IMPORTED_MODULE_11__["JumpService"]], {
          jobDetails: [0, "jobDetails"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.selectedJob;

          _ck(_v, 6, 0, currVal_1);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.link;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_94(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "row matTab"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_95)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_101)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.isMyApplicationsHidden;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = !_co.isMyApplicationsHidden;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobMobilityComponent_2(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 16777216, null, null, 11, "mat-tab", [["id", "matTab"]], null, null, null, _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["View_MatTab_0"], _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["RenderType_MatTab"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 770048, [[3, 4]], 2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTab"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], [2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TAB_GROUP"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 4, {
          templateLabel: 0
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](335544320, 5, {
          _explicitContent: 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_3)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 16384, [[4, 4]], 0, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabLabel"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_4)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_44)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](9, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, 0, 1, null, View_JobMobilityComponent_94)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](11, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          _ck(_v, 1, 0);

          var currVal_0 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == "dashboard";

          _ck(_v, 7, 0, currVal_0);

          var currVal_1 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == "open-roles";

          _ck(_v, 9, 0, currVal_1);

          var currVal_2 = (_v.context.$implicit == null ? null : _v.context.$implicit.value) == "my-applications";

          _ck(_v, 11, 0, currVal_2);
        }, null);
      }

      function View_JobMobilityComponent_102(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_103(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applied Date : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobMobilityComponent_104(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "div", [["class", ""], ["style", "text-align: center;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobMobilityComponent_105(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes cannot exceed 2000 characters"]))], null, null);
      }

      function View_JobMobilityComponent_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpid"](0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["DatePipe"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["LOCALE_ID"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 1, {
          dropdownWrapper: 0
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 2, {
          fileInput: 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 23, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 15, "div", [["class", "banner-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 7, "div", [["class", "banner-image"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 0, "img", [["height", "30px"], ["src", "../../assets/images/trianz-logo-vertical-inverse.jpg"], ["style", "margin-left: 164px;\n      margin-top: 7px;"], ["width", "30px"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 5, "p", [["class", "profile-tooltip"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "span", [["class", "contact"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](9, null, ["Support: ", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 0, "img", [["alt", "Profile"], ["class", "profileStyle"], ["src", "../../assets/images/profile-download.svg"], ["style", "border-radius:5px;height: 22px;"]], null, [[null, "mouseenter"], [null, "mouseleave"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("mouseenter" === en) {
            var pd_0 = (_co.showProfileInfo = true) !== false;
            ad = pd_0 && ad;
          }

          if ("mouseleave" === en) {
            var pd_1 = (_co.showProfileInfo = false) !== false;
            ad = pd_1 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](12, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 6, "div", [["class", "jump"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 0, "img", [["src", "../../assets/images/JUMP-Logo-high-resolution-inverse.png"], ["style", "width: 243px;\n      height: 110px;\n      margin-left: -19px;margin-bottom: 44px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 4, "div", [["class", "title-div"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](16, 0, null, null, 1, "p", [["class", "jump-title"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Unlimited Mobility Program "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 1, "p", [["class", "sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Search | Apply | Qualify | Transition"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 6, "div", [["class", "content-section"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 5, "mat-tab-group", [["class", "mat-tab-group"], ["style", "width: 100%;"]], [[2, "mat-tab-group-dynamic-height", null], [2, "mat-tab-group-inverted-header", null]], [[null, "selectedIndexChange"], [null, "selectedTabChange"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("selectedIndexChange" === en) {
            var pd_0 = (_co.selectedIndex = $event) !== false;
            ad = pd_0 && ad;
          }

          if ("selectedTabChange" === en) {
            var pd_1 = _co.categoryTabClick(_co.selectedIndex) !== false;
            ad = pd_1 && ad;
          }

          return ad;
        }, _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["View_MatTabGroup_0"], _node_modules_angular_material_tabs_index_ngfactory__WEBPACK_IMPORTED_MODULE_4__["RenderType_MatTabGroup"])), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](6144, null, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TAB_GROUP"], null, [_angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabGroup"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](23, 3325952, null, 1, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MatTabGroup"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"], [2, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_5__["MAT_TABS_CONFIG"]], [2, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_6__["ANIMATION_MODULE_TYPE"]]], {
          selectedIndex: [0, "selectedIndex"]
        }, {
          selectedIndexChange: "selectedIndexChange",
          selectedTabChange: "selectedTabChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](603979776, 3, {
          _allTabs: 1
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_2)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](26, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 53, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "candidateModal"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 52, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 51, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 3, "div", [["class", "modal-header d-flex justify-content-between"], ["style", "padding:13px 25px 10px 22px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 1, "div", [["style", "font-weight: 600;font-size: 18px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](33, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](34, 0, null, null, 0, "img", [["aria-label", "Close"], ["class", "modal-close-btn"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"], ["style", "cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeEmpDataModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](35, 0, null, null, 45, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_102)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](37, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 42, "div", [["class", "row"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Name : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](43, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](45, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Email : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](47, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](48, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](49, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](50, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Mobile : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](52, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](53, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](54, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](55, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](57, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](58, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](59, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](60, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Total Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](62, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](63, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](64, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](65, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](67, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](68, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_103)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](70, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](71, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](72, 0, null, null, 1, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](74, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](75, 0, null, null, 0, "textarea", [["class", "form-control input-div"], ["cols", "3"], ["readonly", ""], ["rows", "3"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](76, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](77, 0, null, null, 1, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](79, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](80, 0, null, null, 0, "textarea", [["class", "form-control input-div"], ["cols", "3"], ["readonly", ""], ["rows", "3"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](81, 0, null, null, 10, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "history"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](82, 0, null, null, 9, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](83, 0, null, null, 8, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](84, 0, null, null, 3, "div", [["class", "modal-header d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](85, 0, null, null, 1, "div", [["style", "font-weight: 600;font-size: 18px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](86, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](87, 0, null, null, 0, "img", [["aria-label", "Close"], ["class", "modal-close-btn"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeHistoryModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](88, 0, null, null, 3, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_104)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](90, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](91, 0, null, null, 0, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](92, 0, null, null, 19, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "notes"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](93, 0, null, null, 18, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](94, 0, null, null, 17, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](95, 0, null, null, 3, "div", [["class", "modal-header d-flex justify-content-between"], ["style", "padding:13px 14px 10px 14px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](96, 0, null, null, 1, "div", [["style", "font-weight: 600;font-size: 18px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](98, 0, null, null, 0, "img", [["aria-label", "Close"], ["class", "modal-close-btn"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"], ["style", "cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](99, 0, null, null, 12, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](100, 0, null, null, 8, "div", [["class", "form-group pt-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](101, 0, null, null, 5, "textarea", [["class", "form-control input-div"], ["cols", "50"], ["rows", "9"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 102)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 102).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 102)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 102)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_4 = (_co.notesComments = $event) !== false;
            ad = pd_4 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](102, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](104, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](106, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobMobilityComponent_105)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](108, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](109, 0, null, null, 2, "div", [["class", "float-right"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](110, 0, null, null, 1, "button", [["class", "btn mt-2 ml-3 save-btn"], ["type", "submit"]], [[8, "disabled", 0]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.saveNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Save"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_1 = _co.showProfileInfo;

          _ck(_v, 12, 0, currVal_1);

          var currVal_4 = _co.selectedIndex;

          _ck(_v, 23, 0, currVal_4);

          var currVal_5 = _co.tabs;

          _ck(_v, 26, 0, currVal_5);

          var currVal_7 = _co.loading == true;

          _ck(_v, 37, 0, currVal_7);

          var currVal_14 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 70, 0, currVal_14);

          var currVal_18 = _co.loading == true;

          _ck(_v, 90, 0, currVal_18);

          var currVal_26 = _co.notesComments;

          _ck(_v, 104, 0, currVal_26);

          var currVal_27 = (_co.notesComments == null ? null : _co.notesComments.length) > 2000;

          _ck(_v, 108, 0, currVal_27);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.jumpEmail;

          _ck(_v, 9, 0, currVal_0);

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 23).dynamicHeight;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 23).headerPosition === "below";

          _ck(_v, 21, 0, currVal_2, currVal_3);

          var currVal_6 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 33, 0, currVal_6);

          var currVal_8 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 43, 0, currVal_8);

          var currVal_9 = _co.empData == null ? null : _co.empData.email;

          _ck(_v, 48, 0, currVal_9);

          var currVal_10 = _co.empData == null ? null : _co.empData.mobile;

          _ck(_v, 53, 0, currVal_10);

          var currVal_11 = _co.empData == null ? null : _co.empData.location;

          _ck(_v, 58, 0, currVal_11);

          var currVal_12 = _co.empData == null ? null : _co.empData.totalExperience;

          _ck(_v, 63, 0, currVal_12);

          var currVal_13 = _co.empData == null ? null : _co.empData.trianzExperience;

          _ck(_v, 68, 0, currVal_13);

          var currVal_15 = _co.empData == null ? null : _co.empData.primarySkills;

          _ck(_v, 75, 0, currVal_15);

          var currVal_16 = _co.empData == null ? null : _co.empData.secondarySkills;

          _ck(_v, 80, 0, currVal_16);

          var currVal_17 = _co.candidateName;

          _ck(_v, 86, 0, currVal_17);

          var currVal_19 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassUntouched;

          var currVal_20 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassTouched;

          var currVal_21 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassPristine;

          var currVal_22 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassDirty;

          var currVal_23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassValid;

          var currVal_24 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassInvalid;

          var currVal_25 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 106).ngClassPending;

          _ck(_v, 101, 0, currVal_19, currVal_20, currVal_21, currVal_22, currVal_23, currVal_24, currVal_25);

          var currVal_28 = _co.notesComments == "" || (_co.notesComments == null ? null : _co.notesComments.length) > 2000 || _co.changeComment == _co.notesComments;

          _ck(_v, 110, 0, currVal_28);
        });
      }

      function View_JobMobilityComponent_Host_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "app-job-mobility", [], null, null, null, View_JobMobilityComponent_0, RenderType_JobMobilityComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 114688, null, 0, _job_mobility_component__WEBPACK_IMPORTED_MODULE_12__["JobMobilityComponent"], [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _providers_jump_service__WEBPACK_IMPORTED_MODULE_11__["JumpService"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]], null, null)], function (_ck, _v) {
          _ck(_v, 1, 0);
        }, null);
      }

      var JobMobilityComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("app-job-mobility", _job_mobility_component__WEBPACK_IMPORTED_MODULE_12__["JobMobilityComponent"], View_JobMobilityComponent_Host_0, {}, {}, []);
      /***/

    },

    /***/
    "OvOj":
    /*!****************************************************!*\
      !*** ./src/app/app.component.scss.shim.ngstyle.js ***!
      \****************************************************/

    /*! exports provided: styles */

    /***/
    function OvOj(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "styles", function () {
        return styles;
      });
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles = [".shadow[_ngcontent-%COMP%] {\n  box-shadow: 0px 3px 2px var(--header-shadow) !important;\n}\n\n.pgap[_ngcontent-%COMP%] {\n  font-size: 16px;\n  font-weight: 500;\n  margin-right: 35px;\n  cursor: pointer;\n}\n\n.pgap[_ngcontent-%COMP%]:hover {\n  color: #039CCE;\n}\n\n.search-bg[_ngcontent-%COMP%] {\n  background: var(--search-bg);\n}\n\n.sidenavi[_ngcontent-%COMP%] {\n  position: fixed;\n  left: -1px;\n  width: 56px;\n  height: 100%;\n  background: #F1F1F1 0% 0% no-repeat padding-box;\n  box-shadow: 0px 3px 6px #00000029;\n}\n\n.profileStyle[_ngcontent-%COMP%] {\n  height: 40px;\n  margin-bottom: 10px;\n  cursor: pointer;\n}\n\n.imageBadge[_ngcontent-%COMP%] {\n  display: inline-block;\n  \n  position: relative;\n}\n\n.Badge[_ngcontent-%COMP%] {\n  position: absolute;\n  bottom: 9px;\n  \n  right: 0px;\n  width: 10px;\n  height: 10px;\n  border-radius: 100px;\n}\n\n.sidenav[_ngcontent-%COMP%] {\n  height: 100%;\n  width: 0;\n  position: fixed;\n  z-index: 1;\n  top: 0;\n  left: 0;\n  margin-left: 56px;\n  background-color: white;\n  overflow-x: hidden;\n  transition: 0.5s;\n  padding-top: 10px;\n  box-shadow: 0px 3px 6px #00000029;\n}\n\n.sidenav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  padding: 8px 8px 8px 32px;\n  text-decoration: none;\n  font-size: 25px;\n  color: #009BFF;\n  display: block;\n  transition: 0.3s;\n}\n\n.sidenav[_ngcontent-%COMP%]   .closebtn[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  right: 10px;\n  font-size: 36px;\n  margin-left: 50px;\n}\n\n.logo-text[_ngcontent-%COMP%] {\n  font-size: 24px;\n  letter-spacing: 0px;\n  color: #000000;\n  text-transform: capitalize;\n  opacity: 1;\n  font-weight: 600;\n  vertical-align: middle;\n  margin-right: 20px;\n}\n\n.logo-text[_ngcontent-%COMP%] {\n  font-size: 24px;\n  letter-spacing: 0px;\n  color: #000000;\n  text-transform: capitalize;\n  opacity: 1;\n  font-weight: 600;\n  vertical-align: middle;\n  margin-right: 20px;\n}\n\n.dropbtn[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n}\n\n.dropbtn[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n  padding: 10px;\n  font-size: 15px;\n  border: none;\n  background: transparent;\n  outline: #fff;\n  margin-top: 3px;\n}\n\n.dropbtn[_ngcontent-%COMP%]:hover, .dropbtn[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  color: #039cce;\n}\n\n.dropbtnSelected[_ngcontent-%COMP%] {\n  color: #039cce;\n  padding: 10px;\n  font-size: 15px;\n  border: none;\n  background: transparent;\n  outline: #fff;\n  margin-top: 3px;\n}\n\n.dropdown[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  margin: -4px 6px;\n}\n\n.dropdown-menu.show[_ngcontent-%COMP%] {\n  background-color: var(--menu-bg);\n  min-width: 160px;\n  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n  z-index: 1;\n  border: none;\n  top: 5px !important;\n}\n\n.dropdown-menu.menu-width.show[_ngcontent-%COMP%] {\n  width: 100vw;\n}\n\n.dropdown-toggle[_ngcontent-%COMP%]::after {\n  display: none;\n}\n\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  background: var(--menu-hover);\n}\n\n.dropdown-menu[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: var(--on-background);\n  padding: 5px 10px;\n  text-decoration: none;\n  display: block;\n  font-size: 14px;\n}\n\n.drp-icon[_ngcontent-%COMP%] {\n  color: #f6f6f6;\n  position: absolute;\n  top: -22px;\n  left: 3rem;\n  font-size: 27px;\n}\n\n.close-btn[_ngcontent-%COMP%] {\n  position: absolute;\n  \n  right: 15px;\n  top: 10px;\n  cursor: pointer;\n}\n\n.submenu-content[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 196px;\n  padding: 15px 20px;\n}\n\n.submenu-heading[_ngcontent-%COMP%] {\n  padding: 0px 9px;\n  font-size: 14px;\n  color: #000000;\n  font-weight: 600;\n}\n\n.has-search[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  padding-left: 10px;\n  background: var(--search-bg);\n  color: #b2b2b2;\n  border: none;\n  outline: none;\n  border: 0;\n  width: 300px;\n}\n\n.search-bg[_ngcontent-%COMP%] {\n  background: var(--search-bg);\n}\n\n.has-search[_ngcontent-%COMP%]   .form-control-feedback[_ngcontent-%COMP%] {\n  cursor: pointer;\n  padding: 10px;\n  color: #aaa;\n}\n\n.a-tag[_ngcontent-%COMP%] {\n  display: inline-block !important;\n}\n\n.nolink[_ngcontent-%COMP%]:hover {\n  background: transparent !important;\n}\n\n@media screen and (max-height: 450px) {\n  .sidenav[_ngcontent-%COMP%] {\n    padding-top: 15px;\n  }\n\n  .sidenav[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    font-size: 18px;\n  }\n}\n\n.icon[_ngcontent-%COMP%] {\n  padding: 9px;\n  box-shadow: 0px 3px 6px #00000029;\n  cursor: pointer;\n}\n\n.iconSpacing[_ngcontent-%COMP%] {\n  margin-left: 7px;\n  margin-top: 15px;\n}\n\nspan.line-tx[_ngcontent-%COMP%] {\n  font-size: 14px;\n  font-weight: 400;\n  color: #000000;\n  cursor: pointer;\n}\n\n.top-right[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 23px;\n  z-index: 9999 !important;\n}\n\n.common-title[_ngcontent-%COMP%] {\n  width: 90%;\n  color: #000000;\n  font-weight: 600;\n  padding: 10px 0px 0px 13px;\n  margin-bottom: 8px;\n}\n\na[_ngcontent-%COMP%] {\n  text-decoration: none;\n}\n\n.icon-img[_ngcontent-%COMP%] {\n  width: 22px;\n  height: 22px;\n}\n\n.naming[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}\n\n.caret-img[_ngcontent-%COMP%] {\n  height: 54px;\n  position: absolute;\n  top: -34px;\n  left: 2rem;\n}\n\n.caret-img1[_ngcontent-%COMP%] {\n  height: 54px;\n  position: absolute;\n  top: -34px;\n  left: 26rem;\n}\n\n.caret-img2[_ngcontent-%COMP%] {\n  height: 54px;\n  position: absolute;\n  top: -34px;\n  left: 19rem;\n}\n\n.cursorPointer[_ngcontent-%COMP%]    > *[_ngcontent-%COMP%] {\n  pointer-events: none;\n}\n\n.logo-div[_ngcontent-%COMP%] {\n  cursor: pointer;\n  width: 150px;\n  height: 43px;\n  margin-top: -2px;\n}\n\n@media only screen and (min-width: 768px) and (max-width: 1024px) {\n  .logo-div[_ngcontent-%COMP%] {\n    cursor: pointer;\n    width: 115px;\n    height: 43px;\n    margin-top: -3px;\n  }\n\n  .dropbtn[_ngcontent-%COMP%] {\n    font-size: 13px;\n    margin-top: 4px;\n  }\n\n  .has-search[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n    font-size: 14px;\n    width: 220px;\n  }\n\n  img.serach-img[_ngcontent-%COMP%] {\n    width: 16px;\n  }\n\n  .dropdown-menu[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n    font-size: 12px;\n  }\n}\n\n@media only screen and (min-width: 600px) and (max-width: 800px) {\n  .logo-div[_ngcontent-%COMP%] {\n    cursor: pointer;\n    width: 84px;\n    height: 38px;\n    margin-top: 2px;\n  }\n\n  .dropdown[_ngcontent-%COMP%] {\n    margin: -4px 2px;\n  }\n\n  .dropbtn[_ngcontent-%COMP%] {\n    font-size: 10px;\n    margin-top: 7px;\n  }\n\n  .has-search[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n    font-size: 11px;\n    width: 155px;\n  }\n\n  img.serach-img[_ngcontent-%COMP%] {\n    width: 12px;\n    margin-top: -5px;\n  }\n\n  .dropbtnSelected[_ngcontent-%COMP%] {\n    padding: 12px;\n    font-size: 11px;\n  }\n}\n\n.dropdown-menu.transform.show[_ngcontent-%COMP%] {\n  transform: translate3d(-28px, 45px, 0px) !important;\n}\n\n.switch[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  width: 56px;\n  height: 27px;\n  top: 0px;\n  \n  float: right;\n  margin-right: 2rem;\n}\n\n.switch[_ngcontent-%COMP%]   input[_ngcontent-%COMP%] {\n  display: none;\n}\n\n.slider[_ngcontent-%COMP%] {\n  position: absolute;\n  cursor: pointer;\n  top: 0;\n  left: 0;\n  right: 0;\n  bottom: 0;\n  background-color: rgba(0, 0, 0, 0.5);\n  transition: 0.4s;\n}\n\n.slider[_ngcontent-%COMP%]:before {\n  position: absolute;\n  content: \"\";\n  height: 20px;\n  width: 20px;\n  left: 7px;\n  bottom: 4px;\n  background-color: white;\n  transition: 0.4s;\n}\n\ninput[_ngcontent-%COMP%]:checked    + .slider[_ngcontent-%COMP%] {\n  background-color: #039CCE;\n}\n\ninput[_ngcontent-%COMP%]:focus    + .slider[_ngcontent-%COMP%] {\n  box-shadow: 0 0 1px #2196F3;\n}\n\ninput[_ngcontent-%COMP%]:checked    + .slider[_ngcontent-%COMP%]:before {\n  transform: translateX(26px);\n}\n\n\n\n.slider.round[_ngcontent-%COMP%] {\n  border-radius: 34px;\n}\n\n.slider.round[_ngcontent-%COMP%]:before {\n  border-radius: 50%;\n}\n\n.nav-div[_ngcontent-%COMP%] {\n  background: var(--navbackground);\n  color: var(--on-background);\n  padding-top: 10px;\n  padding-bottom: 5px;\n  height: 60px;\n  position: fixed;\n  top: 0;\n  left: 0;\n  right: 0;\n  z-index: 9999;\n}\n\n.modal.left[_ngcontent-%COMP%]   .modal-dialog[_ngcontent-%COMP%] {\n  position: fixed;\n  right: 0;\n  margin: auto;\n  top: 3.8rem;\n  width: 320px;\n  height: 91%;\n  transform: translate3d(0%, 0, 0);\n}\n\n.modal.left[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  height: 100%;\n  overflow-y: auto;\n}\n\n.font-sz[_ngcontent-%COMP%] {\n  font-size: 19px;\n  color: var(--on-primary);\n}\n\n.lable-col[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n}\n\n.modal-body[_ngcontent-%COMP%] {\n  background: var(--navbackground);\n}\n\n.dropdown2[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.dropdown-content[_ngcontent-%COMP%] {\n  display: none;\n  position: absolute;\n  background-color: #f1f1f1;\n  min-width: 160px;\n  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n  z-index: 1;\n  right: -151px;\n  top: 0;\n  border-radius: 10px;\n}\n\n.dropdown-content[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: black;\n  padding: 5px 10px;\n  text-decoration: none;\n  display: block;\n}\n\n.dropdown-content[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]:hover {\n  background-color: #ddd;\n}\n\n.dropdown2[_ngcontent-%COMP%]:hover   .dropdown-content[_ngcontent-%COMP%] {\n  display: block;\n}\n\n.modal-content[_ngcontent-%COMP%] {\n  border: none;\n  border-radius: unset;\n}\n\n.feedback-text[_ngcontent-%COMP%] {\n  text-align: left;\n  font-size: 14px;\n  letter-spacing: 0px;\n  color: #FF6600;\n  margin-left: 21px;\n  margin-top: 2rem;\n  cursor: pointer;\n}\n\n.textColor[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n}\n\n.modal-content[_ngcontent-%COMP%] {\n  background: var(--navbackground) !important;\n}\n\n.form-control[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n}\n\n.modal-title[_ngcontent-%COMP%] {\n  color: var(--on-primary);\n}\n\n.publish-head[_ngcontent-%COMP%] {\n  height: 34px;\n  background: #f1f1f1;\n  padding: 6px;\n}\n\n.div-subtab[_ngcontent-%COMP%] {\n  padding: 20px;\n  cursor: pointer;\n}\n\n.dropdown-submenu[_ngcontent-%COMP%] {\n  position: relative;\n  margin-left: 5px;\n}\n\n.dropdown-submenu[_ngcontent-%COMP%]   a[_ngcontent-%COMP%]::after {\n  transform: rotate(-90deg);\n  position: absolute;\n  right: 3px;\n  top: 40%;\n}\n\n.dropdown-submenu[_ngcontent-%COMP%]:hover   .dropdown-menu[_ngcontent-%COMP%], .dropdown-submenu[_ngcontent-%COMP%]:focus   .dropdown-menu[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  position: absolute !important;\n  margin-top: -30px;\n  left: 100%;\n}\n\n@media (max-width: 992px) {\n  .dropdown-menu[_ngcontent-%COMP%] {\n    width: 50%;\n  }\n\n  .dropdown-menu[_ngcontent-%COMP%]   .dropdown-submenu[_ngcontent-%COMP%] {\n    width: auto;\n  }\n}\n\n.container[_ngcontent-%COMP%] {\n  margin-top: 78px;\n}\n\n.tooltip[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.tooltip[_ngcontent-%COMP%]   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 201px;\n  background-color: #fff;\n  color: black;\n  text-align: center;\n  border-radius: 6px;\n  padding: 5px 0;\n  position: absolute;\n  z-index: 1;\n  top: 31px;\n  right: -103px;\n  transform: translateX(-50%);\n  opacity: 0;\n  transition: opacity 0.3s;\n  border: 2px solid white;\n}\n\n.tooltip[_ngcontent-%COMP%]   .tooltip-text[_ngcontent-%COMP%]::after {\n  content: \"\";\n  position: absolute;\n  bottom: 100%;\n  \n  left: 50%;\n  transform: translateX(-50%);\n  border-width: 5px;\n  border-style: solid;\n  border-color: transparent transparent white transparent;\n  \n}\n\n.tooltip[_ngcontent-%COMP%]:hover   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: visible;\n  opacity: 1;\n}\n\n.loader-background[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 1000;\n}\n\n.loaderDiv[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 60%;\n  left: 55%;\n  transform: translate(-50%, -50%);\n  font-size: 60px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksdURBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQUNKOztBQUVBO0VBQ0ksY0FBQTtBQUNKOztBQUVBO0VBQ0ksNEJBQUE7QUFDSjs7QUFFQTtFQUNJLGVBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSwrQ0FBQTtFQUNBLGlDQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBRUE7RUFDSSxxQkFBQTtFQUNBLG9FQUFBO0VBQ0Esa0JBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLCtCQUFBO0VBQ0EsVUFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxRQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLGlCQUFBO0VBQ0EsdUJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQ0FBQTtBQUNKOztBQUdBO0VBQ0kseUJBQUE7RUFDQSxxQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBQUo7O0FBR0E7RUFDSSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxXQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FBQUo7O0FBR0E7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBQUo7O0FBR0E7RUFDSSxlQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsMEJBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxzQkFBQTtFQUNBLGtCQUFBO0FBQUo7O0FBRUE7RUFDSSx3QkFBQTtBQUNKOztBQUNBO0VBQ0ksd0JBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7RUFDQSx1QkFBQTtFQUNBLGFBQUE7RUFFQSxlQUFBO0FBQ0o7O0FBQ0E7O0VBRUksY0FBQTtBQUVKOztBQUFBO0VBQ0ksY0FBQTtFQUNBLGFBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtFQUVBLGVBQUE7QUFFSjs7QUFDQTtFQUNJLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxnQkFBQTtBQUVKOztBQUNBO0VBQ0ksZ0NBQUE7RUFDQSxnQkFBQTtFQUNBLCtDQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQUVKOztBQUNBO0VBQ0ksWUFBQTtBQUVKOztBQUNBO0VBQ0ksYUFBQTtBQUVKOztBQUVBO0VBQ0ksNkJBQUE7QUFDSjs7QUFFQTtFQUNJLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBQ0o7O0FBR0E7RUFDSSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtFQUNBLGVBQUE7QUFBSjs7QUFHQTtFQUNJLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7QUFBSjs7QUFHQTtFQUNJLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBQUo7O0FBSUE7RUFDSSxnQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFESjs7QUFLQTtFQUNJLGtCQUFBO0VBRUEsNEJBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxTQUFBO0VBQ0EsWUFBQTtBQUhKOztBQU1BO0VBQ0ksNEJBQUE7QUFISjs7QUFNQTtFQUNJLGVBQUE7RUFDQSxhQUFBO0VBQ0EsV0FBQTtBQUhKOztBQU1BO0VBQ0ksZ0NBQUE7QUFISjs7QUFNQTtFQUNJLGtDQUFBO0FBSEo7O0FBTUE7RUFDSTtJQUNJLGlCQUFBO0VBSE47O0VBS0U7SUFDSSxlQUFBO0VBRk47QUFDRjs7QUFLQTtFQUNJLFlBQUE7RUFDQSxpQ0FBQTtFQUNBLGVBQUE7QUFISjs7QUFNQTtFQUNJLGdCQUFBO0VBQ0EsZ0JBQUE7QUFISjs7QUFNQTtFQUNJLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0FBSEo7O0FBTUE7RUFDSSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0Esd0JBQUE7QUFISjs7QUFNQTtFQUNJLFVBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0FBSEo7O0FBTUE7RUFDSSxxQkFBQTtBQUhKOztBQU1BO0VBQ0ksV0FBQTtFQUNBLFlBQUE7QUFISjs7QUFNQTtFQUNJLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQUhKOztBQU1BO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7QUFISjs7QUFNQTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0FBSEo7O0FBTUE7RUFDSSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtBQUhKOztBQU1BO0VBQ0ksb0JBQUE7QUFISjs7QUFNQTtFQUNJLGVBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGdCQUFBO0FBSEo7O0FBTUE7RUFDSTtJQUNJLGVBQUE7SUFDQSxZQUFBO0lBQ0EsWUFBQTtJQUNBLGdCQUFBO0VBSE47O0VBS0U7SUFDSSxlQUFBO0lBQ0EsZUFBQTtFQUZOOztFQUlFO0lBQ0ksZUFBQTtJQUNBLFlBQUE7RUFETjs7RUFHRTtJQUNJLFdBQUE7RUFBTjs7RUFFRTtJQUNJLGVBQUE7RUFDTjtBQUNGOztBQUVBO0VBQ0k7SUFDSSxlQUFBO0lBQ0EsV0FBQTtJQUNBLFlBQUE7SUFDQSxlQUFBO0VBQU47O0VBRUU7SUFDSSxnQkFBQTtFQUNOOztFQUNFO0lBQ0ksZUFBQTtJQUNBLGVBQUE7RUFFTjs7RUFBRTtJQUNJLGVBQUE7SUFDQSxZQUFBO0VBR047O0VBREU7SUFDSSxXQUFBO0lBQ0EsZ0JBQUE7RUFJTjs7RUFGRTtJQUNJLGFBQUE7SUFDQSxlQUFBO0VBS047QUFDRjs7QUFGQTtFQUNJLG1EQUFBO0FBSUo7O0FBREE7RUFDSSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxRQUFBO0VBQ0EsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFJSjs7QUFEQTtFQUNJLGFBQUE7QUFJSjs7QUFEQTtFQUNJLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxvQ0FBQTtFQUVBLGdCQUFBO0FBSUo7O0FBREE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFNBQUE7RUFDQSxXQUFBO0VBQ0EsdUJBQUE7RUFFQSxnQkFBQTtBQUlKOztBQURBO0VBQ0kseUJBQUE7QUFJSjs7QUFEQTtFQUNJLDJCQUFBO0FBSUo7O0FBREE7RUFHSSwyQkFBQTtBQUlKOztBQUFBLG9CQUFBOztBQUVBO0VBQ0ksbUJBQUE7QUFFSjs7QUFDQTtFQUNJLGtCQUFBO0FBRUo7O0FBQ0E7RUFDSSxnQ0FBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsYUFBQTtBQUVKOztBQUNBO0VBQ0ksZUFBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBSUEsZ0NBQUE7QUFFSjs7QUFDQTtFQUNJLFlBQUE7RUFDQSxnQkFBQTtBQUVKOztBQUNBO0VBQ0ksZUFBQTtFQUNBLHdCQUFBO0FBRUo7O0FBQ0E7RUFDSSx3QkFBQTtBQUVKOztBQUNBO0VBQ0ksZ0NBQUE7QUFFSjs7QUFDQTtFQUNJLGtCQUFBO0VBQ0EscUJBQUE7QUFFSjs7QUFDQTtFQUNJLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSwrQ0FBQTtFQUNBLFVBQUE7RUFDQSxhQUFBO0VBQ0EsTUFBQTtFQUNBLG1CQUFBO0FBRUo7O0FBQ0E7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGNBQUE7QUFFSjs7QUFDQTtFQUNJLHNCQUFBO0FBRUo7O0FBQ0E7RUFDSSxjQUFBO0FBRUo7O0FBQ0E7RUFDSSxZQUFBO0VBQ0Esb0JBQUE7QUFFSjs7QUFDQTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FBRUo7O0FBQ0E7RUFDSSx3QkFBQTtBQUVKOztBQUNBO0VBQ0ksMkNBQUE7QUFFSjs7QUFDQTtFQUNJLHdCQUFBO0FBRUo7O0FBQ0E7RUFDSSx3QkFBQTtBQUVKOztBQUNBO0VBQ0ksWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtBQUVKOztBQUVBO0VBQ0ksYUFBQTtFQUNBLGVBQUE7QUFDSjs7QUFDQTtFQUNJLGtCQUFBO0VBQ0EsZ0JBQUE7QUFFSjs7QUFBQTtFQUNJLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsUUFBQTtBQUdKOztBQURBO0VBQ0ksYUFBQTtFQUNBLHNCQUFBO0VBQ0EsNkJBQUE7RUFDQSxpQkFBQTtFQUNBLFVBQUE7QUFJSjs7QUFGQTtFQUNJO0lBQ0ksVUFBQTtFQUtOOztFQUhFO0lBQ0ksV0FBQTtFQU1OO0FBQ0Y7O0FBSkE7RUFDSSxnQkFBQTtBQU1KOztBQURBO0VBQ0ksa0JBQUE7RUFDQSxxQkFBQTtBQUlKOztBQURFO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsYUFBQTtFQUNBLDJCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0VBQ0EsdUJBQUE7QUFJSjs7QUFERTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFBYyxvREFBQTtFQUNkLFNBQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0EsbUJBQUE7RUFDQSx1REFBQTtFQUF5RCxnQkFBQTtBQU03RDs7QUFIRTtFQUNFLG1CQUFBO0VBQ0EsVUFBQTtBQU1KOztBQUhFO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0FBTUo7O0FBRkU7RUFDRSxlQUFBO0VBQ0EsUUFBQTtFQUNBLFNBQUE7RUFDQSxnQ0FBQTtFQUNBLGVBQUE7QUFLSiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zaGFkb3cge1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCAycHggdmFyKC0taGVhZGVyLXNoYWRvdykgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnBnYXAge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICAgIG1hcmdpbi1yaWdodDogMzVweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnBnYXA6aG92ZXIge1xyXG4gICAgY29sb3I6ICMwMzlDQ0U7XHJcbn1cclxuXHJcbi5zZWFyY2gtYmcge1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0tc2VhcmNoLWJnKTtcclxufVxyXG5cclxuLnNpZGVuYXZpIHtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIGxlZnQ6IC0xcHg7XHJcbiAgICB3aWR0aDogNTZweDtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGJhY2tncm91bmQ6ICNGMUYxRjEgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG59XHJcblxyXG4ucHJvZmlsZVN0eWxlIHtcclxuICAgIGhlaWdodDogNDBweDtcclxuICAgIG1hcmdpbi1ib3R0b206IDEwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi5pbWFnZUJhZGdlIHtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIC8qIGtlZXBzIHRoZSBpbWcgd2l0aCB0aGUgYmFkZ2UgaWYgdGhlIGltZyBpcyBmb3JjZWQgdG8gYSBuZXcgbGluZSAqL1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG59XHJcblxyXG4uQmFkZ2Uge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiA5cHg7XHJcbiAgICAvKiBwb3NpdGlvbiB3aGVyZSB5b3Ugd2FudCBpdCAqL1xyXG4gICAgcmlnaHQ6IDBweDtcclxuICAgIHdpZHRoOiAxMHB4O1xyXG4gICAgaGVpZ2h0OiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTAwcHg7XHJcbn1cclxuXHJcbi5zaWRlbmF2IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIHdpZHRoOiAwO1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgei1pbmRleDogMTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICBtYXJnaW4tbGVmdDogNTZweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgdHJhbnNpdGlvbjogMC41cztcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG4gICAgO1xyXG59XHJcblxyXG4uc2lkZW5hdiBhIHtcclxuICAgIHBhZGRpbmc6IDhweCA4cHggOHB4IDMycHg7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBmb250LXNpemU6IDI1cHg7XHJcbiAgICBjb2xvcjogIzAwOUJGRjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgdHJhbnNpdGlvbjogMC4zcztcclxufVxyXG5cclxuLnNpZGVuYXYgLmNsb3NlYnRuIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIHJpZ2h0OiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiAzNnB4O1xyXG4gICAgbWFyZ2luLWxlZnQ6IDUwcHg7XHJcbn1cclxuXHJcbi5sb2dvLXRleHQge1xyXG4gICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDBweDtcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbi5sb2dvLXRleHQge1xyXG4gICAgZm9udC1zaXplOiAyNHB4O1xyXG4gICAgbGV0dGVyLXNwYWNpbmc6IDBweDtcclxuICAgIGNvbG9yOiAjMDAwMDAwO1xyXG4gICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG4gICAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICAgIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbn1cclxuLmRyb3BidG4gYXtcclxuICAgIGNvbG9yOiB2YXIoLS1vbi1wcmltYXJ5KTtcclxufVxyXG4uZHJvcGJ0biB7XHJcbiAgICBjb2xvcjogdmFyKC0tb24tcHJpbWFyeSk7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBvdXRsaW5lOiAjZmZmO1xyXG4gICAgXHJcbiAgICBtYXJnaW4tdG9wOiAzcHg7XHJcbn1cclxuLmRyb3BidG46aG92ZXIsXHJcbi5kcm9wYnRuIGE6aG92ZXIge1xyXG4gICAgY29sb3I6ICMwMzljY2U7XHJcbn1cclxuLmRyb3BidG5TZWxlY3RlZCB7XHJcbiAgICBjb2xvcjogIzAzOWNjZTtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIG91dGxpbmU6ICNmZmY7XHJcbiAgICBcclxuICAgIG1hcmdpbi10b3A6IDNweDtcclxufVxyXG5cclxuLmRyb3Bkb3duIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIG1hcmdpbjogLTRweCA2cHg7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1tZW51LnNob3cge1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0tbWVudS1iZyk7XHJcbiAgICBtaW4td2lkdGg6IDE2MHB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAxNnB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgYm9yZGVyOiBub25lO1xyXG4gICAgdG9wOiA1cHggIWltcG9ydGFudFxyXG59XHJcblxyXG4uZHJvcGRvd24tbWVudS5tZW51LXdpZHRoLnNob3cge1xyXG4gICAgd2lkdGg6IDEwMHZ3O1xyXG59XHJcblxyXG4uZHJvcGRvd24tdG9nZ2xlOjphZnRlciB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG4gICBcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW06aG92ZXIge1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0tbWVudS1ob3Zlcik7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1tZW51IGEge1xyXG4gICAgY29sb3I6IHZhcigtLW9uLWJhY2tncm91bmQpO1xyXG4gICAgcGFkZGluZzogNXB4IDEwcHg7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIFxyXG59XHJcblxyXG4uZHJwLWljb24ge1xyXG4gICAgY29sb3I6ICNmNmY2ZjY7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IC0yMnB4O1xyXG4gICAgbGVmdDogM3JlbTtcclxuICAgIGZvbnQtc2l6ZTogMjdweDtcclxufVxyXG5cclxuLmNsb3NlLWJ0biB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAvKiB6LWluZGV4OiAzMzM7ICovXHJcbiAgICByaWdodDogMTVweDtcclxuICAgIHRvcDogMTBweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnN1Ym1lbnUtY29udGVudCB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogMTk2cHg7XHJcbiAgICBwYWRkaW5nOiAxNXB4IDIwcHg7XHJcbiAgICBcclxufVxyXG5cclxuLnN1Ym1lbnUtaGVhZGluZyB7XHJcbiAgICBwYWRkaW5nOiAwcHggOXB4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgXHJcbn1cclxuXHJcbi5oYXMtc2VhcmNoIC5mb3JtLWNvbnRyb2wge1xyXG4gICAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gICAgLy8gYmFja2dyb3VuZDogI2YwZjBmMDtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLXNlYXJjaC1iZyk7XHJcbiAgICBjb2xvcjogI2IyYjJiMjtcclxuICAgIGJvcmRlcjogbm9uZTtcclxuICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICBib3JkZXI6IDA7XHJcbiAgICB3aWR0aDogMzAwcHg7XHJcbn1cclxuXHJcbi5zZWFyY2gtYmcge1xyXG4gICAgYmFja2dyb3VuZDogdmFyKC0tc2VhcmNoLWJnKTtcclxufVxyXG5cclxuLmhhcy1zZWFyY2ggLmZvcm0tY29udHJvbC1mZWVkYmFjayB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgY29sb3I6ICNhYWE7XHJcbn1cclxuXHJcbi5hLXRhZyB7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2sgIWltcG9ydGFudDtcclxufVxyXG5cclxuLm5vbGluazpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG5AbWVkaWEgc2NyZWVuIGFuZCAobWF4LWhlaWdodDogNDUwcHgpIHtcclxuICAgIC5zaWRlbmF2IHtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMTVweDtcclxuICAgIH1cclxuICAgIC5zaWRlbmF2IGEge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIH1cclxufVxyXG5cclxuLmljb24ge1xyXG4gICAgcGFkZGluZzogOXB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG4gICAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uaWNvblNwYWNpbmcge1xyXG4gICAgbWFyZ2luLWxlZnQ6IDdweDtcclxuICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbn1cclxuXHJcbnNwYW4ubGluZS10eCB7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBmb250LXdlaWdodDogNDAwO1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi50b3AtcmlnaHQge1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAxMHB4O1xyXG4gICAgcmlnaHQ6IDIzcHg7XHJcbiAgICB6LWluZGV4OiA5OTk5ICFpbXBvcnRhbnRcclxufVxyXG5cclxuLmNvbW1vbi10aXRsZSB7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgY29sb3I6ICMwMDAwMDA7XHJcbiAgICBmb250LXdlaWdodDogNjAwO1xyXG4gICAgcGFkZGluZzogMTBweCAwcHggMHB4IDEzcHg7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA4cHg7XHJcbn1cclxuXHJcbmEge1xyXG4gICAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG59XHJcblxyXG4uaWNvbi1pbWcge1xyXG4gICAgd2lkdGg6IDIycHg7XHJcbiAgICBoZWlnaHQ6IDIycHg7XHJcbn1cclxuXHJcbi5uYW1pbmcge1xyXG4gICAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxufVxyXG5cclxuLmNhcmV0LWltZyB7XHJcbiAgICBoZWlnaHQ6IDU0cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IC0zNHB4O1xyXG4gICAgbGVmdDogMnJlbTtcclxufVxyXG5cclxuLmNhcmV0LWltZzEge1xyXG4gICAgaGVpZ2h0OiA1NHB4O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiAtMzRweDtcclxuICAgIGxlZnQ6IDI2cmVtO1xyXG59XHJcblxyXG4uY2FyZXQtaW1nMiB7XHJcbiAgICBoZWlnaHQ6IDU0cHg7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB0b3A6IC0zNHB4O1xyXG4gICAgbGVmdDogMTlyZW07XHJcbn1cclxuXHJcbi5jdXJzb3JQb2ludGVyPioge1xyXG4gICAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuXHJcbi5sb2dvLWRpdiB7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICB3aWR0aDogMTUwcHg7XHJcbiAgICBoZWlnaHQ6IDQzcHg7XHJcbiAgICBtYXJnaW4tdG9wOiAtMnB4O1xyXG59XHJcblxyXG5AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6IDc2OHB4KSBhbmQgKG1heC13aWR0aDogMTAyNHB4KSB7XHJcbiAgICAubG9nby1kaXYge1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICB3aWR0aDogMTE1cHg7XHJcbiAgICAgICAgaGVpZ2h0OiA0M3B4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6IC0zcHg7XHJcbiAgICB9XHJcbiAgICAuZHJvcGJ0biB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDRweDtcclxuICAgIH1cclxuICAgIC5oYXMtc2VhcmNoIC5mb3JtLWNvbnRyb2wge1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICB3aWR0aDogMjIwcHg7XHJcbiAgICB9XHJcbiAgICBpbWcuc2VyYWNoLWltZyB7XHJcbiAgICAgICAgd2lkdGg6IDE2cHg7XHJcbiAgICB9XHJcbiAgICAuZHJvcGRvd24tbWVudSBhIHtcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbkBtZWRpYSBvbmx5IHNjcmVlbiBhbmQgKG1pbi13aWR0aDogNjAwcHgpIGFuZCAobWF4LXdpZHRoOiA4MDBweCkge1xyXG4gICAgLmxvZ28tZGl2IHtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgd2lkdGg6IDg0cHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzOHB4O1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDJweDtcclxuICAgIH1cclxuICAgIC5kcm9wZG93biB7XHJcbiAgICAgICAgbWFyZ2luOiAtNHB4IDJweDtcclxuICAgIH1cclxuICAgIC5kcm9wYnRuIHtcclxuICAgICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogN3B4O1xyXG4gICAgfVxyXG4gICAgLmhhcy1zZWFyY2ggLmZvcm0tY29udHJvbCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxMXB4O1xyXG4gICAgICAgIHdpZHRoOiAxNTVweDtcclxuICAgIH1cclxuICAgIGltZy5zZXJhY2gtaW1nIHtcclxuICAgICAgICB3aWR0aDogMTJweDtcclxuICAgICAgICBtYXJnaW4tdG9wOiAtNXB4O1xyXG4gICAgfVxyXG4gICAgLmRyb3BidG5TZWxlY3RlZCB7XHJcbiAgICAgICAgcGFkZGluZzogMTJweDtcclxuICAgICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICB9XHJcbn1cclxuXHJcbi5kcm9wZG93bi1tZW51LnRyYW5zZm9ybS5zaG93IHtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoLTI4cHgsIDQ1cHgsIDBweCkgIWltcG9ydGFudDtcclxufVxyXG5cclxuLnN3aXRjaCB7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICB3aWR0aDogNTZweDtcclxuICAgIGhlaWdodDogMjdweDtcclxuICAgIHRvcDogMHB4O1xyXG4gICAgLyogbWFyZ2luOiAwIDVweDsgKi9cclxuICAgIGZsb2F0OiByaWdodDtcclxuICAgIG1hcmdpbi1yaWdodDogMnJlbTtcclxufVxyXG5cclxuLnN3aXRjaCBpbnB1dCB7XHJcbiAgICBkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG4uc2xpZGVyIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIGJvdHRvbTogMDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC41KTtcclxuICAgIC13ZWJraXQtdHJhbnNpdGlvbjogLjRzO1xyXG4gICAgdHJhbnNpdGlvbjogLjRzO1xyXG59XHJcblxyXG4uc2xpZGVyOmJlZm9yZSB7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBjb250ZW50OiBcIlwiO1xyXG4gICAgaGVpZ2h0OiAyMHB4O1xyXG4gICAgd2lkdGg6IDIwcHg7XHJcbiAgICBsZWZ0OiA3cHg7XHJcbiAgICBib3R0b206IDRweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gICAgLXdlYmtpdC10cmFuc2l0aW9uOiAuNHM7XHJcbiAgICB0cmFuc2l0aW9uOiAuNHM7XHJcbn1cclxuXHJcbmlucHV0OmNoZWNrZWQrLnNsaWRlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDM5Q0NFO1xyXG59XHJcblxyXG5pbnB1dDpmb2N1cysuc2xpZGVyIHtcclxuICAgIGJveC1zaGFkb3c6IDAgMCAxcHggIzIxOTZGMztcclxufVxyXG5cclxuaW5wdXQ6Y2hlY2tlZCsuc2xpZGVyOmJlZm9yZSB7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWCgyNnB4KTtcclxuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMjZweCk7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMjZweCk7XHJcbn1cclxuXHJcblxyXG4vKiBSb3VuZGVkIHNsaWRlcnMgKi9cclxuXHJcbi5zbGlkZXIucm91bmQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzRweDtcclxufVxyXG5cclxuLnNsaWRlci5yb3VuZDpiZWZvcmUge1xyXG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG59XHJcblxyXG4ubmF2LWRpdiB7XHJcbiAgICBiYWNrZ3JvdW5kOiB2YXIoLS1uYXZiYWNrZ3JvdW5kKTtcclxuICAgIGNvbG9yOiB2YXIoLS1vbi1iYWNrZ3JvdW5kKTtcclxuICAgIHBhZGRpbmctdG9wOiAxMHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDVweDtcclxuICAgIGhlaWdodDogNjBweDtcclxuICAgIHBvc2l0aW9uOiBmaXhlZDtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICByaWdodDogMDtcclxuICAgIHotaW5kZXg6IDk5OTk7XHJcbn1cclxuXHJcbi5tb2RhbC5sZWZ0IC5tb2RhbC1kaWFsb2cge1xyXG4gICAgcG9zaXRpb246IGZpeGVkO1xyXG4gICAgcmlnaHQ6IDA7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICB0b3A6IDMuOHJlbTtcclxuICAgIHdpZHRoOiAzMjBweDtcclxuICAgIGhlaWdodDogOTElO1xyXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAlLCAwLCAwKTtcclxuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAlLCAwLCAwKTtcclxuICAgIC1vLXRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMCUsIDAsIDApO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwJSwgMCwgMCk7XHJcbn1cclxuXHJcbi5tb2RhbC5sZWZ0IC5tb2RhbC1jb250ZW50IHtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbn1cclxuXHJcbi5mb250LXN6IHtcclxuICAgIGZvbnQtc2l6ZTogMTlweDtcclxuICAgIGNvbG9yOiB2YXIoLS1vbi1wcmltYXJ5KTtcclxufVxyXG5cclxuLmxhYmxlLWNvbCB7XHJcbiAgICBjb2xvcjogdmFyKC0tb24tcHJpbWFyeSk7XHJcbn1cclxuXHJcbi5tb2RhbC1ib2R5IHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLW5hdmJhY2tncm91bmQpO1xyXG59XHJcblxyXG4uZHJvcGRvd24yIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxuLmRyb3Bkb3duLWNvbnRlbnQge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmMWYxZjE7XHJcbiAgICBtaW4td2lkdGg6IDE2MHB4O1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDhweCAxNnB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgcmlnaHQ6IC0xNTFweDtcclxuICAgIHRvcDogMDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1jb250ZW50IGEge1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgcGFkZGluZzogNXB4IDEwcHg7XHJcbiAgICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxufVxyXG5cclxuLmRyb3Bkb3duLWNvbnRlbnQgYTpob3ZlciB7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkO1xyXG59XHJcblxyXG4uZHJvcGRvd24yOmhvdmVyIC5kcm9wZG93bi1jb250ZW50IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG59XHJcblxyXG4ubW9kYWwtY29udGVudCB7XHJcbiAgICBib3JkZXI6IG5vbmU7XHJcbiAgICBib3JkZXItcmFkaXVzOiB1bnNldDtcclxufVxyXG5cclxuLmZlZWRiYWNrLXRleHQge1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGxldHRlci1zcGFjaW5nOiAwcHg7XHJcbiAgICBjb2xvcjogI0ZGNjYwMDtcclxuICAgIG1hcmdpbi1sZWZ0OiAyMXB4O1xyXG4gICAgbWFyZ2luLXRvcDogMnJlbTtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnRleHRDb2xvciB7XHJcbiAgICBjb2xvcjogdmFyKC0tb24tcHJpbWFyeSk7XHJcbn1cclxuXHJcbi5tb2RhbC1jb250ZW50IHtcclxuICAgIGJhY2tncm91bmQ6IHZhcigtLW5hdmJhY2tncm91bmQpIWltcG9ydGFudDtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbCB7XHJcbiAgICBjb2xvcjogdmFyKC0tb24tcHJpbWFyeSk7XHJcbn1cclxuXHJcbi5tb2RhbC10aXRsZSB7XHJcbiAgICBjb2xvcjogdmFyKC0tb24tcHJpbWFyeSk7XHJcbn1cclxuXHJcbi5wdWJsaXNoLWhlYWQge1xyXG4gICAgaGVpZ2h0OiAzNHB4O1xyXG4gICAgYmFja2dyb3VuZDogI2YxZjFmMTtcclxuICAgIHBhZGRpbmc6IDZweDtcclxuICAgIC8vIGJvcmRlcjogMXB4IHNvbGlkICNjNWM1YzU7XHJcbn1cclxuXHJcbi5kaXYtc3VidGFiIHtcclxuICAgIHBhZGRpbmc6IDIwcHg7XHJcbiAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmRyb3Bkb3duLXN1Ym1lbnV7XHJcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICBtYXJnaW4tbGVmdDogNXB4O1xyXG59XHJcbi5kcm9wZG93bi1zdWJtZW51IGE6OmFmdGVye1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoLTkwZGVnKTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHJpZ2h0OiAzcHg7XHJcbiAgICB0b3A6IDQwJTtcclxufVxyXG4uZHJvcGRvd24tc3VibWVudTpob3ZlciAuZHJvcGRvd24tbWVudSwgLmRyb3Bkb3duLXN1Ym1lbnU6Zm9jdXMgLmRyb3Bkb3duLW1lbnV7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luLXRvcDogLTMwcHg7XHJcbiAgICBsZWZ0OiAxMDAlO1xyXG59XHJcbkBtZWRpYSAobWF4LXdpZHRoOiA5OTJweCkge1xyXG4gICAgLmRyb3Bkb3duLW1lbnV7XHJcbiAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgIH1cclxuICAgIC5kcm9wZG93bi1tZW51IC5kcm9wZG93bi1zdWJtZW51e1xyXG4gICAgICAgIHdpZHRoOiBhdXRvO1xyXG4gICAgfVxyXG59XHJcbi5jb250YWluZXJ7XHJcbiAgICBtYXJnaW4tdG9wOiA3OHB4O1xyXG4gICAgLy8gbWFyZ2luLWxlZnQ6NzZweDtcclxufVxyXG5cclxuXHJcbi50b29sdGlwIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICB9XHJcbiAgXHJcbiAgLnRvb2x0aXAgLnRvb2x0aXAtdGV4dCB7XHJcbiAgICB2aXNpYmlsaXR5OiBoaWRkZW47XHJcbiAgICB3aWR0aDogMjAxcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gICAgY29sb3I6IGJsYWNrO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gICAgcGFkZGluZzogNXB4IDA7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiAxO1xyXG4gICAgdG9wOiAzMXB4O1xyXG4gICAgcmlnaHQ6IC0xMDNweDtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtNTAlKTtcclxuICAgIG9wYWNpdHk6IDA7XHJcbiAgICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuM3M7XHJcbiAgICBib3JkZXI6IDJweCBzb2xpZCB3aGl0ZTtcclxuICB9XHJcbiAgXHJcbiAgLnRvb2x0aXAgLnRvb2x0aXAtdGV4dDo6YWZ0ZXIge1xyXG4gICAgY29udGVudDogJyc7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBib3R0b206IDEwMCU7IC8qIFBvc2l0aW9uIHRoZSBhcnJvdyBhdCB0aGUgYm90dG9tIG9mIHRoZSB0b29sdGlwICovXHJcbiAgICBsZWZ0OiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XHJcbiAgICBib3JkZXItd2lkdGg6IDVweDtcclxuICAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50IHRyYW5zcGFyZW50IHdoaXRlIHRyYW5zcGFyZW50OyAvKiBBcnJvdyBjb2xvciAqL1xyXG4gIH1cclxuICBcclxuICAudG9vbHRpcDpob3ZlciAudG9vbHRpcC10ZXh0IHtcclxuICAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbiAgICBvcGFjaXR5OiAxO1xyXG4gIH1cclxuXHJcbiAgLmxvYWRlci1iYWNrZ3JvdW5kIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogMDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICB6LWluZGV4OiAxMDAwO1xyXG4gICAgLy8gYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xyXG4gIH1cclxuXHJcbiAgLmxvYWRlckRpdiB7XHJcbiAgICBwb3NpdGlvbjogZml4ZWQ7XHJcbiAgICB0b3A6IDYwJTtcclxuICAgIGxlZnQ6IDU1JTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gICAgZm9udC1zaXplOiA2MHB4O1xyXG4gIH0iXX0= */"];
      /***/
    },

    /***/
    "PGEX":
    /*!************************************!*\
      !*** ./src/app/ascii.validator.ts ***!
      \************************************/

    /*! exports provided: asciiValidator */

    /***/
    function PGEX(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "asciiValidator", function () {
        return asciiValidator;
      });

      function asciiValidator() {
        return function (control) {
          if (!control.value) {
            return null;
          }

          var nonAsciiRegex = /[^\x00-\x7F]/;
          var forbidden = nonAsciiRegex.test(control.value);
          return forbidden ? {
            'nonAscii': {
              value: control.value
            }
          } : null;
        };
      }
      /***/

    },

    /***/
    "RnhZ":
    /*!**************************************************!*\
      !*** ./node_modules/moment/locale sync ^\.\/.*$ ***!
      \**************************************************/

    /*! no static exports found */

    /***/
    function RnhZ(module, exports, __webpack_require__) {
      var map = {
        "./af": "K/tc",
        "./af.js": "K/tc",
        "./ar": "jnO4",
        "./ar-dz": "o1bE",
        "./ar-dz.js": "o1bE",
        "./ar-kw": "Qj4J",
        "./ar-kw.js": "Qj4J",
        "./ar-ly": "HP3h",
        "./ar-ly.js": "HP3h",
        "./ar-ma": "CoRJ",
        "./ar-ma.js": "CoRJ",
        "./ar-ps": "TJgH",
        "./ar-ps.js": "TJgH",
        "./ar-sa": "gjCT",
        "./ar-sa.js": "gjCT",
        "./ar-tn": "bYM6",
        "./ar-tn.js": "bYM6",
        "./ar.js": "jnO4",
        "./az": "SFxW",
        "./az.js": "SFxW",
        "./be": "H8ED",
        "./be.js": "H8ED",
        "./bg": "hKrs",
        "./bg.js": "hKrs",
        "./bm": "p/rL",
        "./bm.js": "p/rL",
        "./bn": "kEOa",
        "./bn-bd": "loYQ",
        "./bn-bd.js": "loYQ",
        "./bn.js": "kEOa",
        "./bo": "0mo+",
        "./bo.js": "0mo+",
        "./br": "aIdf",
        "./br.js": "aIdf",
        "./bs": "JVSJ",
        "./bs.js": "JVSJ",
        "./ca": "1xZ4",
        "./ca.js": "1xZ4",
        "./cs": "PA2r",
        "./cs.js": "PA2r",
        "./cv": "A+xa",
        "./cv.js": "A+xa",
        "./cy": "l5ep",
        "./cy.js": "l5ep",
        "./da": "DxQv",
        "./da.js": "DxQv",
        "./de": "tGlX",
        "./de-at": "s+uk",
        "./de-at.js": "s+uk",
        "./de-ch": "u3GI",
        "./de-ch.js": "u3GI",
        "./de.js": "tGlX",
        "./dv": "WYrj",
        "./dv.js": "WYrj",
        "./el": "jUeY",
        "./el.js": "jUeY",
        "./en-au": "Dmvi",
        "./en-au.js": "Dmvi",
        "./en-ca": "OIYi",
        "./en-ca.js": "OIYi",
        "./en-gb": "Oaa7",
        "./en-gb.js": "Oaa7",
        "./en-ie": "4dOw",
        "./en-ie.js": "4dOw",
        "./en-il": "czMo",
        "./en-il.js": "czMo",
        "./en-in": "7C5Q",
        "./en-in.js": "7C5Q",
        "./en-nz": "b1Dy",
        "./en-nz.js": "b1Dy",
        "./en-sg": "t+mt",
        "./en-sg.js": "t+mt",
        "./eo": "Zduo",
        "./eo.js": "Zduo",
        "./es": "iYuL",
        "./es-do": "CjzT",
        "./es-do.js": "CjzT",
        "./es-mx": "tbfe",
        "./es-mx.js": "tbfe",
        "./es-us": "Vclq",
        "./es-us.js": "Vclq",
        "./es.js": "iYuL",
        "./et": "7BjC",
        "./et.js": "7BjC",
        "./eu": "D/JM",
        "./eu.js": "D/JM",
        "./fa": "jfSC",
        "./fa.js": "jfSC",
        "./fi": "gekB",
        "./fi.js": "gekB",
        "./fil": "1ppg",
        "./fil.js": "1ppg",
        "./fo": "ByF4",
        "./fo.js": "ByF4",
        "./fr": "nyYc",
        "./fr-ca": "2fjn",
        "./fr-ca.js": "2fjn",
        "./fr-ch": "Dkky",
        "./fr-ch.js": "Dkky",
        "./fr.js": "nyYc",
        "./fy": "cRix",
        "./fy.js": "cRix",
        "./ga": "USCx",
        "./ga.js": "USCx",
        "./gd": "9rRi",
        "./gd.js": "9rRi",
        "./gl": "iEDd",
        "./gl.js": "iEDd",
        "./gom-deva": "qvJo",
        "./gom-deva.js": "qvJo",
        "./gom-latn": "DKr+",
        "./gom-latn.js": "DKr+",
        "./gu": "4MV3",
        "./gu.js": "4MV3",
        "./he": "x6pH",
        "./he.js": "x6pH",
        "./hi": "3E1r",
        "./hi.js": "3E1r",
        "./hr": "S6ln",
        "./hr.js": "S6ln",
        "./hu": "WxRl",
        "./hu.js": "WxRl",
        "./hy-am": "1rYy",
        "./hy-am.js": "1rYy",
        "./id": "UDhR",
        "./id.js": "UDhR",
        "./is": "BVg3",
        "./is.js": "BVg3",
        "./it": "bpih",
        "./it-ch": "bxKX",
        "./it-ch.js": "bxKX",
        "./it.js": "bpih",
        "./ja": "B55N",
        "./ja.js": "B55N",
        "./jv": "tUCv",
        "./jv.js": "tUCv",
        "./ka": "IBtZ",
        "./ka.js": "IBtZ",
        "./kk": "bXm7",
        "./kk.js": "bXm7",
        "./km": "6B0Y",
        "./km.js": "6B0Y",
        "./kn": "PpIw",
        "./kn.js": "PpIw",
        "./ko": "Ivi+",
        "./ko.js": "Ivi+",
        "./ku": "JCF/",
        "./ku-kmr": "dVgr",
        "./ku-kmr.js": "dVgr",
        "./ku.js": "JCF/",
        "./ky": "lgnt",
        "./ky.js": "lgnt",
        "./lb": "RAwQ",
        "./lb.js": "RAwQ",
        "./lo": "sp3z",
        "./lo.js": "sp3z",
        "./lt": "JvlW",
        "./lt.js": "JvlW",
        "./lv": "uXwI",
        "./lv.js": "uXwI",
        "./me": "KTz0",
        "./me.js": "KTz0",
        "./mi": "aIsn",
        "./mi.js": "aIsn",
        "./mk": "aQkU",
        "./mk.js": "aQkU",
        "./ml": "AvvY",
        "./ml.js": "AvvY",
        "./mn": "lYtQ",
        "./mn.js": "lYtQ",
        "./mr": "Ob0Z",
        "./mr.js": "Ob0Z",
        "./ms": "6+QB",
        "./ms-my": "ZAMP",
        "./ms-my.js": "ZAMP",
        "./ms.js": "6+QB",
        "./mt": "G0Uy",
        "./mt.js": "G0Uy",
        "./my": "honF",
        "./my.js": "honF",
        "./nb": "bOMt",
        "./nb.js": "bOMt",
        "./ne": "OjkT",
        "./ne.js": "OjkT",
        "./nl": "+s0g",
        "./nl-be": "2ykv",
        "./nl-be.js": "2ykv",
        "./nl.js": "+s0g",
        "./nn": "uEye",
        "./nn.js": "uEye",
        "./oc-lnc": "Fnuy",
        "./oc-lnc.js": "Fnuy",
        "./pa-in": "8/+R",
        "./pa-in.js": "8/+R",
        "./pl": "jVdC",
        "./pl.js": "jVdC",
        "./pt": "8mBD",
        "./pt-br": "0tRk",
        "./pt-br.js": "0tRk",
        "./pt.js": "8mBD",
        "./ro": "lyxo",
        "./ro.js": "lyxo",
        "./ru": "lXzo",
        "./ru.js": "lXzo",
        "./sd": "Z4QM",
        "./sd.js": "Z4QM",
        "./se": "//9w",
        "./se.js": "//9w",
        "./si": "7aV9",
        "./si.js": "7aV9",
        "./sk": "e+ae",
        "./sk.js": "e+ae",
        "./sl": "gVVK",
        "./sl.js": "gVVK",
        "./sq": "yPMs",
        "./sq.js": "yPMs",
        "./sr": "zx6S",
        "./sr-cyrl": "E+lV",
        "./sr-cyrl.js": "E+lV",
        "./sr.js": "zx6S",
        "./ss": "Ur1D",
        "./ss.js": "Ur1D",
        "./sv": "X709",
        "./sv.js": "X709",
        "./sw": "dNwA",
        "./sw.js": "dNwA",
        "./ta": "PeUW",
        "./ta.js": "PeUW",
        "./te": "XLvN",
        "./te.js": "XLvN",
        "./tet": "V2x9",
        "./tet.js": "V2x9",
        "./tg": "Oxv6",
        "./tg.js": "Oxv6",
        "./th": "EOgW",
        "./th.js": "EOgW",
        "./tk": "Wv91",
        "./tk.js": "Wv91",
        "./tl-ph": "Dzi0",
        "./tl-ph.js": "Dzi0",
        "./tlh": "z3Vd",
        "./tlh.js": "z3Vd",
        "./tr": "DoHr",
        "./tr.js": "DoHr",
        "./tzl": "z1FC",
        "./tzl.js": "z1FC",
        "./tzm": "wQk9",
        "./tzm-latn": "tT3J",
        "./tzm-latn.js": "tT3J",
        "./tzm.js": "wQk9",
        "./ug-cn": "YRex",
        "./ug-cn.js": "YRex",
        "./uk": "raLr",
        "./uk.js": "raLr",
        "./ur": "UpQW",
        "./ur.js": "UpQW",
        "./uz": "Loxo",
        "./uz-latn": "AQ68",
        "./uz-latn.js": "AQ68",
        "./uz.js": "Loxo",
        "./vi": "KSF8",
        "./vi.js": "KSF8",
        "./x-pseudo": "/X5v",
        "./x-pseudo.js": "/X5v",
        "./yo": "fzPg",
        "./yo.js": "fzPg",
        "./zh-cn": "XDpg",
        "./zh-cn.js": "XDpg",
        "./zh-hk": "SatO",
        "./zh-hk.js": "SatO",
        "./zh-mo": "OmwH",
        "./zh-mo.js": "OmwH",
        "./zh-tw": "kOpN",
        "./zh-tw.js": "kOpN"
      };

      function webpackContext(req) {
        var id = webpackContextResolve(req);
        return __webpack_require__(id);
      }

      function webpackContextResolve(req) {
        if (!__webpack_require__.o(map, req)) {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        }

        return map[req];
      }

      webpackContext.keys = function webpackContextKeys() {
        return Object.keys(map);
      };

      webpackContext.resolve = webpackContextResolve;
      module.exports = webpackContext;
      webpackContext.id = "RnhZ";
      /***/
    },

    /***/
    "SDTg":
    /*!********************************************************!*\
      !*** ./src/app/job-mobility/job-mobility.component.ts ***!
      \********************************************************/

    /*! exports provided: JobMobilityComponent */

    /***/
    function SDTg(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JobMobilityComponent", function () {
        return JobMobilityComponent;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! sweetalert2 */
      "PSD3");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_2__);
      /* harmony import */


      var _ascii_validator__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../ascii.validator */
      "PGEX");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! moment */
      "wd/R");
      /* harmony import */


      var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! rxjs */
      "qCKp");

      var JobMobilityComponent = /*#__PURE__*/function () {
        function JobMobilityComponent(fb, jumpService, cdRef) {
          _classCallCheck(this, JobMobilityComponent);

          var _a;

          this.fb = fb;
          this.jumpService = jumpService;
          this.cdRef = cdRef;
          this.tabChangeSubject = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
          this.searchTerm = '';
          this.dropdownVisible = false;
          this.searchOptions = [{
            label: 'TR #',
            value: 'trid'
          }, {
            label: 'Position',
            value: 'position'
          }, {
            label: 'Skill',
            value: 'skill'
          }, {
            label: 'Grade',
            value: 'grade'
          }];
          this.selectedOption = this.searchOptions[0];
          this.filteredItems = [];
          this.pageSize = 10;
          this.visibleItems = [];
          this.pages = [];
          this.currentApplicationsPage = 1;
          this.itemsPerApplyPage = 5;
          this.currentPage = 1;
          this.itemsPerPage = 10;
          this.selectedCategory = 'all';
          this.isEditForm = false;
          this.skills = ['JavaScript', 'Python', 'SQL', 'Java', 'C#'];
          this.statusList = [{
            "tr_status_id": 0,
            "tr_status_name": "All"
          }, {
            "tr_status_id": 1,
            "tr_status_name": "Open"
          }, {
            "tr_status_id": 10,
            "tr_status_name": "In Process"
          }, {
            "tr_status_id": 20,
            "tr_status_name": "Hold"
          }, {
            "tr_status_id": 30,
            "tr_status_name": "Closed"
          }];
          this.trStatusList = [{
            "tr_status_id": 1,
            "tr_status_name": "Open"
          }, {
            "tr_status_id": 10,
            "tr_status_name": "In Process"
          }, {
            "tr_status_id": 20,
            "tr_status_name": "Hold"
          }, {
            "tr_status_id": 30,
            "tr_status_name": "Closed"
          }];
          this.fileName = "";
          this.selectedStatus = (_a = this.statusList[0]) === null || _a === void 0 ? void 0 : _a.tr_status_id;
          this.roles = ['Developer', 'Tester', 'Manager'];
          this.myApplicationsTable = [];
          this.tabs = [];
          this.detailTabs = [{
            label: "Details",
            value: "0"
          }, {
            label: "Notes",
            value: "1"
          }, {
            label: "History",
            value: "2"
          }];
          this.isShowTable = true;
          this.isOpenRolesHidden = true;
          this.filteredData = [];
          this.isMyApplicationsHidden = true;
          this.isProfileOpen = false;
          this.userDetails = {};
          this.selectApplynow = false;
          this.applyButton = true;
          this.showApplyDetails = false;
          this.viewDashboardDetails = 0;
          this.isApplied = false;
          this.candidates = [];
          this.expandedDashboardRow = null;
          this.expandedApplicationsRow = null;
          this.expandedRow = null;
          this.jumpEmail = 'jump@trianz.com';
          this.showProfileInfo = false;
          this.getMyProfile();
        }

        _createClass(JobMobilityComponent, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _a;

            this.loading = true;
            this.frmEditProfile = this.fb.group({
              fname: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              // lname: new FormControl(),
              email: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              phoneNumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              location: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              primaryskill: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              secondaryskill: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              experience: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              trianzExperience: new _angular_forms__WEBPACK_IMPORTED_MODULE_1__["FormControl"](),
              fileName: [(_a = this.file) === null || _a === void 0 ? void 0 : _a.name]
            });
            this.getTabs();
            this.createForm();
            this.selectTabs();
            this.getMyApplicationsData(); // this.getDemo()
          } // tr creation
          // createForm() {
          //   this.applicationForm = this.fb.group({
          //     position: ['', [Validators.required, asciiValidator(), Validators.maxLength(99)]],
          //     organization: ["", Validators.required],
          //     code: ["", Validators.required],
          //     practice: ['', Validators.required],
          //     accountName: [''],
          //     projectName: [''],
          //     skill: ['', [Validators.required, Validators.maxLength(255)]],
          //     mandatorySkill: ['', [Validators.required, Validators.maxLength(255)]],
          //     desirableSkills: [''],
          //     experience: [{ value: '', disabled: true }, Validators.required],
          //     recruiterName: ['', Validators.required],
          //     grade: ['', Validators.required],
          //     location: ['', Validators.required],
          //     status: ['', Validators.required],
          //     lastDateForSubmission: ['', Validators.required],
          //     jobDesc: ['', [Validators.required, Validators.maxLength(4000)]],
          //     firstLevelTech: ["", Validators.required],
          //     secondLevelTech: [""]
          //   });
          //   this.minDate = new Date().toISOString().split('T')[0]
          // }

        }, {
          key: "applyNow",
          value: function applyNow(link, category) {
            localStorage.setItem('category', category);

            if (category == "dashboard") {
              this.isShowTable = false;
            } else if (category == "open-roles") {
              this.isOpenRolesHidden = false;
            } else {
              this.isMyApplicationsHidden = false;
            }

            this.selectedJob = {
              'link': link,
              'category': category
            };
          }
        }, {
          key: "onClose",
          value: function onClose() {
            this.isEditForm = false;
            this.applicationForm.reset();
            $("#applicationTR").modal("hide");
          }
        }, {
          key: "onReset",
          value: function onReset() {
            this.applicationForm.reset();
            this.createForm();
          }
        }, {
          key: "categoryTabClick",
          value: function categoryTabClick(index) {
            var _a;

            this.expandedRow = null;
            this.expandedDashboardRow = null;
            this.expandedApplicationsRow = null;
            this.isShowTable = true;
            this.isOpenRolesHidden = true;
            this.isMyApplicationsHidden = true; // const selected = this.tabs.filter(
            //   ((item: any) => item?.label === event?.tab?.textLabel)
            // )

            var selectedLabel = (_a = this.tabs[index]) === null || _a === void 0 ? void 0 : _a.label;
            this.searchTerm = "", this.currentPage = 1;

            if (selectedLabel == "Open Roles") {
              this.selectedOption = this.searchOptions[2];
              this.getOpenRoles(this.currentPage);
            } else if (selectedLabel == "Dashboard") {
              this.selectedOption = this.searchOptions[0];
              this.getActiveTrData(this.currentPage); // setTimeout(() => this.getApplicationsList(this.jobsList[0]?.trId),1500)
              // this.showApplications()
            } else {
              this.getMyApplicationsData();
            }
          }
        }, {
          key: "changeTabClick",
          value: function changeTabClick(index) {
            var _a;

            this.expandedRow = null;
            this.expandedDashboardRow = null;
            this.expandedApplicationsRow = null;

            if (this.selectedIndex == index) {
              this.isShowTable = true;
              this.isOpenRolesHidden = true;
              this.isMyApplicationsHidden = true;
              var selectedLabel = (_a = this.tabs[index]) === null || _a === void 0 ? void 0 : _a.label;
              this.searchTerm = "", this.currentPage = 1;

              if (selectedLabel == "Open Roles") {
                this.selectedOption = this.searchOptions[2];
                this.getOpenRoles(this.currentPage);
              } else if (selectedLabel == "Dashboard") {
                this.selectedOption = this.searchOptions[0];
                this.getActiveTrData(this.currentPage); // setTimeout(() => this.getApplicationsList(this.jobsList[0]?.trId),1500)
                // this.showApplications()
              } else {
                this.getMyApplicationsData();
              }
            }
          }
        }, {
          key: "selectTabs",
          value: function selectTabs() {
            if (localStorage.getItem('category')) {
              this.selectedIndex = this.tabs.findIndex(function (list) {
                return list.value.toLowerCase() === localStorage.getItem('category').toLowerCase();
              });
              localStorage.removeItem('category');
            }
          }
        }, {
          key: "clickDashboardTable",
          value: function clickDashboardTable() {
            this.isShowTable = true;

            if (this.searchTerm) {
              this.getSearchDashboardData(this.currentPage);
            } else {
              this.getActiveTrData(this.currentPage);
            }
          }
        }, {
          key: "clickOpenrolesData",
          value: function clickOpenrolesData() {
            this.isOpenRolesHidden = true;

            if (this.searchTerm) {
              this.getSearchOpenRolesData(this.currentPage);
            } else {
              this.getOpenRoles(this.currentPage);
            }
          }
        }, {
          key: "clickMyApplicationsData",
          value: function clickMyApplicationsData() {
            this.isMyApplicationsHidden = true;
          }
        }, {
          key: "openEditForm",
          value: function openEditForm() {
            this.isEditForm = true;
            this.applicationForm.reset();
            this.getUpdatedTrDetails();
            $("#applicationTR").modal("show");
          }
        }, {
          key: "updateVisibleItems",
          value: function updateVisibleItems(page) {
            if (this.searchTerm) {
              this.getSearchOpenRolesData(this.currentPage);
            } else {
              this.getOpenRoles(this.currentPage);
            }
          } // import tr

        }, {
          key: "importTr",
          value: function importTr() {
            this.getTrDetails();
          }
        }, {
          key: "getTrDetails",
          value: function getTrDetails() {
            var _this12 = this;

            var _a;

            this.createTrLoading = true;
            this.jumpService.getImportTrDetails((_a = this.applicationForm.get('code')) === null || _a === void 0 ? void 0 : _a.value).subscribe(function (data) {
              var trsArray = data.data;

              _this12.getTrData(trsArray);
            }, function (error) {
              _this12.createTrLoading = false;
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'error',
                title: error === null || error === void 0 ? void 0 : error.error.message
              });
              console.error('Error fetching data', error);
            });
          }
        }, {
          key: "applynowbtnClick",
          value: function applynowbtnClick() {
            this.selectApplynow = true;
          }
        }, {
          key: "closeModel",
          value: function closeModel(event) {
            this.selectApplynow = event;
          }
        }, {
          key: "closeApply",
          value: function closeApply(event) {
            this.applyButton = event;
          }
        }, {
          key: "getUpdatedTrDetails",
          value: function getUpdatedTrDetails() {
            var _this13 = this;

            var _a;

            this.createTrLoading = true;
            this.jumpService.getTrDataById((_a = this.selectedJob) === null || _a === void 0 ? void 0 : _a.link).subscribe(function (data) {
              var trsArray = data.data;

              _this13.getTrData(trsArray);
            }, function (error) {
              _this13.createTrLoading = false;
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'error',
                title: error === null || error === void 0 ? void 0 : error.error.message
              });
              console.error('Error fetching data', error);
            });
          }
        }, {
          key: "getTrData",
          value: function getTrData(trsArray) {
            var _a, _b, _c, _d, _e;

            this.createTrLoading = false;
            this.importTrData = {
              "position": trsArray === null || trsArray === void 0 ? void 0 : trsArray.jobTitle,
              "organization": trsArray === null || trsArray === void 0 ? void 0 : trsArray.organizationGroup,
              "practice": trsArray === null || trsArray === void 0 ? void 0 : trsArray.practice,
              "accountName": trsArray === null || trsArray === void 0 ? void 0 : trsArray.accountName,
              "projectName": trsArray === null || trsArray === void 0 ? void 0 : trsArray.projectName,
              "skill": trsArray === null || trsArray === void 0 ? void 0 : trsArray.primarySkills,
              "mandatorySkill": trsArray === null || trsArray === void 0 ? void 0 : trsArray.mandatorySkills,
              "desirableSkills": trsArray === null || trsArray === void 0 ? void 0 : trsArray.gthSkills,
              "experience": trsArray === null || trsArray === void 0 ? void 0 : trsArray.experience,
              "grade": trsArray === null || trsArray === void 0 ? void 0 : trsArray.grade,
              "location": trsArray === null || trsArray === void 0 ? void 0 : trsArray.location,
              "status": (_a = trsArray === null || trsArray === void 0 ? void 0 : trsArray.trStatusId) !== null && _a !== void 0 ? _a : (_b = this.trStatusList[0]) === null || _b === void 0 ? void 0 : _b.tr_status_id,
              "jobDesc": trsArray === null || trsArray === void 0 ? void 0 : trsArray.jobDescription,
              "lastDateForSubmission": trsArray === null || trsArray === void 0 ? void 0 : trsArray.deadline,
              "firstLevelTech": trsArray === null || trsArray === void 0 ? void 0 : trsArray.firstLevelTechPanel,
              "secondLevelTech": trsArray === null || trsArray === void 0 ? void 0 : trsArray.secondLevelTechPanel,
              "recruiterName": trsArray === null || trsArray === void 0 ? void 0 : trsArray.recruiterId,
              "code": (_d = (_c = this.applicationForm.get('code')) === null || _c === void 0 ? void 0 : _c.value) !== null && _d !== void 0 ? _d : (_e = this.selectedJob) === null || _e === void 0 ? void 0 : _e.link,
              "recruitersList": trsArray === null || trsArray === void 0 ? void 0 : trsArray.recruitersList
            };
            this.applicationForm.patchValue(this.importTrData);
          }
        }, {
          key: "createTR",
          value: function createTR() {
            var _this14 = this;

            var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;

            this.createTrLoading = true;
            var trData = {
              "trId": (_a = this.applicationForm.get('code')) === null || _a === void 0 ? void 0 : _a.value,
              "jobTitle": (_b = this.applicationForm.get('position')) === null || _b === void 0 ? void 0 : _b.value,
              "organizationGroup": (_c = this.applicationForm.get('organization')) === null || _c === void 0 ? void 0 : _c.value,
              "jobDescription": (_d = this.applicationForm.get('jobDesc')) === null || _d === void 0 ? void 0 : _d.value,
              "primarySkills": (_e = this.applicationForm.get('skill')) === null || _e === void 0 ? void 0 : _e.value,
              "mandatorySkills": (_f = this.applicationForm.get('mandatorySkill')) === null || _f === void 0 ? void 0 : _f.value,
              "gthSkills": (_g = this.applicationForm.get('desirableSkills')) === null || _g === void 0 ? void 0 : _g.value,
              "experience": (_h = this.applicationForm.get('experience')) === null || _h === void 0 ? void 0 : _h.value,
              "recruiterId": (_j = this.applicationForm.get('recruiterName')) === null || _j === void 0 ? void 0 : _j.value,
              "grade": (_k = this.applicationForm.get('grade')) === null || _k === void 0 ? void 0 : _k.value,
              "location": (_l = this.applicationForm.get('location')) === null || _l === void 0 ? void 0 : _l.value,
              "trStatusId": (_m = this.applicationForm.get('status')) === null || _m === void 0 ? void 0 : _m.value,
              "deadline": (_o = this.applicationForm.get('lastDateForSubmission')) === null || _o === void 0 ? void 0 : _o.value,
              "practice": (_p = this.applicationForm.get('practice')) === null || _p === void 0 ? void 0 : _p.value,
              "accountName": (_q = this.applicationForm.get('accountName')) === null || _q === void 0 ? void 0 : _q.value,
              "projectName": (_r = this.applicationForm.get('projectName')) === null || _r === void 0 ? void 0 : _r.value,
              "firstLevelTechPanel": (_s = this.applicationForm.get('firstLevelTech')) === null || _s === void 0 ? void 0 : _s.value,
              "secondLevelTechPanel": (_t = this.applicationForm.get('secondLevelTech')) === null || _t === void 0 ? void 0 : _t.value
            };

            if (!this.isEditForm) {
              this.jumpService.createTR(trData).subscribe(function (response) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'success',
                  title: 'TR created successfully!'
                }).then(function (result) {
                  if (result.isConfirmed) {
                    window.location.reload();
                  }
                });
                _this14.createTrLoading = false;

                _this14.applicationForm.reset();

                $("#applicationTR").modal("hide");
              }, function (error) {
                var _a;

                console.error('Error creating TR', error);
                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'error',
                  title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
                });
                _this14.createTrLoading = false;
              });
            } else {
              this.jumpService.updateTR(trData).subscribe(function (response) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'success',
                  title: response === null || response === void 0 ? void 0 : response.message
                }).then(function (result) {
                  var _a;

                  if (result.isConfirmed) {
                    _this14.jumpService.setJobDetails((_a = _this14.applicationForm.get('code')) === null || _a === void 0 ? void 0 : _a.value);

                    _this14.applicationForm.reset();
                  }
                });
                _this14.createTrLoading = false;
                _this14.isEditForm = false;
                $("#applicationTR").modal("hide");
              }, function (error) {
                var _a;

                console.error('Error creating TR', error);
                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'error',
                  title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
                });
                _this14.createTrLoading = false;
              });
            }
          }
        }, {
          key: "getMyApplicationsData",
          value: function getMyApplicationsData() {
            var _this15 = this;

            this.jumpService.getEmployeeData().subscribe(function (data) {
              var colorArr = ['#fce5cd', '#d9ead3', '#c9daf8', '#f4cccc', '#e6e6e6', '#fff2cc', '#d9d2e9', '#DFF0D8'];
              var textColors = ['#e69138', '#6aa84f', '#3c78d8', '#cc0000', '#999999', '#e69138', '#6a329f', '#3C763D'];
              var statusColorMap = {
                1: colorArr[0],
                10: colorArr[1],
                20: colorArr[2],
                30: colorArr[3],
                40: colorArr[4],
                50: colorArr[5],
                60: colorArr[6],
                70: colorArr[7]
              };
              var statusTextColorMap = {
                1: textColors[0],
                10: textColors[1],
                20: textColors[2],
                30: textColors[3],
                40: textColors[4],
                50: textColors[5],
                60: textColors[6],
                70: textColors[7]
              };
              data.data.forEach(function (application) {
                application.color = statusColorMap[application.statusId];
                application.textColor = statusTextColorMap[application.statusId];
              });
              _this15.myApplicationsTable = data.data;
            }, function (error) {
              console.error('Error fetching data', error);
            });
          }
        }, {
          key: "closeDropdown",
          value: function closeDropdown() {
            this.dropdownVisible = false;
          }
        }, {
          key: "toggleDropdown",
          value: function toggleDropdown() {
            this.dropdownVisible = !this.dropdownVisible;
            this.cdRef.detectChanges();
          }
        }, {
          key: "profileDropdown",
          value: function profileDropdown() {
            this.isProfileOpen = !this.isProfileOpen;
          }
        }, {
          key: "selectOption",
          value: function selectOption(option, item) {
            this.selectedOption = option;
            this.dropdownVisible = false;
            this.searchTerm = "";
            this.currentPage = 1;

            if (item == 'dashboard') {
              this.getActiveTrData(this.currentPage);
            } else {
              this.searchOpenRoleItem();
            }
          }
        }, {
          key: "onDocumentClick",
          value: function onDocumentClick(event) {
            var clickedInsideStatusDialog = event.target.closest('.status-dialog');

            if (!clickedInsideStatusDialog) {
              this.currentItem = "";
            }

            if (!this.dropdownVisible) return;
            var clickedInside = event.target.closest('.input-group');

            if (!clickedInside) {
              this.dropdownVisible = false;
              this.cdRef.detectChanges();
            }
          }
        }, {
          key: "getTabs",
          value: function getTabs() {
            var _this16 = this;

            {
              this.loading = true;
              this.jumpService.getDashboardData().subscribe(function (data) {
                var _a, _b;

                if ((_a = data.roles) === null || _a === void 0 ? void 0 : _a.length) {
                  _this16.tabs = [{
                    label: "Dashboard",
                    value: "dashboard"
                  }, {
                    label: "Open Roles",
                    value: "open-roles"
                  }, {
                    label: "MyApplications",
                    value: "my-applications"
                  }]; // this.categoryTabClick(0)
                } else {
                  _this16.tabs = [{
                    label: "Open Roles",
                    value: "open-roles"
                  }, {
                    label: "MyApplications",
                    value: "my-applications"
                  }];

                  _this16.categoryTabClick(0);
                }

                _this16.userName = (_b = data.userDetails) === null || _b === void 0 ? void 0 : _b.name;
                localStorage.setItem('userDetails', JSON.stringify(data.userDetails));
                _this16.loading = false;
              }, function (error) {
                console.error('Error fetching data', error);
                _this16.loading = false;
              });
            }
          } // Dashboard related

        }, {
          key: "getActiveTrData",
          value: function getActiveTrData(page) {
            var _this17 = this;

            this.currentPage = page;
            this.loading = true;
            this.jumpService.getTrFilteredData(page, this.selectedCategory, this.selectedStatus).subscribe(function (data) {
              var trsArray = data.data;
              _this17.totalPages = Math.ceil((data === null || data === void 0 ? void 0 : data.dataCount) / _this17.itemsPerPage);
              _this17.totalPagesperGrid = Math.ceil((data === null || data === void 0 ? void 0 : data.dataCount) / _this17.itemsPerPage);
              _this17.pages = Array.from({
                length: _this17.totalPages
              }, function (_, i) {
                return i + 1;
              });
              _this17.dashboardTotalJobs = data === null || data === void 0 ? void 0 : data.dataCount;
              _this17.jobsList = trsArray;
              _this17.loading = false;
            }, function (error) {
              console.error('Error fetching data', error);
              _this17.loading = false;
            });
          }
        }, {
          key: "searchItem",
          value: function searchItem(item) {
            if (this.searchTerm) {
              this.getSearchDashboardData(1);
            } else {
              this.getActiveTrData(1);
            }
          }
        }, {
          key: "refreshData",
          value: function refreshData(event, item) {
            var inputElement = event.target;

            if (inputElement.value === '' && item == 'dashboard') {
              this.getActiveTrData(1);
            } else if (inputElement.value === '' && item == 'open-roles') {
              this.getOpenRoles(1);
            }
          }
        }, {
          key: "getSearchDashboardData",
          value: function getSearchDashboardData(currentPage) {
            var _this18 = this;

            var _a;

            this.currentPage = currentPage;
            this.loading = true;
            this.jumpService.getTrSearchData(currentPage, (_a = this.selectedOption) === null || _a === void 0 ? void 0 : _a.value, this.searchTerm).subscribe(function (data) {
              var trsArray = data.data;
              _this18.jobsList = trsArray;
              _this18.dashboardTotalJobs = data === null || data === void 0 ? void 0 : data.dataCount;
              _this18.totalPages = Math.ceil(data.dataCount / _this18.itemsPerPage);
              _this18.totalPagesperGrid = Math.ceil(data.dataCount / _this18.itemsPerPage);
              _this18.pages = Array.from({
                length: _this18.totalPages
              }, function (_, i) {
                return i + 1;
              });
              _this18.loading = false;
            }, function (error) {
              console.error('Error fetching data', error);
              _this18.loading = false;
            });
          }
        }, {
          key: "setPage",
          value: function setPage(page) {
            this.currentPage = page;

            if (this.searchTerm) {
              this.getSearchDashboardData(this.currentPage);
            } else {
              this.getActiveTrData(this.currentPage);
            }
          }
        }, {
          key: "nextPage",
          value: function nextPage() {
            if (this.currentPage < this.totalPages) {
              this.currentPage = this.currentPage++;

              if (this.searchTerm) {
                this.getSearchDashboardData(this.currentPage++);
              } else {
                this.getActiveTrData(this.currentPage++);
              }
            }
          }
        }, {
          key: "prevPage",
          value: function prevPage() {
            if (this.currentPage > 1) {
              this.currentPage--;

              if (this.searchTerm) {
                this.getSearchDashboardData(this.currentPage--);
              } else {
                this.getActiveTrData(this.currentPage--);
              }
            }
          } // open-roles

        }, {
          key: "getOpenRoles",
          value: function getOpenRoles(page) {
            var _this19 = this;

            this.currentPage = page;
            this.loading = true;
            this.jumpService.getActiveRolesData(this.currentPage).subscribe(function (data) {
              var trsArray = data.data;

              _this19.updatePagination(data === null || data === void 0 ? void 0 : data.dataCount);

              _this19.applicationsCount = data === null || data === void 0 ? void 0 : data.applicationsCount;
              _this19.visibleItems = trsArray;
              _this19.openrolesTotalJobs = data === null || data === void 0 ? void 0 : data.dataCount;
              _this19.isApplyValid = data.canApply;
              _this19.loading = false;
            }, function (error) {
              console.error('Error fetching data', error);
              _this19.loading = false;
            });
          }
        }, {
          key: "searchOpenRoleItem",
          value: function searchOpenRoleItem() {
            if (this.searchTerm) {
              this.getSearchOpenRolesData(1);
            } else {
              this.getOpenRoles(1);
            }
          }
        }, {
          key: "getSearchOpenRolesData",
          value: function getSearchOpenRolesData(currentPage) {
            var _this20 = this;

            var _a;

            this.currentPage = currentPage;
            this.loading = true;
            this.jumpService.getRolesSearchData(currentPage, (_a = this.selectedOption) === null || _a === void 0 ? void 0 : _a.value, this.searchTerm).subscribe(function (data) {
              var trsArray = data.data;
              _this20.visibleItems = trsArray;
              _this20.openrolesTotalJobs = data === null || data === void 0 ? void 0 : data.dataCount;

              _this20.updatePagination(data === null || data === void 0 ? void 0 : data.dataCount);

              _this20.loading = false;
            }, function (error) {
              console.error('Error fetching data', error);
              _this20.loading = false;
            }); // }
          }
        }, {
          key: "updatePagination",
          value: function updatePagination(dataCount) {
            this.totalPages = Math.ceil(dataCount / this.itemsPerPage);
            this.pages = Array.from({
              length: this.totalPages
            }, function (_, i) {
              return i + 1;
            });
          }
        }, {
          key: "setRolesPage",
          value: function setRolesPage(page) {
            this.currentPage = page;
            this.updateVisibleItems(page);
          }
        }, {
          key: "nextRolesPage",
          value: function nextRolesPage() {
            if (this.currentPage < this.totalPages) {
              this.currentPage = this.currentPage++;
              this.updateVisibleItems(this.currentPage++);
            }
          }
        }, {
          key: "prevRolesPage",
          value: function prevRolesPage() {
            if (this.currentPage > 1) {
              this.currentPage = this.currentPage--;
              this.updateVisibleItems(this.currentPage--);
            }
          }
        }, {
          key: "getDemo",
          value: function getDemo() {
            this.jumpService.getDemo().subscribe(function (data) {}, function (error) {
              console.error('Error fetching data', error);
            });
          }
        }, {
          key: "goToPage",
          value: function goToPage(page) {
            this.expandedRow = null;

            if (page >= 1 && page <= this.totalPages) {
              this.currentPage = page;

              if (this.searchTerm) {
                this.getSearchOpenRolesData(this.currentPage);
              } else {
                this.getOpenRoles(this.currentPage);
              }
            }
          }
        }, {
          key: "goToDashboardPage",
          value: function goToDashboardPage(page) {
            this.expandedDashboardRow = null;

            if (page >= 1 && page <= this.totalPagesperGrid) {
              this.currentPage = page;

              if (this.searchTerm) {
                this.getSearchDashboardData(this.currentPage);
              } else {
                this.getActiveTrData(this.currentPage);
              }
            }
          }
        }, {
          key: "getDisplayedPages",
          value: function getDisplayedPages() {
            var pages = [];

            if (this.totalPages <= 5) {
              for (var i = 2; i < this.totalPages; i++) {
                pages.push(i);
              }
            } else {
              if (this.currentPage <= 3) {
                for (var _i = 2; _i <= 5; _i++) {
                  pages.push(_i);
                }
              } else if (this.currentPage >= this.totalPages - 2) {
                for (var _i2 = this.totalPages - 4; _i2 < this.totalPages; _i2++) {
                  pages.push(_i2);
                }
              } else {
                for (var _i3 = this.currentPage - 1; _i3 <= this.currentPage + 1; _i3++) {
                  pages.push(_i3);
                }
              }
            }

            return pages;
          }
        }, {
          key: "toggleRow",
          value: function toggleRow(rowId) {
            this.expandedRow = this.expandedRow === rowId ? null : rowId;
            this.showDetails();
          }
        }, {
          key: "applyJob",
          value: function applyJob() {
            this.showApplyDetails = true;
            this.showId = 'profile-vertical';
          }
        }, {
          key: "showDetails",
          value: function showDetails() {
            this.showId = "home-vertical";
            this.showApplyDetails = false;
            this.file = "";
            this.fileName = "";
            this.warningMessage = "";
            this.frmEditProfile.controls["fileName"].reset();
            this.fileInput.nativeElement.value = '';
            this.frmEditProfile.controls["phoneNumber"].reset();
            this.frmEditProfile.controls["location"].reset();
            this.frmEditProfile.controls["experience"].reset();
            this.frmEditProfile.controls["trianzExperience"].reset();
            this.frmEditProfile.controls["primaryskill"].reset();
            this.frmEditProfile.controls["secondaryskill"].reset();
          }
        }, {
          key: "getMyProfile",
          value: function getMyProfile() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var userInfo;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      userInfo = localStorage.getItem('userDetails');
                      this.userInfo = JSON.parse(userInfo);
                      if (this.userInfo) this.createForm();

                    case 3:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "createForm",
          value: function createForm() {
            var _this21 = this;

            var userInfo = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : "";

            var _a;

            userInfo = this.userInfo;
            this.frmEditProfile = this.fb.group({
              fname: [userInfo.name, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_3__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(99)]],
              // lname: [userInfo.lastname, [Validators.required, asciiValidator(),Validators.maxLength(99)]],
              email: [userInfo.email, [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$")]],
              phoneNumber: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].pattern(/^[5-9]\d{9}$/)]],
              location: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(99)]],
              experience: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].max(99)]],
              trianzExperience: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].max(99), this.trianzExperienceValidator()]],
              primaryskill: ["", [_angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required, Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_3__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(500)]],
              secondaryskill: ["", [Object(_ascii_validator__WEBPACK_IMPORTED_MODULE_3__["asciiValidator"])(), _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].maxLength(500)]],
              fileName: [(_a = this.file) === null || _a === void 0 ? void 0 : _a.name, _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"] === null || _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"] === void 0 ? void 0 : _angular_forms__WEBPACK_IMPORTED_MODULE_1__["Validators"].required]
            });
            this.frmEditProfile.get('experience').valueChanges.subscribe(function () {
              _this21.frmEditProfile.get('trianzExperience').updateValueAndValidity();
            });
          }
        }, {
          key: "trianzExperienceValidator",
          value: function trianzExperienceValidator() {
            var _this22 = this;

            return function (control) {
              var _a, _b;

              var totalExperience = (_b = (_a = _this22.frmEditProfile) === null || _a === void 0 ? void 0 : _a.get('experience')) === null || _b === void 0 ? void 0 : _b.value;
              var trianzExperience = control.value;
              return trianzExperience > totalExperience ? {
                experienceMismatch: true
              } : null;
            };
          }
        }, {
          key: "downloadDocument",
          value: function downloadDocument(email) {
            var url = email ? 'https://jumpuat.trianz.com/jump/recruiter/profile/' + email : 'https://jumpuat.trianz.com/jump/employee/profile';
            var anchor = document.createElement('a');
            anchor.href = url;
            anchor.download = '';
            anchor.click();
          }
        }, {
          key: "uploadFile",
          value: function uploadFile(event) {
            this.imageFlag = true;
            var reader = new FileReader();
            var file = event.target.files[0];
            this.file = file;
            var fileExtension = file.name.split('.').pop().toLowerCase();

            if (file && fileExtension == 'pptx' || fileExtension == 'ppt') {
              this.warningMessage = "";

              if (event.target.files && event.target.files[0]) {
                reader.readAsDataURL(file);

                reader.onload = function () {};

                this.uploadResume();
              }
            } else {
              this.warningMessage = "Only PPT files are allowed.";
              this.frmEditProfile.controls["fileName"].reset();
              this.file = "";
            }
          }
        }, {
          key: "openFileInput",
          value: function openFileInput() {
            var fileInput = document.querySelector('input[type="file"]');
            fileInput === null || fileInput === void 0 ? void 0 : fileInput.click();
          }
        }, {
          key: "uploadResume",
          value: function uploadResume() {
            var _this23 = this;

            this.isLoading = true;
            var formData = new FormData();
            formData.append('file', this.file);
            this.jumpService.uploadAttachment(formData).subscribe(function (response) {
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'success',
                title: "File uploaded successfully!"
              });

              _this23.frmEditProfile.controls["fileName"].setValue(_this23.file.name);

              _this23.fileName = response === null || response === void 0 ? void 0 : response.fileName;
              _this23.isLoading = false;
            }, function (error) {
              var _a;

              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'error',
                title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
              });

              _this23.frmEditProfile.controls["fileName"].reset();

              _this23.file = "";
              _this23.isLoading = false;
            });
          }
        }, {
          key: "saveJob",
          value: function saveJob(id) {
            var _this24 = this;

            this.isLoading = true;
            var updateData = {
              "trId": id,
              "email": this.frmEditProfile.controls["email"].value,
              "empName": this.frmEditProfile.controls["fname"].value,
              "mobile": this.frmEditProfile.controls["phoneNumber"].value,
              "trianzExperience": this.frmEditProfile.controls["trianzExperience"].value,
              "totalExperience": this.frmEditProfile.controls["experience"].value,
              "location": this.frmEditProfile.controls["location"].value,
              "primarySkills": this.frmEditProfile.controls["primaryskill"].value,
              "secondarySkills": this.frmEditProfile.controls["secondaryskill"].value
            };
            this.jumpService.applyJob(updateData).subscribe(function (response) {
              _this24.frmEditProfile.controls["fileName"].reset();

              _this24.file = "";
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'success',
                title: 'Your application has been submitted successfully!'
              });
              _this24.isLoading = false;
              _this24.showApplyDetails = false;

              if (_this24.searchTerm) {
                _this24.getSearchOpenRolesData(_this24.currentPage);
              } else {
                _this24.getOpenRoles(_this24.currentPage);
              }

              _this24.isApplied = true;
            }, function (error) {
              var _a;

              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'error',
                title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
              });
              _this24.isLoading = false;
            });
          } // dashboard

        }, {
          key: "toggleDashboardRow",
          value: function toggleDashboardRow(rowId, item) {
            this.expandedDashboardRow = this.expandedDashboardRow === rowId ? null : rowId;
            this.jobId = item === null || item === void 0 ? void 0 : item.trId;
            this.getApplicationsList(item === null || item === void 0 ? void 0 : item.trId);
            this.showApplications();
          }
        }, {
          key: "showDashboardDetails",
          value: function showDashboardDetails() {
            this.viewDashboardDetails = 0;
          }
        }, {
          key: "showApplications",
          value: function showApplications() {
            this.viewDashboardDetails = 1; // this.showSelectedCandidate=false
            // this.showId = 'profile-vertical'
          }
        }, {
          key: "showCandidateList",
          value: function showCandidateList() {
            this.viewDashboardDetails = 2;
          }
        }, {
          key: "openStatusDialog",
          value: function openStatusDialog(item) {
            this.currentItem = item;
            this.selectedStatus = item.statusId;
            console.log(this.selectedStatus);
            this.email = item === null || item === void 0 ? void 0 : item.email; // this.isDialogOpen = true;
          }
        }, {
          key: "cancel",
          value: function cancel() {
            this.isDialogOpen = false;
          }
        }, {
          key: "getApplicationsList",
          value: function getApplicationsList(jobId) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var _this25 = this;

              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      this.jumpService.getApplicationsListByTr(jobId).subscribe(function (data) {
                        var colorArr = ['#fce5cd', '#d9ead3', '#c9daf8', '#f4cccc', '#e6e6e6', '#fff2cc', '#d9d2e9', '#DFF0D8'];
                        var textColors = ['#e69138', '#6aa84f', '#3c78d8', '#cc0000', '#999999', '#e69138', '#6a329f', '#3C763D'];
                        var statusColorMap = {
                          1: colorArr[0],
                          10: colorArr[1],
                          20: colorArr[2],
                          30: colorArr[3],
                          40: colorArr[4],
                          50: colorArr[5],
                          60: colorArr[6],
                          70: colorArr[7]
                        };
                        var statusTextColorMap = {
                          1: textColors[0],
                          10: textColors[1],
                          20: textColors[2],
                          30: textColors[3],
                          40: textColors[4],
                          50: textColors[5],
                          60: textColors[6],
                          70: textColors[7]
                        };
                        data.data.forEach(function (application) {
                          application.color = statusColorMap[application.statusId];
                          application.textColor = statusTextColorMap[application.statusId];
                        });
                        _this25.statusOptions = data === null || data === void 0 ? void 0 : data.appStatusList;
                        _this25.candidates = data.data;

                        _this25.search();
                      });

                      (function (error) {
                        _this25.loading = false;
                        console.error('Error fetching data', error);
                      });

                    case 2:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "changeStatus",
          value: function changeStatus() {
            var _this26 = this;

            if (this.currentItem.statusId == this.selectedStatus) {
              this.isDialogOpen = false;
            } else {
              var trData = {
                "trId": this.jobId,
                "email": this.email,
                "statusId": this.selectedStatus
              };
              this.jumpService.updateNotes(trData).subscribe(function (response) {
                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'success',
                  title: 'Status changed successfully!'
                });
                _this26.email = '';

                _this26.getApplicationsList(_this26.jobId);

                _this26.currentItem = "";
              }, function (error) {
                var _a;

                sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                  icon: 'error',
                  title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
                });
              });
            }
          }
        }, {
          key: "onGlobalClick",
          value: function onGlobalClick(event) {
            // Close the dialog if a click happens outside of it
            var target = event.target;

            if (!target.closest('.status-dialog')) {
              this.currentItem = null;
            }
          }
        }, {
          key: "openEmpData",
          value: function openEmpData(data) {
            this.empData = data;
            this.viewDashboardDetails = 2;
            this.selectedDetailsIndex = 0; // this.showSelectedCandidate = true
            // this.viewDashboardDetails = false
          }
        }, {
          key: "closeEmpDataModal",
          value: function closeEmpDataModal() {
            this.empData = "";
            $("#candidateModal").modal("hide");
          }
        }, {
          key: "closeNotes",
          value: function closeNotes() {
            $("#notes").modal("hide");
          }
        }, {
          key: "closeHistoryModal",
          value: function closeHistoryModal() {
            $("#history").modal("hide");
          }
        }, {
          key: "getNotesHistory",
          value: function getNotesHistory(candidate) {
            var _this27 = this;

            this.loading = true;
            this.candidateName = candidate.empName;
            this.jumpService.getNotesHistory(candidate.trId, candidate === null || candidate === void 0 ? void 0 : candidate.email).subscribe(function (data) {
              _this27.notesHistory = data === null || data === void 0 ? void 0 : data.notesHist;
              _this27.statusHistory = data === null || data === void 0 ? void 0 : data.statusHist;
              _this27.loading = false;
            }, function (error) {
              _this27.loading = false;
            });
          }
        }, {
          key: "getFormattedDate",
          value: function getFormattedDate(currentDate) {
            return moment__WEBPACK_IMPORTED_MODULE_4___default()(currentDate, 'DD-MM-YYYY HH:mm:ss').format('DD-MM-YYYY HH:mm');
          }
        }, {
          key: "openNotes",
          value: function openNotes(data) {
            this.notesComments = data.notes;
            this.changeComment = data === null || data === void 0 ? void 0 : data.notes;
            this.email = data.email;
          }
        }, {
          key: "saveNotes",
          value: function saveNotes() {
            var _this28 = this;

            this.isLoading = true;
            var trData = {
              "trId": this.jobId,
              "email": this.email,
              "notes": this.notesComments
            };
            this.jumpService.updateNotes(trData).subscribe(function (response) {
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'success',
                title: 'Notes  updated successfully!'
              });
              _this28.notesComments = '';

              _this28.getApplicationsList(_this28.jobId);

              setTimeout(function () {
                _this28.empData = _this28.candidates.find(function (user) {
                  return user.email === _this28.email;
                });

                if (_this28.empData) {
                  _this28.openNotes(_this28.empData);

                  console.log('Employee data found:', _this28.empData);
                }
              }, 65);
              _this28.isLoading = false;
            }, function (error) {
              var _a;

              console.error('Error creating TR', error);
              sweetalert2__WEBPACK_IMPORTED_MODULE_2___default.a.fire({
                icon: 'error',
                title: (_a = error.error) === null || _a === void 0 ? void 0 : _a.message
              });
            });
          }
        }, {
          key: "toggleMyApplicationsRow",
          value: function toggleMyApplicationsRow(rowId) {
            this.expandedApplicationsRow = this.expandedApplicationsRow === rowId ? null : rowId;
          } // pagiation and search

        }, {
          key: "search",
          value: function search() {
            this.currentApplicationsPage = 1;
            this.updateApplicationsPagination();
          }
        }, {
          key: "updateApplicationsPagination",
          value: function updateApplicationsPagination() {
            this.totalPages = Math.ceil(this.candidates.length / this.itemsPerApplyPage);
            this.pages = Array.from({
              length: this.totalPages
            }, function (_, i) {
              return i + 1;
            });
            this.updateApplicationsVisibleItems();
          }
        }, {
          key: "updateApplicationsVisibleItems",
          value: function updateApplicationsVisibleItems() {
            var startIndex = (this.currentApplicationsPage - 1) * this.itemsPerApplyPage;
            var endIndex = startIndex + this.itemsPerApplyPage;
            this.startItem = startIndex + 1;
            this.endItem = Math.min(endIndex, this.candidates.length);
            this.applicationsList = this.candidates.slice(startIndex, endIndex);
          }
        }, {
          key: "setApplyPage",
          value: function setApplyPage(page) {
            this.currentApplicationsPage = page;
            this.updateApplicationsVisibleItems();
          }
        }, {
          key: "nextApplyPage",
          value: function nextApplyPage() {
            if (this.currentApplicationsPage < this.totalPages) {
              this.currentApplicationsPage++;
              this.updateApplicationsVisibleItems();
            }
          }
        }, {
          key: "prevApplyPage",
          value: function prevApplyPage() {
            if (this.currentApplicationsPage > 1) {
              this.currentApplicationsPage--;
              this.updateApplicationsVisibleItems();
            }
          } // candiate details tabs

        }, {
          key: "candidateTabClick",
          value: function candidateTabClick(index) {
            if (index == 1) {
              this.openNotes(this.empData);
            } else if (index == 2) {
              this.getNotesHistory(this.empData);
            } else {// this.getMyApplicationsData()
            }
          }
        }]);

        return JobMobilityComponent;
      }();
      /***/

    },

    /***/
    "Ss9G":
    /*!*****************************************!*\
      !*** ./src/app/app.module.ngfactory.js ***!
      \*****************************************/

    /*! exports provided: AppModuleNgFactory */

    /***/
    function Ss9G(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModuleNgFactory", function () {
        return AppModuleNgFactory;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _app_module__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./app.module */
      "ZAI4");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _node_modules_angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../../node_modules/@angular/router/router.ngfactory */
      "pMnS");
      /* harmony import */


      var _job_mobility_job_mobility_component_ngfactory__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./job-mobility/job-mobility.component.ngfactory */
      "MAAT");
      /* harmony import */


      var _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./job-details/job-details.component.ngfactory */
      "sPRM");
      /* harmony import */


      var _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../../node_modules/@ng-bootstrap/ng-bootstrap/ng-bootstrap.ngfactory */
      "9AJC");
      /* harmony import */


      var _node_modules_ng_pick_datetime_dialog_dialog_container_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../../node_modules/ng-pick-datetime/dialog/dialog-container.component.ngfactory */
      "No7X");
      /* harmony import */


      var _node_modules_ng_pick_datetime_date_time_date_time_picker_container_component_ngfactory__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! ../../node_modules/ng-pick-datetime/date-time/date-time-picker-container.component.ngfactory */
      "bIR2");
      /* harmony import */


      var _app_component_ngfactory__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
      /*! ./app.component.ngfactory */
      "yvrC");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /* harmony import */


      var _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
      /*! @angular/animations/browser */
      "fDlF");
      /* harmony import */


      var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
      /*! @angular/platform-browser/animations */
      "omvX");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
      /*! @angular/common/http */
      "IheW");
      /* harmony import */


      var apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(
      /*! apollo-angular-link-http */
      "h3O7");
      /* harmony import */


      var apollo_angular__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(
      /*! apollo-angular */
      "nbgS");
      /* harmony import */


      var _graphql_module__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(
      /*! ./graphql.module */
      "4KHl");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _angular_animations__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(
      /*! @angular/animations */
      "GS7A");
      /* harmony import */


      var _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(
      /*! @ng-bootstrap/ng-bootstrap */
      "G0yt");
      /* harmony import */


      var _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(
      /*! @angular/cdk/a11y */
      "YEUz");
      /* harmony import */


      var _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(
      /*! @angular/cdk/platform */
      "SCoL");
      /* harmony import */


      var _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(
      /*! @angular/cdk/tree */
      "y7ui");
      /* harmony import */


      var _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(
      /*! @angular/cdk/drag-drop */
      "ltgo");
      /* harmony import */


      var _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(
      /*! @angular/cdk/scrolling */
      "7KAL");
      /* harmony import */


      var _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(
      /*! @angular/cdk/observers */
      "9b/N");
      /* harmony import */


      var _angular_material_core__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(
      /*! @angular/material/core */
      "UhP/");
      /* harmony import */


      var _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(
      /*! @angular/cdk/overlay */
      "1O3W");
      /* harmony import */


      var _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(
      /*! @angular/cdk/bidi */
      "9gLZ");
      /* harmony import */


      var ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(
      /*! ng-pick-datetime/dialog/dialog.service */
      "Tq4R");
      /* harmony import */


      var ng_pick_datetime_date_time_date_time_picker_intl_service__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/date-time-picker-intl.service */
      "rAFq");
      /* harmony import */


      var ng_pick_datetime_date_time_date_time_picker_component__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/date-time-picker.component */
      "4D9t");
      /* harmony import */


      var ng_pick_datetime_date_time_adapter_date_time_adapter_class__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/adapter/date-time-adapter.class */
      "bMPK");
      /* harmony import */


      var ng_pick_datetime_date_time_adapter_native_date_time_adapter_class__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/adapter/native-date-time-adapter.class */
      "UiI2");
      /* harmony import */


      var ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(
      /*! ng-multiselect-dropdown */
      "UPO+");
      /* harmony import */


      var _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(
      /*! @azure/msal-angular */
      "l+12");
      /* harmony import */


      var _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(
      /*! ./job-mobility/job-mobility.component */
      "SDTg");
      /* harmony import */


      var _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(
      /*! ./job-details/job-details.component */
      "HJCg");
      /* harmony import */


      var _app_routing_module__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(
      /*! ./app-routing.module */
      "vY5A");
      /* harmony import */


      var ngx_spinner__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(
      /*! ngx-spinner */
      "7g+E");
      /* harmony import */


      var ngx_ui_loader__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(
      /*! ngx-ui-loader */
      "HHV2");
      /* harmony import */


      var ngx_loading__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(
      /*! ngx-loading */
      "Wiza");
      /* harmony import */


      var _angular_cdk_table__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(
      /*! @angular/cdk/table */
      "GXRp");
      /* harmony import */


      var _angular_material_button__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(
      /*! @angular/material/button */
      "Dxy4");
      /* harmony import */


      var _angular_material_icon__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(
      /*! @angular/material/icon */
      "Tj54");
      /* harmony import */


      var _angular_material_form_field__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(
      /*! @angular/material/form-field */
      "Q2Ze");
      /* harmony import */


      var _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(
      /*! @angular/cdk/text-field */
      "8sFK");
      /* harmony import */


      var _angular_material_input__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(
      /*! @angular/material/input */
      "e6WT");
      /* harmony import */


      var _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(
      /*! @angular/cdk/portal */
      "1z/I");
      /* harmony import */


      var _angular_material_tabs__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(
      /*! @angular/material/tabs */
      "M9ds");
      /* harmony import */


      var _kolkov_angular_editor__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(
      /*! @kolkov/angular-editor */
      "Q6Ar");
      /* harmony import */


      var _syncfusion_ej2_angular_richtexteditor__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(
      /*! @syncfusion/ej2-angular-richtexteditor */
      "SH2w");
      /* harmony import */


      var ngx_summernote__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(
      /*! ngx-summernote */
      "8Z0m");
      /* harmony import */


      var ng_pick_datetime_dialog_dialog_module__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(
      /*! ng-pick-datetime/dialog/dialog.module */
      "jRYl");
      /* harmony import */


      var ng_pick_datetime_date_time_date_time_module__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/date-time.module */
      "KL2N");
      /* harmony import */


      var ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/adapter/native-date-time.module */
      "QX+E");
      /* harmony import */


      var ng_pick_datetime_date_time_adapter_date_time_format_class__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(
      /*! ng-pick-datetime/date-time/adapter/date-time-format.class */
      "EFU/");
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var AppModuleNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵcmf"](_app_module__WEBPACK_IMPORTED_MODULE_1__["AppModule"], [_app_component__WEBPACK_IMPORTED_MODULE_2__["AppComponent"]], function (_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmod"]([_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵCodegenComponentFactoryResolver"], [[8, [_node_modules_angular_router_router_ngfactory__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_router_router_lNgFactory"], _job_mobility_job_mobility_component_ngfactory__WEBPACK_IMPORTED_MODULE_4__["JobMobilityComponentNgFactory"], _job_details_job_details_component_ngfactory__WEBPACK_IMPORTED_MODULE_5__["JobDetailsComponentNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["NgbAlertNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["NgbDatepickerNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["ɵuNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["ɵvNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["ɵmNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["ɵrNgFactory"], _node_modules_ng_bootstrap_ng_bootstrap_ng_bootstrap_ngfactory__WEBPACK_IMPORTED_MODULE_6__["ɵsNgFactory"], _node_modules_ng_pick_datetime_dialog_dialog_container_component_ngfactory__WEBPACK_IMPORTED_MODULE_7__["OwlDialogContainerComponentNgFactory"], _node_modules_ng_pick_datetime_date_time_date_time_picker_container_component_ngfactory__WEBPACK_IMPORTED_MODULE_8__["OwlDateTimeContainerComponentNgFactory"], _app_component_ngfactory__WEBPACK_IMPORTED_MODULE_9__["AppComponentNgFactory"]]], [3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"]], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleRef"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_r"], [[3, _angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common__WEBPACK_IMPORTED_MODULE_10__["NgLocalization"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["NgLocaleLocalization"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["LOCALE_ID"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_x"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_t"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_ID"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_g"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_p"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_q"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["DomSanitizer"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomSanitizerImpl"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](6144, _angular_core__WEBPACK_IMPORTED_MODULE_0__["Sanitizer"], null, [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["DomSanitizer"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["HAMMER_GESTURE_CONFIG"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["HammerGestureConfig"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["EVENT_MANAGER_PLUGINS"], function (p0_0, p0_1, p0_2, p1_0, p2_0, p2_1, p2_2, p2_3) {
          return [new _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomEventsPlugin"](p0_0, p0_1, p0_2), new _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵKeyEventsPlugin"](p1_0), new _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵHammerGesturesPlugin"](p2_0, p2_1, p2_2, p2_3)];
        }, [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["HAMMER_GESTURE_CONFIG"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵConsole"], [2, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["HAMMER_LOADER"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["EventManager"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["EventManager"], [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["EVENT_MANAGER_PLUGINS"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](135680, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomSharedStylesHost"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomSharedStylesHost"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomRendererFactory2"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomRendererFactory2"], [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["EventManager"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomSharedStylesHost"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_ID"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["AnimationDriver"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ɵangular_packages_platform_browser_animations_animations_a"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["ɵAnimationStyleNormalizer"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ɵangular_packages_platform_browser_animations_animations_b"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["ɵAnimationEngine"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ɵInjectableAnimationEngine"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["AnimationDriver"], _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["ɵAnimationStyleNormalizer"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["RendererFactory2"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ɵangular_packages_platform_browser_animations_animations_c"], [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomRendererFactory2"], _angular_animations_browser__WEBPACK_IMPORTED_MODULE_12__["ɵAnimationEngine"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](6144, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵSharedStylesHost"], null, [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵDomSharedStylesHost"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_core__WEBPACK_IMPORTED_MODULE_0__["Testability"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Testability"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_g"], [_angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_router__WEBPACK_IMPORTED_MODULE_14__["NoPreloading"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["NoPreloading"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](6144, _angular_router__WEBPACK_IMPORTED_MODULE_14__["PreloadingStrategy"], null, [_angular_router__WEBPACK_IMPORTED_MODULE_14__["NoPreloading"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](135680, _angular_router__WEBPACK_IMPORTED_MODULE_14__["RouterPreloader"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["RouterPreloader"], [_angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleFactoryLoader"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Compiler"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["PreloadingStrategy"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_router__WEBPACK_IMPORTED_MODULE_14__["PreloadAllModules"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["PreloadAllModules"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_o"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_c"], [_angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["ViewportScroller"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_CONFIGURATION"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_INITIALIZER"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_j"], [_angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_h"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_BOOTSTRAP_LISTENER"], function (p0_0) {
          return [p0_0];
        }, [_angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_INITIALIZER"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_d"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_d"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](6144, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["XhrFactory"], null, [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_d"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpXhrBackend"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpXhrBackend"], [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["XhrFactory"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](6144, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpBackend"], null, [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpXhrBackend"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpHandler"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵHttpInterceptingHandler"], [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpBackend"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClient"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClient"], [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpHandler"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__["HttpLink"], apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__["HttpLink"], [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClient"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, apollo_angular__WEBPACK_IMPORTED_MODULE_17__["APOLLO_OPTIONS"], _graphql_module__WEBPACK_IMPORTED_MODULE_18__["createApollo"], [apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__["HttpLink"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, apollo_angular__WEBPACK_IMPORTED_MODULE_17__["Apollo"], apollo_angular__WEBPACK_IMPORTED_MODULE_17__["Apollo"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], [2, apollo_angular__WEBPACK_IMPORTED_MODULE_17__["APOLLO_OPTIONS"]], [2, apollo_angular__WEBPACK_IMPORTED_MODULE_17__["APOLLO_NAMED_OPTIONS"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpXsrfTokenExtractor"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_g"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["PLATFORM_ID"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_e"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_h"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_h"], [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpXsrfTokenExtractor"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_f"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HTTP_INTERCEPTORS"], function (p0_0) {
          return [p0_0];
        }, [_angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_h"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵangular_packages_forms_forms_n"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵangular_packages_forms_forms_n"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_animations__WEBPACK_IMPORTED_MODULE_20__["AnimationBuilder"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ɵBrowserAnimationBuilder"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["RendererFactory2"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModal"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModal"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["ɵw"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModalConfig"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["FormBuilder"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__["FormBuilder"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](135680, _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["FocusMonitor"], _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["FocusMonitor"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_23__["Platform"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"]], [2, _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["FOCUS_MONITOR_DEFAULT_OPTIONS"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_24__["CdkTreeNodeDef"], _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_24__["CdkTreeNodeDef"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["TemplateRef"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__["DragDrop"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__["DragDrop"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__["ViewportRuler"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__["DragDropRegistry"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_27__["MutationObserverFactory"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_27__["MutationObserverFactory"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["ErrorStateMatcher"], _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["ErrorStateMatcher"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["ScrollStrategyOptions"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayContainer"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayPositionBuilder"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayKeyboardDispatcher"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_30__["Directionality"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["ɵangular_material_src_cdk_overlay_overlay_c"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["ɵangular_material_src_cdk_overlay_overlay_d"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OWL_DIALOG_SCROLL_STRATEGY"], ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OWL_DIALOG_SCROLL_STRATEGY_PROVIDER_FACTORY"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OwlDialogService"], ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OwlDialogService"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"]], ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OWL_DIALOG_SCROLL_STRATEGY"], [2, ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OWL_DIALOG_DEFAULT_OPTIONS"]], [3, ng_pick_datetime_dialog_dialog_service__WEBPACK_IMPORTED_MODULE_31__["OwlDialogService"]], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayContainer"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, ng_pick_datetime_date_time_date_time_picker_intl_service__WEBPACK_IMPORTED_MODULE_32__["OwlDateTimeIntl"], ng_pick_datetime_date_time_date_time_picker_intl_service__WEBPACK_IMPORTED_MODULE_32__["OwlDateTimeIntl"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](5120, ng_pick_datetime_date_time_date_time_picker_component__WEBPACK_IMPORTED_MODULE_33__["OWL_DTPICKER_SCROLL_STRATEGY"], ng_pick_datetime_date_time_date_time_picker_component__WEBPACK_IMPORTED_MODULE_33__["OWL_DTPICKER_SCROLL_STRATEGY_PROVIDER_FACTORY"], [_angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["Overlay"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, ng_pick_datetime_date_time_adapter_date_time_adapter_class__WEBPACK_IMPORTED_MODULE_34__["DateTimeAdapter"], ng_pick_datetime_date_time_adapter_native_date_time_adapter_class__WEBPACK_IMPORTED_MODULE_35__["NativeDateTimeAdapter"], [[2, ng_pick_datetime_date_time_adapter_date_time_adapter_class__WEBPACK_IMPORTED_MODULE_34__["OWL_DATE_TIME_LOCALE"]], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_23__["Platform"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_36__["ɵb"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_36__["ɵb"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalBroadcastService"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalBroadcastService"], [_azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MSAL_INSTANCE"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalService"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](4608, _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalGuard"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalGuard"], [_azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MSAL_GUARD_CONFIG"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalBroadcastService"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalService"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_common__WEBPACK_IMPORTED_MODULE_10__["CommonModule"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["CommonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ErrorHandler"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵangular_packages_platform_browser_platform_browser_a"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgProbeToken"], function () {
          return [_angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_b"]()];
        }, []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_h"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_h"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_INITIALIZER"], function (p0_0, p1_0) {
          return [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["ɵangular_packages_platform_browser_platform_browser_m"](p0_0), _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_i"](p1_0)];
        }, [[2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgProbeToken"]], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_h"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationInitStatus"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationInitStatus"], [[2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["APP_INITIALIZER"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](131584, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationRef"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationRef"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵConsole"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ErrorHandler"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ComponentFactoryResolver"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationInitStatus"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationModule"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationModule"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["ApplicationRef"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["BrowserModule"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["BrowserModule"], [[3, _angular_platform_browser__WEBPACK_IMPORTED_MODULE_11__["BrowserModule"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_a"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_e"], [[3, _angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_router__WEBPACK_IMPORTED_MODULE_14__["UrlSerializer"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["DefaultUrlSerializer"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ChildrenOutletContexts"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ChildrenOutletContexts"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_CONFIGURATION"], {
          scrollPositionRestoration: "top"
        }, []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_common__WEBPACK_IMPORTED_MODULE_10__["LocationStrategy"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_d"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["PlatformLocation"], [2, _angular_common__WEBPACK_IMPORTED_MODULE_10__["APP_BASE_HREF"]], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_CONFIGURATION"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"], [_angular_common__WEBPACK_IMPORTED_MODULE_10__["LocationStrategy"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["PlatformLocation"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["Compiler"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Compiler"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](512, _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleFactoryLoader"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["SystemJsNgModuleLoader"], [_angular_core__WEBPACK_IMPORTED_MODULE_0__["Compiler"], [2, _angular_core__WEBPACK_IMPORTED_MODULE_0__["SystemJsNgModuleLoaderConfig"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTES"], function () {
          return [[{
            path: "",
            component: _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_38__["JobMobilityComponent"]
          }, {
            path: "jump",
            component: _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_38__["JobMobilityComponent"]
          }, {
            path: "job-details",
            component: _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_39__["JobDetailsComponent"]
          }]];
        }, []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1024, _angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_f"], [_angular_router__WEBPACK_IMPORTED_MODULE_14__["UrlSerializer"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ChildrenOutletContexts"], _angular_common__WEBPACK_IMPORTED_MODULE_10__["Location"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injector"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModuleFactoryLoader"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["Compiler"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTES"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["ROUTER_CONFIGURATION"], [2, _angular_router__WEBPACK_IMPORTED_MODULE_14__["UrlHandlingStrategy"]], [2, _angular_router__WEBPACK_IMPORTED_MODULE_14__["RouteReuseStrategy"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_router__WEBPACK_IMPORTED_MODULE_14__["RouterModule"], _angular_router__WEBPACK_IMPORTED_MODULE_14__["RouterModule"], [[2, _angular_router__WEBPACK_IMPORTED_MODULE_14__["ɵangular_packages_router_router_a"]], [2, _angular_router__WEBPACK_IMPORTED_MODULE_14__["Router"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _app_routing_module__WEBPACK_IMPORTED_MODULE_40__["AppRoutingModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_40__["AppRoutingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, apollo_angular__WEBPACK_IMPORTED_MODULE_17__["ApolloModule"], apollo_angular__WEBPACK_IMPORTED_MODULE_17__["ApolloModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__["HttpLinkModule"], apollo_angular_link_http__WEBPACK_IMPORTED_MODULE_16__["HttpLinkModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _graphql_module__WEBPACK_IMPORTED_MODULE_18__["GraphQLModule"], _graphql_module__WEBPACK_IMPORTED_MODULE_18__["GraphQLModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientXsrfModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientXsrfModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["HttpClientModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵangular_packages_forms_forms_d"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ɵangular_packages_forms_forms_d"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__["FormsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ngx_spinner__WEBPACK_IMPORTED_MODULE_41__["NgxSpinnerModule"], ngx_spinner__WEBPACK_IMPORTED_MODULE_41__["NgxSpinnerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ngx_ui_loader__WEBPACK_IMPORTED_MODULE_42__["NgxUiLoaderModule"], ngx_ui_loader__WEBPACK_IMPORTED_MODULE_42__["NgxUiLoaderModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["BrowserAnimationsModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["BrowserAnimationsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ngx_loading__WEBPACK_IMPORTED_MODULE_43__["NgxLoadingModule"], ngx_loading__WEBPACK_IMPORTED_MODULE_43__["NgxLoadingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbAccordionModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbAccordionModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbAlertModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbAlertModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbButtonsModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbButtonsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbCarouselModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbCarouselModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbCollapseModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbCollapseModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbDatepickerModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbDatepickerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbDropdownModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbDropdownModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModalModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModalModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbNavModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbNavModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbPaginationModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbPaginationModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbPopoverModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbPopoverModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbProgressbarModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbProgressbarModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbRatingModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbRatingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTimepickerModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTimepickerModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbToastModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbToastModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTooltipModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTooltipModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTypeaheadModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTypeaheadModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTabsetModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbTabsetModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModule"], _ng_bootstrap_ng_bootstrap__WEBPACK_IMPORTED_MODULE_21__["NgbModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ReactiveFormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_19__["ReactiveFormsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_table__WEBPACK_IMPORTED_MODULE_44__["CdkTableModule"], _angular_cdk_table__WEBPACK_IMPORTED_MODULE_44__["CdkTableModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_24__["CdkTreeModule"], _angular_cdk_tree__WEBPACK_IMPORTED_MODULE_24__["CdkTreeModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__["CdkScrollableModule"], _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__["CdkScrollableModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__["DragDropModule"], _angular_cdk_drag_drop__WEBPACK_IMPORTED_MODULE_25__["DragDropModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_30__["BidiModule"], _angular_cdk_bidi__WEBPACK_IMPORTED_MODULE_30__["BidiModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_23__["PlatformModule"], _angular_cdk_platform__WEBPACK_IMPORTED_MODULE_23__["PlatformModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__["ScrollingModule"], _angular_cdk_scrolling__WEBPACK_IMPORTED_MODULE_26__["ScrollingModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["MatCommonModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["MatCommonModule"], [_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["HighContrastModeDetector"], [2, _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["MATERIAL_SANITY_CHECKS"]], [2, _angular_common__WEBPACK_IMPORTED_MODULE_10__["DOCUMENT"]]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["MatRippleModule"], _angular_material_core__WEBPACK_IMPORTED_MODULE_28__["MatRippleModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_button__WEBPACK_IMPORTED_MODULE_45__["MatButtonModule"], _angular_material_button__WEBPACK_IMPORTED_MODULE_45__["MatButtonModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_icon__WEBPACK_IMPORTED_MODULE_46__["MatIconModule"], _angular_material_icon__WEBPACK_IMPORTED_MODULE_46__["MatIconModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_27__["ObserversModule"], _angular_cdk_observers__WEBPACK_IMPORTED_MODULE_27__["ObserversModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_form_field__WEBPACK_IMPORTED_MODULE_47__["MatFormFieldModule"], _angular_material_form_field__WEBPACK_IMPORTED_MODULE_47__["MatFormFieldModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_48__["TextFieldModule"], _angular_cdk_text_field__WEBPACK_IMPORTED_MODULE_48__["TextFieldModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_input__WEBPACK_IMPORTED_MODULE_49__["MatInputModule"], _angular_material_input__WEBPACK_IMPORTED_MODULE_49__["MatInputModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_50__["PortalModule"], _angular_cdk_portal__WEBPACK_IMPORTED_MODULE_50__["PortalModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["A11yModule"], _angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["A11yModule"], [_angular_cdk_a11y__WEBPACK_IMPORTED_MODULE_22__["HighContrastModeDetector"]]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_material_tabs__WEBPACK_IMPORTED_MODULE_51__["MatTabsModule"], _angular_material_tabs__WEBPACK_IMPORTED_MODULE_51__["MatTabsModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _kolkov_angular_editor__WEBPACK_IMPORTED_MODULE_52__["AngularEditorModule"], _kolkov_angular_editor__WEBPACK_IMPORTED_MODULE_52__["AngularEditorModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _syncfusion_ej2_angular_richtexteditor__WEBPACK_IMPORTED_MODULE_53__["RichTextEditorModule"], _syncfusion_ej2_angular_richtexteditor__WEBPACK_IMPORTED_MODULE_53__["RichTextEditorModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ngx_summernote__WEBPACK_IMPORTED_MODULE_54__["NgxSummernoteModule"], ngx_summernote__WEBPACK_IMPORTED_MODULE_54__["NgxSummernoteModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayModule"], _angular_cdk_overlay__WEBPACK_IMPORTED_MODULE_29__["OverlayModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng_pick_datetime_dialog_dialog_module__WEBPACK_IMPORTED_MODULE_55__["OwlDialogModule"], ng_pick_datetime_dialog_dialog_module__WEBPACK_IMPORTED_MODULE_55__["OwlDialogModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng_pick_datetime_date_time_date_time_module__WEBPACK_IMPORTED_MODULE_56__["OwlDateTimeModule"], ng_pick_datetime_date_time_date_time_module__WEBPACK_IMPORTED_MODULE_56__["OwlDateTimeModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__["NativeDateTimeModule"], ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__["NativeDateTimeModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__["OwlNativeDateTimeModule"], ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__["OwlNativeDateTimeModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_36__["NgMultiSelectDropDownModule"], ng_multiselect_dropdown__WEBPACK_IMPORTED_MODULE_36__["NgMultiSelectDropDownModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalModule"], _azure_msal_angular__WEBPACK_IMPORTED_MODULE_37__["MsalModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](1073742336, _app_module__WEBPACK_IMPORTED_MODULE_1__["AppModule"], _app_module__WEBPACK_IMPORTED_MODULE_1__["AppModule"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_core__WEBPACK_IMPORTED_MODULE_0__["DEFAULT_CURRENCY_CODE"], _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵangular_packages_core_core_u"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵINJECTOR_SCOPE"], "root", []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_e"], "XSRF-TOKEN", []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_common_http__WEBPACK_IMPORTED_MODULE_15__["ɵangular_packages_common_http_http_f"], "X-XSRF-TOKEN", []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_13__["ANIMATION_MODULE_TYPE"], "BrowserAnimations", []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, ng_pick_datetime_date_time_adapter_date_time_format_class__WEBPACK_IMPORTED_MODULE_58__["OWL_DATE_TIME_FORMATS"], ng_pick_datetime_date_time_adapter_native_date_time_module__WEBPACK_IMPORTED_MODULE_57__["ɵ0"], []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, ngx_ui_loader__WEBPACK_IMPORTED_MODULE_42__["ɵa"], {
          logoUrl: "../assets/images/Loader-150X150-Alpha.gif",
          logoSize: 60,
          logoPosition: "center-center",
          bgsOpacity: 0
        }, []), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵmpd"](256, "loadingConfig", {}, [])]);
      });
      /***/

    },

    /***/
    "Sy1n":
    /*!**********************************!*\
      !*** ./src/app/app.component.ts ***!
      \**********************************/

    /*! exports provided: AppComponent */

    /***/
    function Sy1n(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
        return AppComponent;
      });
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");

      var AppComponent = function AppComponent(sanitizer, router, // private bnIdle: BnNgIdleService,
      titleService, // private utility: UtilityService,
      route) {
        var _this29 = this;

        _classCallCheck(this, AppComponent);

        this.sanitizer = sanitizer;
        this.router = router;
        this.titleService = titleService;
        this.route = route;
        this.title = 'Pulse';
        this.profile_image = "";
        this.envMode = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].mode;
        this.appUrl = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].androidApp;
        this.appUrl2 = src_environments_environment__WEBPACK_IMPORTED_MODULE_0__["environment"].iosApp;
        this.width = 0;
        this.showNav = false;
        this.selected = 'home';
        this.plannerFlag = false;
        this.plannerTime = 0;
        this.tasks = "../assets/images/sidenav/tasks.svg";
        this.tasksActive = "../assets/images/sidenav/tasks-active.svg";
        this.quicklinks = "../assets/images/sidenav/quicklinks.svg";
        this.quicklinksActive = "../assets/images/sidenav/quicklinks-active.svg";
        this.calenders = "../assets/images/calendars.svg";
        this.calender = "../assets/images/sidenav/calendar.svg";
        this.calenderActive = "../assets/images/sidenav/calendar-active.svg";
        this.notification = "../assets/images/sidenav/notification.svg";
        this.notificationActive = "../assets/images/sidenav/notification-active.svg";
        this.contacts = "../assets/images/sidenav/contacts.svg";
        this.contactsActive = "../assets/images/sidenav/contacts-active.svg";
        this.projects = "../assets/images/sidenav/projects.svg";
        this.projectsActive = "../assets/images/sidenav/projects-active.svg";
        this.analytics = "../assets/images/analytics.svg";
        this.analyticsactive = "../assets/images/analytics-blue.svg";
        this.docs = "../assets/images/sidenav/docs.svg";
        this.docsActive = "../assets/images/sidenav/docs-active.svg";
        this.mbo = "../assets/images/sidenav/mbo.svg";
        this.mboactive = "../assets/images/sidenav/mbo-active.svg";
        this.playershow = false;
        this.dropDown = false;
        this.dropDownKey = '';
        this.navState = '';
        this.href = "";
        this.sessioncard = false;
        this.navFlag = 0;
        this.superAdmin = false;
        this.pipeline = "../assets/images/analytics.svg";
        this.showMessage = false;
        this.closeModal = false;
        this.loaderFlag = false;
        this.showWidgetLibrary = false;
        this.mboFlag = false;
        this.showDom = false;
        this.permissions = [];
        this.wGridDisabled = false;
        this.loading = true;
        setTimeout(function () {
          _this29.loading = false;
        }, 3000);
      };
      /***/

    },

    /***/
    "ZAI4":
    /*!*******************************!*\
      !*** ./src/app/app.module.ts ***!
      \*******************************/

    /*! exports provided: MSALInstanceFactory, MSALGuardConfigFactory, MSALInterceptorConfigFactory, AppModule */

    /***/
    function ZAI4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MSALInstanceFactory", function () {
        return MSALInstanceFactory;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MSALGuardConfigFactory", function () {
        return MSALGuardConfigFactory;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "MSALInterceptorConfigFactory", function () {
        return MSALInterceptorConfigFactory;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppModule", function () {
        return AppModule;
      });
      /* harmony import */


      var _azure_msal_browser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @azure/msal-browser */
      "Czdx");
      /* harmony import */


      var src_environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! src/environments/environment */
      "AytR");

      var ngxUiLoaderConfig = {
        logoUrl: '../assets/images/Loader-150X150-Alpha.gif',
        logoSize: 60,
        logoPosition: 'center-center',
        bgsOpacity: 0
      };

      function MSALInstanceFactory() {
        return new _azure_msal_browser__WEBPACK_IMPORTED_MODULE_0__["PublicClientApplication"]({
          auth: {
            clientId: "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].auth.clientId),
            authority: "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].auth.authority),
            redirectUri: "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].redirectUri),
            postLogoutRedirectUri: "".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].redirectUri)
          },
          cache: {
            cacheLocation: "localStorage",
            storeAuthStateInCookie: true
          },
          system: {
            iframeHashTimeout: 10000
          }
        });
      }

      function MSALGuardConfigFactory() {
        return {
          interactionType: _azure_msal_browser__WEBPACK_IMPORTED_MODULE_0__["InteractionType"].Popup,
          authRequest: {
            scopes: ["".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].SPUrl, "/AllSites.Read")]
          }
        };
      }

      function MSALInterceptorConfigFactory() {
        var protectedResourceMap = new Map();
        protectedResourceMap.set("".concat(src_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].SPUrl), ['allsites.read']);
        return {
          interactionType: _azure_msal_browser__WEBPACK_IMPORTED_MODULE_0__["InteractionType"].Popup,
          protectedResourceMap: protectedResourceMap
        };
      }

      var AppModule = function AppModule() {
        _classCallCheck(this, AppModule);
      };
      /***/

    },

    /***/
    "kyDx":
    /*!************************************************************************!*\
      !*** ./src/app/job-details/job-details.component.scss.shim.ngstyle.js ***!
      \************************************************************************/

    /*! exports provided: styles */

    /***/
    function kyDx(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "styles", function () {
        return styles;
      });
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles = [".banner-section[_ngcontent-%COMP%] {\n  background-color: #e7f2f9;\n  background-size: 100%;\n  min-height: 145px;\n  background-position: 100%;\n  background-repeat: no-repeat;\n}\n\n.job-details-header[_ngcontent-%COMP%] {\n  color: #212529;\n  font-size: 16px;\n}\n\n.font-size-18p[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n\n.font-size-16p[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\n.font-size-14p[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\n.font-size-12p[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n\n.font-size-10p[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n\n.loaderDiv[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 60%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  font-size: 60px;\n}\n\n.centerLoader[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.card-img-height[_ngcontent-%COMP%] {\n  min-height: 210px;\n  max-height: 211px;\n}\n\n.canvas-height[_ngcontent-%COMP%] {\n  height: 210px;\n}\n\n@media (min-width: 1900px) {\n  .card-img-height[_ngcontent-%COMP%] {\n    min-height: 243px;\n    max-height: 245px;\n  }\n\n  .canvas-height[_ngcontent-%COMP%] {\n    height: 245px;\n  }\n}\n\n.categoryTabs[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: #a7a7a7;\n  text-decoration: none;\n}\n\n.categoryTabs[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  color: var(--on-background);\n  border-bottom: 2px solid #f60;\n  padding-bottom: 5px;\n}\n\n.vertical-line[_ngcontent-%COMP%] {\n  border-left: 2px solid lightgrey;\n  height: 230px;\n  margin-left: 17px;\n  margin-top: 32px;\n}\n\n#application[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  top: 0rem;\n  left: -834px;\n}\n\n#application[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  padding: 23px;\n}\n\n#history[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  top: 0rem;\n  left: -809px;\n  width: 810px;\n}\n\n.modal-content[_ngcontent-%COMP%] {\n  border-radius: 0;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  box-shadow: 0px 3px 6px #00000029;\n  position: absolute;\n  top: 0rem;\n  left: -834px;\n  min-height: 420px;\n  width: 835px;\n}\n\n.textColor[_ngcontent-%COMP%] {\n  font-size: 24px;\n}\n\n.modal-body[_ngcontent-%COMP%] {\n  padding: 17px 23px;\n  overflow-y: auto;\n  overflow-x: hidden;\n  height: 461px;\n}\n\n.application-details[_ngcontent-%COMP%] {\n  background: #FCFCFC 0% 0% no-repeat padding-box;\n  border: 0.200000003px solid #80808073;\n  padding-left: 10px;\n  padding-top: 10px;\n}\n\n.btn-warning[_ngcontent-%COMP%] {\n  background-color: #FB6B02;\n  color: white;\n  width: 23%;\n}\n\n.file-input-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.custom-file-upload[_ngcontent-%COMP%] {\n  width: 30%;\n  border: 1px solid lightgray;\n  padding: 4px 12px;\n  cursor: pointer;\n  background-color: lightgray;\n}\n\n#imageUpload[_ngcontent-%COMP%] {\n  width: 0;\n  opacity: 0;\n  overflow: hidden;\n  position: absolute;\n  z-index: -1;\n}\n\n.continue-box[_ngcontent-%COMP%] {\n  flex: 1;\n  border: 1px solid #f4dada14;\n  padding: 4px 33px;\n  background-color: #F3F4F6;\n  min-height: 33px;\n}\n\n.tick-button[_ngcontent-%COMP%] {\n  display: inline-block;\n  width: 80px;\n  height: 80px;\n  border-radius: 50%;\n  background-color: #4CAF50;\n  color: white;\n  border: none;\n  cursor: pointer;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.container[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  height: 23vh;\n}\n\n#welcome[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  padding: 13px 50px;\n  overflow-y: auto;\n  overflow-x: hidden;\n  height: 328px;\n}\n\n#welcome[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  border-radius: 0;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  box-shadow: 0px 3px 6px #00000029;\n  position: absolute;\n  top: 6rem;\n  left: -100px;\n  min-height: 340px;\n  width: 800px;\n}\n\n.loader-background[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  z-index: 9999;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.filter-dropdown[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  position: absolute;\n  background-color: white;\n  border: 1px solid #ddd;\n  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n  z-index: 1;\n}\n\n.filter-dropdown[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  padding: 8px 12px;\n}\n\n.filter-dropdown[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]:hover {\n  background-color: #f1f1f1;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  border-bottom: 1px solid var(--Gray-200, #E4E7EC);\n  background: var(--table-header, #D6DCE3);\n  font-size: 14px;\n  color: var(--clientnewstext);\n  font-weight: 500;\n  border: none;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:hover {\n  border-bottom: 1px solid var(--Gray-200, #E4E7EC);\n  background: var(--d-9-d-9-d-9, #D1E1F4);\n}\n\n.th-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  background: var(--table-bg);\n  color: var(--clientnewstext);\n  font-weight: 600;\n}\n\n.table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\ntd[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\ntable[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  border-bottom: 1px solid var(--Gray-200, #E4E7EC);\n  background: var(--d-9-d-9-d-9, #D1E1F4);\n}\n\n.last-item[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #dee2e6;\n}\n\n.status-filter[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.filter-dropdown[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  position: absolute;\n  background-color: white;\n  border: 1px solid #ddd;\n  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);\n  z-index: 1;\n}\n\n.filter-dropdown[_ngcontent-%COMP%]   label[_ngcontent-%COMP%] {\n  padding: 8px 12px;\n}\n\n.filter-dropdown[_ngcontent-%COMP%]   label[_ngcontent-%COMP%]:hover {\n  background-color: #f1f1f1;\n}\n\n.jobHeader[_ngcontent-%COMP%] {\n  background-color: #e7f2f9;\n}\n\n.icon-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.icon-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  margin-right: 20px;\n}\n\n.icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  margin-right: 8px;\n  cursor: pointer;\n  color: #757575;\n}\n\n.icon-label[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #555;\n}\n\n.icon-item[_ngcontent-%COMP%]:hover   .icon[_ngcontent-%COMP%] {\n  color: #007bff;\n}\n\n.close-modal-icon[_ngcontent-%COMP%] {\n  height: 25px;\n  cursor: pointer;\n  padding-top: 5px;\n}\n\n.icon-item[_ngcontent-%COMP%]:hover   .icon-label[_ngcontent-%COMP%] {\n  color: #007bff;\n}\n\n.badge[_ngcontent-%COMP%] {\n  line-height: 1.5 !important;\n}\n\n.badge-open[_ngcontent-%COMP%] {\n  color: white;\n  font-size: 14px;\n  border-radius: 5px;\n  width: 90%;\n  cursor: pointer;\n  border-radius: 16px;\n  font-weight: bold;\n}\n\n.dialog-overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  background-color: rgba(0, 0, 0, 0.5);\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.dialog[_ngcontent-%COMP%] {\n  background-color: #fff;\n  padding: 20px;\n  border-radius: 8px;\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);\n  width: 300px;\n  text-align: center;\n}\n\n.dialog[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n\n.dialog[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px;\n  margin-bottom: 20px;\n}\n\n.dialog-actions[_ngcontent-%COMP%] {\n  display: flex;\n  float: right;\n}\n\n.dialog-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 4px 20px;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  block-size: 36px;\n}\n\n.close-status[_ngcontent-%COMP%] {\n  cursor: pointer;\n  font-size: 20px;\n}\n\n#notes[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  width: 630px;\n  left: -629px;\n}\n\n.main-div[_ngcontent-%COMP%] {\n  font-family: Arial, sans-serif;\n  display: flex;\n  justify-content: center;\n  align-items: flex-start;\n  padding: 20px;\n}\n\n.progress-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  width: 300px;\n}\n\n.progress-title[_ngcontent-%COMP%] {\n  font-size: 17px;\n  font-weight: bold;\n  margin-bottom: 10px;\n}\n\n.progress-line[_ngcontent-%COMP%] {\n  position: relative;\n  width: 7px;\n  background-color: #ddd;\n  flex-grow: 1;\n  border-radius: 5px;\n  margin-bottom: 27px;\n}\n\n.progress[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  background-color: #ff6600;\n  top: 0;\n}\n\n.step[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  margin-bottom: 23px;\n  position: relative;\n  font-size: 15px;\n}\n\n.step[_ngcontent-%COMP%]   .bullet[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #fff;\n  font-weight: bold;\n  position: absolute;\n  z-index: 1;\n  opacity: 1;\n}\n\n.step[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%] {\n  margin-left: 27px;\n}\n\n.step[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  margin-bottom: 5px;\n}\n\n#history[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  padding: 13px 50px;\n  overflow-y: auto;\n  overflow-x: hidden;\n  height: 376px;\n}\n\n.job-details-btn[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  text-align: left;\n  text-decoration: none;\n}\n\n.status[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n  width: 84%;\n}\n\n.status-edit[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\n.form-control[_ngcontent-%COMP%] {\n  background-color: #F3F4F6;\n}\n\n.close-job[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 10px;\n  right: 10px;\n  background: transparent;\n  border: none;\n  font-size: 20px;\n  cursor: pointer;\n}\n\n.close-icon-container[_ngcontent-%COMP%] {\n  display: inline-flex;\n  align-items: center;\n  justify-content: center;\n  width: 24px;\n  height: 24px;\n  border-radius: 50%;\n  color: #6c757dd9;\n  border: 2px solid;\n  margin-right: 10px;\n  margin-top: 5px;\n  cursor: pointer;\n}\n\n.secondary-skill-ellipsis[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 200px;\n  vertical-align: top;\n}\n\n.notes-progress-line[_ngcontent-%COMP%] {\n  position: relative;\n  width: 11px;\n  background-color: #ddd;\n  flex-grow: 1;\n  border-radius: 5px;\n  margin-bottom: 21px;\n}\n\n.notes-progress[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  background-color: #ff6600;\n  top: 0;\n  height: 100%;\n  border-radius: 7px;\n}\n\n.note[_ngcontent-%COMP%] {\n  margin-left: 20px;\n}\n\n.note-card[_ngcontent-%COMP%] {\n  background: #fff;\n  border-radius: 10px;\n  box-shadow: 0 0px 10px rgba(0, 0, 0, 0.1);\n  margin: 0px -34px 22px 0px;\n  padding: 16px;\n  height: 76px;\n  width: 346px;\n  display: flex;\n  flex-direction: column;\n}\n\n.note-header[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n}\n\n.note-name[_ngcontent-%COMP%] {\n  font-weight: bold;\n}\n\n.note-date[_ngcontent-%COMP%] {\n  color: #777;\n  font-size: 0.9em;\n}\n\n.note-comments[_ngcontent-%COMP%] {\n  color: #333;\n}\n\n.ellipsis[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  display: inline-block;\n  vertical-align: top;\n  max-width: 100%;\n  cursor: pointer;\n}\n\n.tooltip[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  cursor: pointer;\n}\n\n.tooltip[_ngcontent-%COMP%]   .tooltiptext[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 300px;\n  background-color: #555;\n  color: #fff;\n  text-align: center;\n  border-radius: 6px;\n  padding: 5px;\n  position: absolute;\n  z-index: 1;\n  bottom: 125%;\n  left: 50%;\n  margin-left: -150px;\n  opacity: 0;\n  transition: opacity 0.3s;\n}\n\n.tooltip[_ngcontent-%COMP%]:hover   .tooltiptext[_ngcontent-%COMP%] {\n  visibility: visible;\n  opacity: 1;\n}\n\n.save-btn[_ngcontent-%COMP%] {\n  background-color: #09c;\n  color: white;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 5px;\n  margin-top: 14px;\n  margin-right: 35px;\n}\n\n.page-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 37px;\n  height: 37px;\n  border: 1px solid #ddd;\n  border-radius: 5px;\n  cursor: pointer;\n  transition: background-color 0.3s;\n}\n\n.page-item.active[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  color: white;\n  background-color: #09c;\n}\n\n.page-item.disabled[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n}\n\n.disabled[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n  opacity: 0.5;\n  pointer-events: none;\n}\n\n.page-number[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #09c;\n  transition: color 0.3s, -webkit-text-decoration 0.3s;\n  transition: color 0.3s, text-decoration 0.3s;\n  transition: color 0.3s, text-decoration 0.3s, -webkit-text-decoration 0.3s;\n}\n\n.page-number[_ngcontent-%COMP%]:hover {\n  color: #09c;\n  text-decoration: underline;\n}\n\n.page-number.active[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  color: white;\n}\n\n.page-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #09c;\n  transition: color 0.3s;\n}\n\n.page-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%]:hover {\n  color: #09c;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  border-bottom: 1px solid var(--Gray-200, #E4E7EC);\n  background: var(--table-header, #D6DCE3);\n  font-size: 14px;\n  color: var(--clientnewstext);\n  font-weight: 500;\n  border: none;\n}\n\ntable[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  border-bottom: 1px solid var(--Gray-200, #E4E7EC);\n  background: var(--d-9-d-9-d-9, #D1E1F4);\n}\n\n.apply-btn[_ngcontent-%COMP%] {\n  margin-left: 31px;\n  padding-top: 7px;\n  color: white;\n  background-color: #FF6600;\n}\n\n.more-details[_ngcontent-%COMP%] {\n  padding-left: 31px;\n  display: flex;\n  align-items: center;\n  margin-bottom: 0px;\n  margin-top: 2px;\n}\n\n.job-details-title[_ngcontent-%COMP%] {\n  font-size: 16px;\n  letter-spacing: 0px;\n  color: var(--on-background);\n  opacity: 1;\n  font-weight: 600;\n  position: relative;\n}\n\n.job-details-title[_ngcontent-%COMP%]   span[_ngcontent-%COMP%] {\n  font-weight: normal;\n  font-style: italic;\n  font-size: 15px;\n}\n\n#candidateModal[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 400px !important;\n}\n\n#candidateModal[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  height: 430px;\n}\n\n.text-danger[_ngcontent-%COMP%] {\n  color: red !important;\n}\n\n.tooltip-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.tooltip-container[_ngcontent-%COMP%]   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 201px;\n  background-color: #555;\n  color: #fff;\n  text-align: center;\n  border-radius: 6px;\n  padding: 5px 0;\n  position: absolute;\n  z-index: 1;\n  left: 34%;\n  top: 41px;\n  transform: translateX(-50%);\n  opacity: 0;\n  transition: opacity 0.3s;\n}\n\n.tooltip-container[_ngcontent-%COMP%]:hover   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: visible;\n  opacity: 1;\n}\n\n.application-header[_ngcontent-%COMP%] {\n  color: var(--Body-text-color, #231F20);\n  font-family: Poppins;\n  font-size: 18px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 20px;\n}\n\n.sub-header[_ngcontent-%COMP%] {\n  color: var(--Body-text-color, #231F20);\n  font-family: Poppins;\n  font-size: 16px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 18px;\n  \n}\n\n.job-detail-header[_ngcontent-%COMP%] {\n  color: var(--Brand-orange-color, #F26C21);\n  font-family: Poppins;\n  font-size: 18px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 20px;\n  padding-bottom: 5px;\n  border-bottom: 1px solid var(--Brand-orange-color, #F26C21);\n}\n\n.section-border[_ngcontent-%COMP%] {\n  border: 1px solid lightgray;\n  border-radius: 9px;\n  margin-right: 23px;\n  margin-bottom: 6px;\n}\n\n.details-sub-header[_ngcontent-%COMP%] {\n  color: var(--Gray-700, #344054);\n  font-family: Poppins;\n  font-size: 16px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 20px;\n}\n\n.modal-dialog-slideout[_ngcontent-%COMP%] {\n  position: fixed;\n  margin: 0;\n  right: 0;\n  height: 100%;\n  transform: translate3d(100%, 0, 0);\n}\n\n.modal-dialog-slideout[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  height: 100vh;\n  overflow-y: auto;\n}\n\n.modal.show[_ngcontent-%COMP%]   .modal-dialog-slideout[_ngcontent-%COMP%] {\n  transform: translate3d(0, 0, 0);\n}\n\n.modal.fade[_ngcontent-%COMP%]   .modal-dialog[_ngcontent-%COMP%] {\n  transition: transform 0.3s ease-out;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvam9iLWRldGFpbHMvam9iLWRldGFpbHMuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLDRCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQUVGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUFBO0VBQ0UsZUFBQTtBQUdGOztBQUFBO0VBQ0UsZUFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsZ0NBQUE7RUFDQSxlQUFBO0FBR0Y7O0FBQUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQUdGOztBQUFBO0VBQ0UsaUJBQUE7RUFDQSxpQkFBQTtBQUdGOztBQUFBO0VBQ0UsYUFBQTtBQUdGOztBQUFBO0VBQ0U7SUFDRSxpQkFBQTtJQUNBLGlCQUFBO0VBR0Y7O0VBQUE7SUFDRSxhQUFBO0VBR0Y7QUFDRjs7QUFBQTtFQUNFLGNBQUE7RUFFQSxxQkFBQTtBQUNGOztBQUVBO0VBQ0UsMkJBQUE7RUFDQSw2QkFBQTtFQUNBLG1CQUFBO0FBQ0Y7O0FBRUE7RUFDRSxnQ0FBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGdCQUFBO0FBQ0Y7O0FBQ0E7RUFDRSxTQUFBO0VBQ0EsWUFBQTtBQUVGOztBQURFO0VBQ0UsYUFBQTtBQUdKOztBQUFBO0VBQ0UsU0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBR0Y7O0FBREE7RUFDRSxnQkFBQTtFQUNBLG9DQUFBO0VBQ0EsaUNBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBSUY7O0FBQUE7RUFDRSxlQUFBO0FBR0Y7O0FBQUE7RUFFRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FBRUY7O0FBQ0E7RUFDRSwrQ0FBQTtFQUNBLHFDQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUVGOztBQUNBO0VBQ0UseUJBQUE7RUFDQSxZQUFBO0VBQ0EsVUFBQTtBQUVGOztBQUNBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBRUY7O0FBQ0E7RUFDRSxVQUFBO0VBQ0EsMkJBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSwyQkFBQTtBQUVGOztBQUNBO0VBQ0UsUUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtBQUVGOztBQUNBO0VBQ0UsT0FBQTtFQUNBLDJCQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLGdCQUFBO0FBRUY7O0FBQ0E7RUFDRSxxQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSx5QkFBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBRUY7O0FBQ0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFlBQUE7QUFFRjs7QUFFRTtFQUNFLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUFDSjs7QUFFRTtFQUNFLGdCQUFBO0VBQ0Esb0NBQUE7RUFDQSxpQ0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBSjs7QUFLQTtFQUNFLGVBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBR0EsYUFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBSkY7O0FBU0E7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSwrQ0FBQTtFQUNBLFVBQUE7QUFORjs7QUFTQTtFQUNFLGlCQUFBO0FBTkY7O0FBU0E7RUFDRSx5QkFBQTtBQU5GOztBQVNBO0VBQ0UsaURBQUE7RUFDQSx3Q0FBQTtFQUNBLGVBQUE7RUFFQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQVBGOztBQVlBO0VBQ0UsaURBQUE7RUFDQSx1Q0FBQTtBQVRGOztBQVlBO0VBQ0UsZUFBQTtFQUNBLDJCQUFBO0VBQ0EsNEJBQUE7RUFDQSxnQkFBQTtBQVRGOztBQVlBO0VBQ0UsZ0JBQUE7QUFURjs7QUFZQTtFQUNFLGVBQUE7QUFURjs7QUFXQTtFQUNFLGlEQUFBO0VBQ0EsdUNBQUE7QUFSRjs7QUFVQTtFQUNFLGdDQUFBO0FBUEY7O0FBVUE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0FBUEY7O0FBVUE7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0Esc0JBQUE7RUFDQSwrQ0FBQTtFQUNBLFVBQUE7QUFQRjs7QUFVQTtFQUNFLGlCQUFBO0FBUEY7O0FBVUE7RUFDRSx5QkFBQTtBQVBGOztBQVVBO0VBQ0UseUJBQUE7QUFQRjs7QUFXQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQVJGOztBQVdBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QUFSRjs7QUFXQTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FBUkY7O0FBV0E7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQVJGOztBQVdBO0VBQ0UsY0FBQTtBQVJGOztBQVVBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQVBGOztBQVVBO0VBQ0UsY0FBQTtBQVBGOztBQVVBO0VBQ0UsMkJBQUE7QUFQRjs7QUFVQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QUFQRjs7QUFVQTtFQUNFLGVBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0NBQUE7RUFDQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQVBGOztBQVVBO0VBQ0Usc0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSx5Q0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQVBGOztBQVVBO0VBQ0UsbUJBQUE7QUFQRjs7QUFVQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFQRjs7QUFVQTtFQUNFLGFBQUE7RUFDQSxZQUFBO0FBUEY7O0FBVUE7RUFDRSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQVBGOztBQVVBO0VBQ0UsZUFBQTtFQUNBLGVBQUE7QUFQRjs7QUFVQTtFQUNFLFlBQUE7RUFDQSxZQUFBO0FBUEY7O0FBY0E7RUFDRSw4QkFBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHVCQUFBO0VBQ0EsYUFBQTtBQVhGOztBQWNBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxZQUFBO0FBWEY7O0FBY0E7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQVhGOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQVhGOztBQWNBO0VBQ0Usa0JBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxNQUFBO0FBWEY7O0FBY0E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQVhGOztBQWNBO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFFQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7QUFaRjs7QUFlQTtFQUNFLGlCQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtBQVpGOztBQWVBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtBQVpGOztBQWVBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSxxQkFBQTtBQVpGOztBQWVBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtBQVpGOztBQWVBO0VBQ0UsZUFBQTtBQVpGOztBQWVBO0VBQ0UseUJBQUE7QUFaRjs7QUFlQTtFQUNFLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFdBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtBQVpGOztBQWVBO0VBQ0Usb0JBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBWkY7O0FBZUE7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBWkY7O0FBZUE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLE1BQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFaRjs7QUFlQTtFQUNFLGlCQUFBO0FBWkY7O0FBZUE7RUFDRSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUNBQUE7RUFDQSwwQkFBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxzQkFBQTtBQVpGOztBQWVBO0VBQ0UsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7QUFaRjs7QUFnQkE7RUFDRSxpQkFBQTtBQWJGOztBQWlCQTtFQUNFLFdBQUE7RUFDQSxnQkFBQTtBQWRGOztBQWlCQTtFQUNFLFdBQUE7QUFkRjs7QUFpQkE7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGVBQUE7QUFkRjs7QUFpQkE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZUFBQTtBQWRGOztBQWlCQTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLFVBQUE7RUFDQSx3QkFBQTtBQWRGOztBQWlCQTtFQUNFLG1CQUFBO0VBQ0EsVUFBQTtBQWRGOztBQWlCQTtFQUNFLHNCQUFBO0VBQ0EsWUFBQTtBQWRGOztBQXNEQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsUUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFuREY7O0FBc0RBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUNBQUE7QUFuREY7O0FBc0RBO0VBQ0UsMEJBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7QUFuREY7O0FBc0RBO0VBQ0UsbUJBQUE7QUFuREY7O0FBd0RBO0VBQ0UsbUJBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7QUFyREY7O0FBdURBO0VBQ0UsZUFBQTtFQUNBLFdBQUE7RUFDQSxvREFBQTtFQUFBLDRDQUFBO0VBQUEsMEVBQUE7QUFwREY7O0FBdURBO0VBQ0UsV0FBQTtFQUNBLDBCQUFBO0FBcERGOztBQXVEQTtFQUNFLDBCQUFBO0VBQ0EsWUFBQTtBQXBERjs7QUF1REE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLHNCQUFBO0FBcERGOztBQXVEQTtFQUNFLFdBQUE7QUFwREY7O0FBc0RBO0VBQ0UsaURBQUE7RUFDQSx3Q0FBQTtFQUNBLGVBQUE7RUFFQSw0QkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQXBERjs7QUF5REE7RUFDRSxpREFBQTtFQUNBLHVDQUFBO0FBdERGOztBQXdEQTtFQUNFLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0EseUJBQUE7QUFyREY7O0FBd0RBO0VBQ0Usa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7QUFyREY7O0FBdURBO0VBQ0UsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsMkJBQUE7RUFDQSxVQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQXBERjs7QUFzREE7RUFDRSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQW5ERjs7QUFxREE7RUFDRSw0QkFBQTtBQWxERjs7QUFtREU7RUFDRSxhQUFBO0FBakRKOztBQW9EQTtFQUNFLHFCQUFBO0FBakRGOztBQW1EQTtFQUNFLGtCQUFBO0VBQ0EscUJBQUE7QUFoREY7O0FBbURBO0VBQ0Usa0JBQUE7RUFDQSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxTQUFBO0VBQ0EsU0FBQTtFQUNBLDJCQUFBO0VBQ0EsVUFBQTtFQUNBLHdCQUFBO0FBaERGOztBQW1EQTtFQUNFLG1CQUFBO0VBQ0EsVUFBQTtBQWhERjs7QUFrREE7RUFDRSxzQ0FBQTtFQUNGLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQS9DQTs7QUFpREE7RUFDRSxzQ0FBQTtFQUNGLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUFtQixXQUFBO0FBN0NuQjs7QUErQ0E7RUFDRSx5Q0FBQTtFQUNGLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkRBQUE7QUE1Q0E7O0FBOENBO0VBQ0UsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUEzQ0Y7O0FBNkNBO0VBQ0EsK0JBQUE7RUFDQSxvQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUExQ0E7O0FBNkNBO0VBQ0UsZUFBQTtFQUNBLFNBQUE7RUFDQSxRQUFBO0VBQ0EsWUFBQTtFQUNBLGtDQUFBO0FBMUNGOztBQTZDQTtFQUNFLGFBQUE7RUFDQSxnQkFBQTtBQTFDRjs7QUE2Q0E7RUFDRSwrQkFBQTtBQTFDRjs7QUE2Q0E7RUFDRSxtQ0FBQTtBQTFDRiIsImZpbGUiOiJzcmMvYXBwL2pvYi1kZXRhaWxzL2pvYi1kZXRhaWxzLmNvbXBvbmVudC5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJhbm5lci1zZWN0aW9uIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTdmMmY5O1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJTtcclxuICBtaW4taGVpZ2h0OiAxNDVweDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbn1cclxuLmpvYi1kZXRhaWxzLWhlYWRlcntcclxuICBjb2xvcjogcmdiKDMzLCAzNywgNDEpOyBcclxuICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuLmZvbnQtc2l6ZS0xOHAge1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxufVxyXG5cclxuLmZvbnQtc2l6ZS0xNnAge1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxufVxyXG5cclxuLmZvbnQtc2l6ZS0xNHAge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmZvbnQtc2l6ZS0xMnAge1xyXG4gIGZvbnQtc2l6ZTogMTJweDtcclxufVxyXG5cclxuLmZvbnQtc2l6ZS0xMHAge1xyXG4gIGZvbnQtc2l6ZTogMTBweDtcclxufVxyXG5cclxuLmxvYWRlckRpdiB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHRvcDogNjAlO1xyXG4gIGxlZnQ6IDUwJTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgtNTAlLCAtNTAlKTtcclxuICBmb250LXNpemU6IDYwcHg7XHJcbn1cclxuXHJcbi5jZW50ZXJMb2FkZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmNhcmQtaW1nLWhlaWdodCB7XHJcbiAgbWluLWhlaWdodDogMjEwcHg7XHJcbiAgbWF4LWhlaWdodDogMjExcHg7XHJcbn1cclxuXHJcbi5jYW52YXMtaGVpZ2h0IHtcclxuICBoZWlnaHQ6IDIxMHB4O1xyXG59XHJcblxyXG5AbWVkaWEgKG1pbi13aWR0aDogMTkwMHB4KSB7XHJcbiAgLmNhcmQtaW1nLWhlaWdodCB7XHJcbiAgICBtaW4taGVpZ2h0OiAyNDNweDtcclxuICAgIG1heC1oZWlnaHQ6IDI0NXB4O1xyXG4gIH1cclxuXHJcbiAgLmNhbnZhcy1oZWlnaHQge1xyXG4gICAgaGVpZ2h0OiAyNDVweDtcclxuICB9XHJcbn1cclxuXHJcbi5jYXRlZ29yeVRhYnMgYSB7XHJcbiAgY29sb3I6ICNhN2E3YTc7XHJcbiAgO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5cclxuLmNhdGVnb3J5VGFicyBhLmFjdGl2ZSB7XHJcbiAgY29sb3I6IHZhcigtLW9uLWJhY2tncm91bmQpO1xyXG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZjYwO1xyXG4gIHBhZGRpbmctYm90dG9tOiA1cHg7XHJcbn1cclxuXHJcbi52ZXJ0aWNhbC1saW5lIHtcclxuICBib3JkZXItbGVmdDogMnB4IHNvbGlkIGxpZ2h0Z3JleTtcclxuICBoZWlnaHQ6IDIzMHB4O1xyXG4gIG1hcmdpbi1sZWZ0OiAxN3B4O1xyXG4gIG1hcmdpbi10b3A6IDMycHg7XHJcbn1cclxuI2FwcGxpY2F0aW9uIC5tb2RhbC1jb250ZW50IHtcclxuICB0b3A6MHJlbTtcclxuICBsZWZ0OiAtODM0cHg7XHJcbiAgLm1vZGFsLWJvZHl7XHJcbiAgICBwYWRkaW5nOjIzcHg7XHJcbiAgfVxyXG59XHJcbiNoaXN0b3J5IC5tb2RhbC1jb250ZW50e1xyXG4gIHRvcDowcmVtO1xyXG4gIGxlZnQ6IC04MDlweDtcclxuICB3aWR0aDogODEwcHg7XHJcbn1cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAuMik7XHJcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDByZW07XHJcbiAgbGVmdDogLTgzNHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDQyMHB4O1xyXG4gIHdpZHRoOiA4MzVweDtcclxuICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5YmFja2dyb3VuZCk7XHJcbn1cclxuXHJcbi50ZXh0Q29sb3Ige1xyXG4gIGZvbnQtc2l6ZTogMjRweDtcclxufVxyXG5cclxuLm1vZGFsLWJvZHkge1xyXG4gIC8vIHBhZGRpbmc6IDEzcHggNTBweDtcclxuICBwYWRkaW5nOiAxN3B4IDIzcHg7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxuICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgaGVpZ2h0OiA0NjFweDtcclxufVxyXG5cclxuLmFwcGxpY2F0aW9uLWRldGFpbHMge1xyXG4gIGJhY2tncm91bmQ6ICNGQ0ZDRkMgMCUgMCUgbm8tcmVwZWF0IHBhZGRpbmctYm94O1xyXG4gIGJvcmRlcjogMC4yMDAwMDAwMDNweCBzb2xpZCAjODA4MDgwNzM7XHJcbiAgcGFkZGluZy1sZWZ0OiAxMHB4O1xyXG4gIHBhZGRpbmctdG9wOiAxMHB4O1xyXG59XHJcblxyXG4uYnRuLXdhcm5pbmcge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGQjZCMDI7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIHdpZHRoOiAyMyU7XHJcbn1cclxuXHJcbi5maWxlLWlucHV0LWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uY3VzdG9tLWZpbGUtdXBsb2FkIHtcclxuICB3aWR0aDogMzAlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBwYWRkaW5nOiA0cHggMTJweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogbGlnaHRncmF5O1xyXG59XHJcblxyXG4jaW1hZ2VVcGxvYWQge1xyXG4gIHdpZHRoOiAwO1xyXG4gIG9wYWNpdHk6IDA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogLTE7XHJcbn1cclxuXHJcbi5jb250aW51ZS1ib3gge1xyXG4gIGZsZXg6IDE7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZGFkYTE0O1xyXG4gIHBhZGRpbmc6IDRweCAzM3B4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNGM0Y0RjY7XHJcbiAgbWluLWhlaWdodDogMzNweDtcclxufVxyXG5cclxuLnRpY2stYnV0dG9uIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgd2lkdGg6IDgwcHg7XHJcbiAgaGVpZ2h0OiA4MHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNENBRjUwO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxufVxyXG5cclxuLmNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGhlaWdodDogMjN2aDtcclxufVxyXG5cclxuI3dlbGNvbWUge1xyXG4gIC5tb2RhbC1ib2R5IHtcclxuICAgIHBhZGRpbmc6IDEzcHggNTBweDtcclxuICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgICBoZWlnaHQ6IDMyOHB4O1xyXG4gIH1cclxuXHJcbiAgLm1vZGFsLWNvbnRlbnQge1xyXG4gICAgYm9yZGVyLXJhZGl1czogMDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYmEoMCwgMCwgMCwgLjIpO1xyXG4gICAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgdG9wOiA2cmVtO1xyXG4gICAgbGVmdDogLTEwMHB4O1xyXG4gICAgbWluLWhlaWdodDogMzQwcHg7XHJcbiAgICB3aWR0aDogODAwcHg7XHJcbiAgICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5YmFja2dyb3VuZCk7XHJcbiAgfVxyXG59XHJcblxyXG4ubG9hZGVyLWJhY2tncm91bmQge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xyXG4gIC8vIGJhY2tkcm9wLWZpbHRlcjogYmx1cig1cHgpO1xyXG4gIHotaW5kZXg6IDk5OTk7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4ubG9hZGVyRGl2IHt9XHJcblxyXG4uZmlsdGVyLWRyb3Bkb3duIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbiAgYm94LXNoYWRvdzogMHB4IDhweCAxNnB4IDBweCByZ2JhKDAsIDAsIDAsIDAuMik7XHJcbiAgei1pbmRleDogMTtcclxufVxyXG5cclxuLmZpbHRlci1kcm9wZG93biBsYWJlbCB7XHJcbiAgcGFkZGluZzogOHB4IDEycHg7XHJcbn1cclxuXHJcbi5maWx0ZXItZHJvcGRvd24gbGFiZWw6aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmMWYxZjE7XHJcbn1cclxuXHJcbi50YWJsZSB0aGVhZCB0aCB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLUdyYXktMjAwLCAjRTRFN0VDKTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS10YWJsZS1oZWFkZXIsICNENkRDRTMpO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjRTFGM0ZGO1xyXG4gIGNvbG9yOiB2YXIoLS1jbGllbnRuZXdzdGV4dCk7XHJcbiAgZm9udC13ZWlnaHQ6IDUwMDtcclxuICBib3JkZXI6IG5vbmU7XHJcbiAgLy8gcGFkZGluZzogMjhweDtcclxuICAvLyBib3JkZXItcmlnaHQ6IDAuNXB4IHNvbGlkIHZhcigtLXVzZXItdGFibGUpO1xyXG4gIC8vIGJvcmRlci1ib3R0b206IDAuNXB4IHNvbGlkIHZhcigtLXVzZXItdGFibGUpO1xyXG59XHJcbi50YWJsZSB0aGVhZCB0aCA6aG92ZXJ7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLUdyYXktMjAwLCAjRTRFN0VDKTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1kLTktZC05LWQtOSwgI0QxRTFGNCk7XHJcbn1cclxuXHJcbi50aC10aXRsZSB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLXRhYmxlLWJnKTtcclxuICBjb2xvcjogdmFyKC0tY2xpZW50bmV3c3RleHQpO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbn1cclxuXHJcbi50YWJsZSB0Ym9keSB7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxufVxyXG5cclxudGQge1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG50YWJsZSB0cjpob3ZlciB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLUdyYXktMjAwLCAjRTRFN0VDKTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1kLTktZC05LWQtOSwgI0QxRTFGNCk7XHJcbn1cclxuLmxhc3QtaXRlbSB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNkZWUyZTY7IFxyXG59XHJcblxyXG4uc3RhdHVzLWZpbHRlciB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxufVxyXG5cclxuLmZpbHRlci1kcm9wZG93biB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXI6IDFweCBzb2xpZCAjZGRkO1xyXG4gIGJveC1zaGFkb3c6IDBweCA4cHggMTZweCAwcHggcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG4gIHotaW5kZXg6IDE7XHJcbn1cclxuXHJcbi5maWx0ZXItZHJvcGRvd24gbGFiZWwge1xyXG4gIHBhZGRpbmc6IDhweCAxMnB4O1xyXG59XHJcblxyXG4uZmlsdGVyLWRyb3Bkb3duIGxhYmVsOmhvdmVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZjFmMWYxO1xyXG59XHJcblxyXG4uam9iSGVhZGVyIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZTdmMmY5O1xyXG5cclxufVxyXG5cclxuLmljb24tY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5pY29uLWl0ZW0ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbn1cclxuXHJcbi5pY29uIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiA4cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGNvbG9yOiAjNzU3NTc1O1xyXG59XHJcblxyXG4uaWNvbi1sYWJlbCB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG4gIGNvbG9yOiAjNTU1O1xyXG59XHJcblxyXG4uaWNvbi1pdGVtOmhvdmVyIC5pY29uIHtcclxuICBjb2xvcjogIzAwN2JmZjtcclxufVxyXG4uY2xvc2UtbW9kYWwtaWNvbntcclxuICBoZWlnaHQ6IDI1cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIHBhZGRpbmctdG9wOiA1cHg7XHJcbn1cclxuXHJcbi5pY29uLWl0ZW06aG92ZXIgLmljb24tbGFiZWwge1xyXG4gIGNvbG9yOiAjMDA3YmZmO1xyXG59XHJcblxyXG4uYmFkZ2Uge1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjUgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmJhZGdlLW9wZW4ge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIHdpZHRoOiA5MCU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGJvcmRlci1yYWRpdXM6IDE2cHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuXHJcbi5kaWFsb2ctb3ZlcmxheSB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uZGlhbG9nIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIGJveC1zaGFkb3c6IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gIHdpZHRoOiAzMDBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5kaWFsb2cgaDIge1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuXHJcbi5kaWFsb2cgc2VsZWN0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuLmRpYWxvZy1hY3Rpb25zIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsb2F0OiByaWdodDtcclxufVxyXG5cclxuLmRpYWxvZy1hY3Rpb25zIGJ1dHRvbiB7XHJcbiAgcGFkZGluZzogNHB4IDIwcHg7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmxvY2stc2l6ZTogMzZweDtcclxufVxyXG5cclxuLmNsb3NlLXN0YXR1cyB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG5cclxuI25vdGVzIC5tb2RhbC1jb250ZW50IHtcclxuICB3aWR0aDogNjMwcHg7XHJcbiAgbGVmdDogLTYyOXB4O1xyXG59XHJcblxyXG4vLyAjbm90ZXMgLm1vZGFsLWJvZHkge1xyXG4vLyAgIGhlaWdodDogNDEwcHggIWltcG9ydGFudDtcclxuLy8gfVxyXG5cclxuLm1haW4tZGl2IHtcclxuICBmb250LWZhbWlseTogQXJpYWwsIHNhbnMtc2VyaWY7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICBwYWRkaW5nOiAyMHB4O1xyXG59XHJcblxyXG4ucHJvZ3Jlc3MtY29udGFpbmVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgd2lkdGg6IDMwMHB4O1xyXG59XHJcblxyXG4ucHJvZ3Jlc3MtdGl0bGUge1xyXG4gIGZvbnQtc2l6ZTogMTdweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBtYXJnaW4tYm90dG9tOiAxMHB4O1xyXG59XHJcblxyXG4ucHJvZ3Jlc3MtbGluZSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiA3cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2RkZDtcclxuICBmbGV4LWdyb3c6IDE7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDI3cHg7XHJcbn1cclxuXHJcbi5wcm9ncmVzcyB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZjY2MDA7XHJcbiAgdG9wOiAwO1xyXG59XHJcblxyXG4uc3RlcCB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuICBtYXJnaW4tYm90dG9tOiAyM3B4O1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuXHJcbi5zdGVwIC5idWxsZXQge1xyXG4gIHdpZHRoOiAyMHB4O1xyXG4gIGhlaWdodDogMjBweDtcclxuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY2NjAwO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBjb2xvcjogI2ZmZjtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgei1pbmRleDogMTtcclxuICBvcGFjaXR5OiAxO1xyXG59XHJcblxyXG4uc3RlcCAuZGV0YWlscyB7XHJcbiAgbWFyZ2luLWxlZnQ6IDI3cHg7XHJcbn1cclxuXHJcbi5zdGVwIC5kZXRhaWxzIGRpdiB7XHJcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG4jaGlzdG9yeSAubW9kYWwtYm9keSB7XHJcbiAgcGFkZGluZzogMTNweCA1MHB4O1xyXG4gIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gIGhlaWdodDogMzc2cHg7XHJcbn1cclxuXHJcbi5qb2ItZGV0YWlscy1idG4ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxufVxyXG5cclxuLnN0YXR1cyB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGdhcDogNHB4O1xyXG4gIHdpZHRoOiA4NCU7XHJcbn1cclxuXHJcbi5zdGF0dXMtZWRpdCB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcblxyXG4uZm9ybS1jb250cm9sIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjNGNEY2O1xyXG59XHJcblxyXG4uY2xvc2Utam9iIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiAxMHB4O1xyXG4gIHJpZ2h0OiAxMHB4O1xyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICBmb250LXNpemU6IDIwcHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uY2xvc2UtaWNvbi1jb250YWluZXIge1xyXG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDI0cHg7XHJcbiAgaGVpZ2h0OiAyNHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBjb2xvcjogIzZjNzU3ZGQ5O1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkO1xyXG4gIG1hcmdpbi1yaWdodDogMTBweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4uc2Vjb25kYXJ5LXNraWxsLWVsbGlwc2lzIHtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgbWF4LXdpZHRoOiAyMDBweDtcclxuICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG59XHJcblxyXG4ubm90ZXMtcHJvZ3Jlc3MtbGluZSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiAxMXB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNkZGQ7XHJcbiAgZmxleC1ncm93OiAxO1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICBtYXJnaW4tYm90dG9tOiAyMXB4O1xyXG59XHJcblxyXG4ubm90ZXMtcHJvZ3Jlc3Mge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY2NjAwO1xyXG4gIHRvcDogMDtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xyXG59XHJcblxyXG4ubm90ZSB7XHJcbiAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbn1cclxuXHJcbi5ub3RlLWNhcmQge1xyXG4gIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICBib3gtc2hhZG93OiAwIDBweCAxMHB4IHJnYmEoMCwgMCwgMCwgMC4xKTtcclxuICBtYXJnaW46IDBweCAtMzRweCAyMnB4IDBweDtcclxuICBwYWRkaW5nOiAxNnB4O1xyXG4gIGhlaWdodDogNzZweDtcclxuICB3aWR0aDogMzQ2cHg7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG59XHJcblxyXG4ubm90ZS1oZWFkZXIge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgLy8gbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLm5vdGUtbmFtZSB7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgLy8gZm9udC1zaXplOiAxLjJlbTtcclxufVxyXG5cclxuLm5vdGUtZGF0ZSB7XHJcbiAgY29sb3I6ICM3Nzc7XHJcbiAgZm9udC1zaXplOiAwLjllbTtcclxufVxyXG5cclxuLm5vdGUtY29tbWVudHMge1xyXG4gIGNvbG9yOiAjMzMzO1xyXG59XHJcblxyXG4uZWxsaXBzaXMge1xyXG4gIHdoaXRlLXNwYWNlOiBub3dyYXA7XHJcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICB0ZXh0LW92ZXJmbG93OiBlbGxpcHNpcztcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcclxuICBtYXgtd2lkdGg6IDEwMCU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcblxyXG4udG9vbHRpcCB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuXHJcbi50b29sdGlwIC50b29sdGlwdGV4dCB7XHJcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIHdpZHRoOiAzMDBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTU1O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgcGFkZGluZzogNXB4O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB6LWluZGV4OiAxO1xyXG4gIGJvdHRvbTogMTI1JTtcclxuICBsZWZ0OiA1MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IC0xNTBweDtcclxuICBvcGFjaXR5OiAwO1xyXG4gIHRyYW5zaXRpb246IG9wYWNpdHkgMC4zcztcclxufVxyXG5cclxuLnRvb2x0aXA6aG92ZXIgLnRvb2x0aXB0ZXh0IHtcclxuICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gIG9wYWNpdHk6IDE7XHJcbn1cclxuXHJcbi5zYXZlLWJ0biB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA5YztcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi8vIC5wYWdpbmF0aW9uIHtcclxuLy8gICBkaXNwbGF5OiBmbGV4O1xyXG4vLyAgIGxpc3Qtc3R5bGU6IG5vbmU7XHJcbi8vICAgcGFkZGluZzogMDtcclxuLy8gfVxyXG5cclxuLy8gLnBhZ2luYXRpb24gbGkge1xyXG4vLyAgIG1hcmdpbjogMCA1cHg7XHJcbi8vIH1cclxuXHJcbi8vIC5wYWdpbmF0aW9uIGEsIC5wYWdpbmF0aW9uIHNwYW4ge1xyXG4vLyAgIHBhZGRpbmc6IDEwcHggMTVweDtcclxuLy8gICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbi8vICAgY29sb3I6ICMwMDdiZmY7XHJcbi8vICAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuLy8gICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbi8vICAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAwLjNzLCBjb2xvciAwLjNzO1xyXG4vLyB9XHJcblxyXG4vLyAucGFnaW5hdGlvbiBhOmhvdmVyIHtcclxuLy8gICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDA1NmIzO1xyXG4vLyAgIGNvbG9yOiB3aGl0ZTtcclxuLy8gfVxyXG5cclxuLy8gLnBhZ2luYXRpb24gLmFjdGl2ZSB7XHJcbi8vICAgYmFja2dyb3VuZC1jb2xvcjogIzAwN2JmZjtcclxuLy8gICBjb2xvcjogd2hpdGU7XHJcbi8vICAgYm9yZGVyLWNvbG9yOiAjMDA3YmZmO1xyXG4vLyB9XHJcblxyXG4vLyAucGFnaW5hdGlvbiAucHJldiwgLnBhZ2luYXRpb24gLm5leHQge1xyXG4vLyAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuLy8gICBtYXJnaW4tbGVmdDogYXV0bztcclxuLy8gfVxyXG5cclxuXHJcblxyXG4ucGFnaW5hdGlvbiB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGdhcDogNXB4O1xyXG4gIG1hcmdpbi10b3A6IDE0cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAzNXB4O1xyXG59XHJcblxyXG4ucGFnZS1pdGVtIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDM3cHg7XHJcbiAgaGVpZ2h0OiAzN3B4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDAuM3M7XHJcbn1cclxuXHJcbi5wYWdlLWl0ZW0uYWN0aXZlIHtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA5YztcclxufVxyXG5cclxuLnBhZ2UtaXRlbS5kaXNhYmxlZCB7XHJcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICAvLyBvcGFjaXR5OiAwLjU7XHJcbiAgLy8gcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuXHJcbi5kaXNhYmxlZCB7XHJcbiAgY3Vyc29yOiBub3QtYWxsb3dlZDtcclxuICBvcGFjaXR5OiAwLjU7XHJcbiAgcG9pbnRlci1ldmVudHM6IG5vbmU7XHJcbn1cclxuLnBhZ2UtbnVtYmVyIHtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgY29sb3I6ICMwOWM7XHJcbiAgdHJhbnNpdGlvbjogY29sb3IgMC4zcywgdGV4dC1kZWNvcmF0aW9uIDAuM3M7XHJcbn1cclxuXHJcbi5wYWdlLW51bWJlcjpob3ZlciB7XHJcbiAgY29sb3I6ICMwOWM7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7XHJcbn1cclxuXHJcbi5wYWdlLW51bWJlci5hY3RpdmUge1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxufVxyXG5cclxuLnBhZ2UtaXRlbSBpIHtcclxuICBmb250LXNpemU6IDI0cHg7XHJcbiAgY29sb3I6ICMwOWM7XHJcbiAgdHJhbnNpdGlvbjogY29sb3IgMC4zcztcclxufVxyXG5cclxuLnBhZ2UtaXRlbSBpOmhvdmVyIHtcclxuICBjb2xvcjogIzA5YztcclxufVxyXG4udGFibGUgdGhlYWQgdGgge1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1HcmF5LTIwMCwgI0U0RTdFQyk7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0tdGFibGUtaGVhZGVyLCAjRDZEQ0UzKTtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI0UxRjNGRjtcclxuICBjb2xvcjogdmFyKC0tY2xpZW50bmV3c3RleHQpO1xyXG4gIGZvbnQtd2VpZ2h0OiA1MDA7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIC8vIHBhZGRpbmc6IDI4cHg7XHJcbiAgLy8gYm9yZGVyLXJpZ2h0OiAwLjVweCBzb2xpZCB2YXIoLS11c2VyLXRhYmxlKTtcclxuICAvLyBib3JkZXItYm90dG9tOiAwLjVweCBzb2xpZCB2YXIoLS11c2VyLXRhYmxlKTtcclxufVxyXG50YWJsZSB0cjpob3ZlciB7XHJcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIHZhcigtLUdyYXktMjAwLCAjRTRFN0VDKTtcclxuICBiYWNrZ3JvdW5kOiB2YXIoLS1kLTktZC05LWQtOSwgI0QxRTFGNCk7XHJcbn1cclxuLmFwcGx5LWJ0biB7XHJcbiAgbWFyZ2luLWxlZnQ6IDMxcHg7XHJcbiAgcGFkZGluZy10b3A6IDdweDtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI0ZGNjYwMDtcclxufVxyXG5cclxuLm1vcmUtZGV0YWlscyB7XHJcbiAgcGFkZGluZy1sZWZ0OiAzMXB4O1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBtYXJnaW4tYm90dG9tOiAwcHg7XHJcbiAgbWFyZ2luLXRvcDogMnB4O1xyXG59XHJcbi5qb2ItZGV0YWlscy10aXRsZXtcclxuICBmb250LXNpemU6IDE2cHg7IFxyXG4gIGxldHRlci1zcGFjaW5nOiAwcHg7XHJcbiAgY29sb3I6IHZhcigtLW9uLWJhY2tncm91bmQpOyBcclxuICBvcGFjaXR5OiAxOyBcclxuICBmb250LXdlaWdodDogNjAwOyBcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuLmpvYi1kZXRhaWxzLXRpdGxlIHNwYW4ge1xyXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgZm9udC1zdHlsZTogaXRhbGljO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG4jY2FuZGlkYXRlTW9kYWwgLm1vZGFsLWNvbnRlbnR7XHJcbiAgbWluLWhlaWdodDogNDAwcHggIWltcG9ydGFudDtcclxuICAubW9kYWwtYm9keXtcclxuICAgIGhlaWdodDogNDMwcHg7XHJcbiAgfVxyXG59XHJcbi50ZXh0LWRhbmdlcntcclxuICBjb2xvcjogcmVkICFpbXBvcnRhbnQ7XHJcbn1cclxuLnRvb2x0aXAtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4udG9vbHRpcC1jb250YWluZXIgLnRvb2x0aXAtdGV4dCB7XHJcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIHdpZHRoOiAyMDFweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTU1O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgcGFkZGluZzogNXB4IDA7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgbGVmdDogMzQlO1xyXG4gIHRvcDogNDFweDtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoLTUwJSk7XHJcbiAgb3BhY2l0eTogMDtcclxuICB0cmFuc2l0aW9uOiBvcGFjaXR5IDAuM3M7XHJcbn1cclxuXHJcbi50b29sdGlwLWNvbnRhaW5lcjpob3ZlciAudG9vbHRpcC10ZXh0IHtcclxuICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xyXG4gIG9wYWNpdHk6IDE7XHJcbn1cclxuLmFwcGxpY2F0aW9uLWhlYWRlcntcclxuICBjb2xvcjogdmFyKC0tQm9keS10ZXh0LWNvbG9yLCAjMjMxRjIwKTtcclxuZm9udC1mYW1pbHk6IFBvcHBpbnM7XHJcbmZvbnQtc2l6ZTogMThweDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogNjAwO1xyXG5saW5lLWhlaWdodDogMjBweDtcclxufVxyXG4uc3ViLWhlYWRlcntcclxuICBjb2xvcjogdmFyKC0tQm9keS10ZXh0LWNvbG9yLCAjMjMxRjIwKTtcclxuZm9udC1mYW1pbHk6IFBvcHBpbnM7XHJcbmZvbnQtc2l6ZTogMTZweDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogNDAwO1xyXG5saW5lLWhlaWdodDogMThweDsgLyogMTEyLjUlICovXHJcbn1cclxuLmpvYi1kZXRhaWwtaGVhZGVye1xyXG4gIGNvbG9yOiB2YXIoLS1CcmFuZC1vcmFuZ2UtY29sb3IsICNGMjZDMjEpO1xyXG5mb250LWZhbWlseTogUG9wcGlucztcclxuZm9udC1zaXplOiAxOHB4O1xyXG5mb250LXN0eWxlOiBub3JtYWw7XHJcbmZvbnQtd2VpZ2h0OiA2MDA7XHJcbmxpbmUtaGVpZ2h0OiAyMHB4O1xyXG5wYWRkaW5nLWJvdHRvbTogNXB4O1xyXG5ib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tQnJhbmQtb3JhbmdlLWNvbG9yLCAjRjI2QzIxKTtcclxufVxyXG4uc2VjdGlvbi1ib3JkZXIge1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICBib3JkZXItcmFkaXVzOiA5cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyM3B4O1xyXG4gIG1hcmdpbi1ib3R0b206NnB4XHJcbn1cclxuLmRldGFpbHMtc3ViLWhlYWRlcntcclxuY29sb3I6IHZhcigtLUdyYXktNzAwLCAjMzQ0MDU0KTtcclxuZm9udC1mYW1pbHk6IFBvcHBpbnM7XHJcbmZvbnQtc2l6ZTogMTZweDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogNjAwO1xyXG5saW5lLWhlaWdodDogMjBweDtcclxufVxyXG5cclxuLm1vZGFsLWRpYWxvZy1zbGlkZW91dCB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIG1hcmdpbjogMDtcclxuICByaWdodDogMDtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgxMDAlLCAwLCAwKTtcclxufVxyXG5cclxuLm1vZGFsLWRpYWxvZy1zbGlkZW91dCAubW9kYWwtY29udGVudCB7XHJcbiAgaGVpZ2h0OiAxMDB2aDtcclxuICBvdmVyZmxvdy15OiBhdXRvO1xyXG59XHJcblxyXG4ubW9kYWwuc2hvdyAubW9kYWwtZGlhbG9nLXNsaWRlb3V0IHtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZTNkKDAsIDAsIDApO1xyXG59XHJcblxyXG4ubW9kYWwuZmFkZSAubW9kYWwtZGlhbG9nIHtcclxuICB0cmFuc2l0aW9uOiB0cmFuc2Zvcm0gMC4zcyBlYXNlLW91dDtcclxufSJdfQ== */"];
      /***/
    },

    /***/
    "lxz4":
    /*!**********************************************!*\
      !*** ./src/app/providers/utility.service.ts ***!
      \**********************************************/

    /*! exports provided: UtilityService */

    /***/
    function lxz4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
        return UtilityService;
      });
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! sweetalert2 */
      "PSD3");
      /* harmony import */


      var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");

      var UtilityService = /*#__PURE__*/function () {
        function UtilityService() {
          _classCallCheck(this, UtilityService);
        }

        _createClass(UtilityService, [{
          key: "handleError",
          value: function handleError(err) {
            if (err.response.data) this.notify("error", err.response.data);else console.log(err);
          }
        }, {
          key: "getStatusName",
          value: function getStatusName(statusList, widgetStatusId) {
            return statusList.find(function (s) {
              return s.widgetStatusId.toUpperCase() === widgetStatusId.toUpperCase();
            })["status"];
          }
        }, {
          key: "getWidgetName",
          value: function getWidgetName(widgets, widgetId) {
            return widgets.find(function (w) {
              return w.widgetId.toUpperCase() === widgetId.toUpperCase();
            })["widgetName"];
          }
        }, {
          key: "getZoneName",
          value: function getZoneName(zones, zoneId) {
            return zones.find(function (z) {
              return z.widgetZoneId.toUpperCase() === zoneId.toUpperCase();
            })["zoneName"];
          }
        }, {
          key: "getPageName",
          value: function getPageName(pages, pageId) {
            return pages.find(function (p) {
              return p.pageId.toUpperCase() === pageId.toUpperCase();
            })["name"];
          }
        }, {
          key: "notify",
          value: function notify(type, title) {
            var config = {
              icon: type,
              title: title,
              toast: true,
              timer: 3000
            };
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default.a.fire(config);
          }
        }, {
          key: "confirm",
          value: function confirm() {
            return sweetalert2__WEBPACK_IMPORTED_MODULE_0___default.a.fire({
              title: 'Are you sure?',
              text: "You won't be able to revert this!",
              icon: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!'
            });
          }
        }, {
          key: "isRoleExists",
          value: function isRoleExists(role) {
            var _a;

            return (_a = this.roles) === null || _a === void 0 ? void 0 : _a.includes(role.toLowerCase());
          }
        }, {
          key: "isPermitted",
          value: function isPermitted(type) {
            var _a;

            return (_a = this.permissions) === null || _a === void 0 ? void 0 : _a.includes(type.toLowerCase());
          }
        }, {
          key: "tContentConfig",
          value: function tContentConfig() {
            var content = document.querySelector('.content-area');
            if (content) return {
              scrollHeight: content.scrollHeight,
              clientHeight: content.offsetHeight
            };
          }
        }, {
          key: "setCategory",
          value: function setCategory(category) {
            localStorage.setItem('category', category);
          }
        }, {
          key: "getCategory",
          value: function getCategory() {}
        }]);

        return UtilityService;
      }();

      UtilityService.ɵprov = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵɵdefineInjectable"]({
        factory: function UtilityService_Factory() {
          return new UtilityService();
        },
        token: UtilityService,
        providedIn: "root"
      });
      /***/
    },

    /***/
    "sPRM":
    /*!****************************************************************!*\
      !*** ./src/app/job-details/job-details.component.ngfactory.js ***!
      \****************************************************************/

    /*! exports provided: RenderType_JobDetailsComponent, View_JobDetailsComponent_0, View_JobDetailsComponent_Host_0, JobDetailsComponentNgFactory */

    /***/
    function sPRM(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RenderType_JobDetailsComponent", function () {
        return RenderType_JobDetailsComponent;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_JobDetailsComponent_0", function () {
        return View_JobDetailsComponent_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_JobDetailsComponent_Host_0", function () {
        return View_JobDetailsComponent_Host_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "JobDetailsComponentNgFactory", function () {
        return JobDetailsComponentNgFactory;
      });
      /* harmony import */


      var _job_details_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./job-details.component.scss.shim.ngstyle */
      "kyDx");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "s7LF");
      /* harmony import */


      var _job_details_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./job-details.component */
      "HJCg");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _providers_utility_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ../providers/utility.service */
      "lxz4");
      /* harmony import */


      var _providers_jump_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ../providers/jump.service */
      "B8j8");
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles_JobDetailsComponent = [_job_details_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];

      var RenderType_JobDetailsComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({
        encapsulation: 0,
        styles: styles_JobDetailsComponent,
        data: {}
      });

      function View_JobDetailsComponent_1(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_4(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "ul", [["class", "innerhtml"], ["style", "color: var(--on-primary);height: 14px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "li", [["class", "text-justify"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](2, null, ["", ""]))], null, function (_ck, _v) {
          var currVal_0 = _v.context.$implicit;

          _ck(_v, 2, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_3(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 5, "div", [["class", "col-12 mt-3 job-details-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skills: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 2, "div", [["class", "mt-2"], ["style", "position: relative;margin-left: -22px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_4)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](5, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.primarySkillsArray;

          _ck(_v, 5, 0, currVal_0);
        }, null);
      }

      function View_JobDetailsComponent_5(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "col-6 mt-2 mb-2 job-details-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" First Level Panel: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, [" ", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.firstLevelTechPanel;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_6(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "col-6 mt-2 mb-2 job-details-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Second Level Panel: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, [" ", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.secondLevelTechPanel;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_7(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "row m-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "textarea", [["class", "form-control input-div mb-2 font-size-16p"], ["cols", "30"], ["readonly", ""], ["rows", "10"], ["style", "background-color: #f4f8fb;"]], [[8, "value", 0]], null, null, null, null))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob.jobDescription;

          _ck(_v, 2, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_9(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 26, "tr", [], [[2, "last-item", null]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "td", [["class", "display-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "a", [["data-target", "#candidateModal"], ["data-toggle", "modal"], ["href", "javascript:void(0)"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.openEmpData(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](3, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "td", [["class", "secondary-skill-ellipsis"], ["style", "width: 26%;"]], [[8, "title", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 1, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](7, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "td", [["style", "padding-left: 17px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](9, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 1, "td", [["style", "padding-left: 17px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](11, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 6, "td", [["style", "width:198px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 5, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 4, "span", [["class", "badge badge-open status"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](15, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgStyle"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          ngStyle: [0, "ngStyle"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](16, {
          "background-color": 0,
          "color": 1
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](17, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 0, "i", [["class", "bx bx-edit status-edit"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.openStatusDialog(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 7, "td", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 6, "div", [["class", "icon-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 1, "div", [["class", "icon-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.downloadDocument(_v.context.$implicit.email) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 0, "img", [["class", "icon"], ["data-placement", "bottom"], ["data-toggle", "tooltip"], ["height", "20px"], ["src", "../../assets/images/profile-download.svg"], ["title", "Download Profile"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 1, "div", [["class", "icon-item tooltip-container"], ["data-target", "#notes"], ["data-toggle", "modal"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.openNotes(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 0, "img", [["class", "icon"], ["data-placement", "bottom"], ["data-toggle", "tooltip"], ["height", "20px"], ["src", "../../assets/images/notes.svg"], ["title", "Notes"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 1, "div", [["class", "icon-item tooltip-container"], ["data-target", "#history"], ["data-toggle", "modal"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.getNotesHistory(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 0, "img", [["class", "icon"], ["data-placement", "bottom"], ["data-toggle", "tooltip"], ["height", "20px"], ["src", "../../assets/images/history_icon.svg"], ["title", "History"]], null, null, null, null, null))], function (_ck, _v) {
          var currVal_7 = _ck(_v, 16, 0, _v.context.$implicit.color, _v.context.$implicit.textColor);

          _ck(_v, 15, 0, currVal_7);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.index == _co.visibleItems.length - 1;

          _ck(_v, 0, 0, currVal_0);

          var currVal_1 = _v.context.$implicit.empName;

          _ck(_v, 3, 0, currVal_1);

          var currVal_2 = _v.context.$implicit.primarySkills;

          _ck(_v, 4, 0, currVal_2);

          var currVal_3 = _v.context.$implicit.primarySkills;

          _ck(_v, 5, 0, currVal_3);

          var currVal_4 = _v.context.$implicit == null ? null : _v.context.$implicit.location;

          _ck(_v, 7, 0, currVal_4);

          var currVal_5 = _v.context.$implicit.totalExperience;

          _ck(_v, 9, 0, currVal_5);

          var currVal_6 = _v.context.$implicit == null ? null : _v.context.$implicit.trianzExperience;

          _ck(_v, 11, 0, currVal_6);

          var currVal_8 = _v.context.$implicit.statusName;

          _ck(_v, 17, 0, currVal_8);
        });
      }

      function View_JobDetailsComponent_10(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "tr", [["class", "m-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "p", [["class", "m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["No Records found"]))], null, null);
      }

      function View_JobDetailsComponent_11(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["class", "page-item"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.setPage(_v.context.$implicit) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](2, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 3, "span", [["class", "page-number"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](5, {
          "active": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](6, null, ["", ""]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = "page-item";

          var currVal_1 = _ck(_v, 2, 0, _co.currentPage === _v.context.$implicit);

          _ck(_v, 1, 0, currVal_0, currVal_1);

          var currVal_2 = "page-number";

          var currVal_3 = _ck(_v, 5, 0, _co.currentPage === _v.context.$implicit);

          _ck(_v, 4, 0, currVal_2, currVal_3);
        }, function (_ck, _v) {
          var currVal_4 = _v.context.$implicit;

          _ck(_v, 6, 0, currVal_4);
        });
      }

      function View_JobDetailsComponent_13(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, "option", [], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 147456, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgSelectOption"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"]]], {
          value: [0, "value"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 147456, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_x"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], [8, null]], {
          value: [0, "value"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](3, null, ["", ""]))], function (_ck, _v) {
          var currVal_0 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_id;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_id;

          _ck(_v, 2, 0, currVal_1);
        }, function (_ck, _v) {
          var currVal_2 = _v.context.$implicit == null ? null : _v.context.$implicit.application_status_name;

          _ck(_v, 3, 0, currVal_2);
        });
      }

      function View_JobDetailsComponent_12(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 18, "div", [["class", "dialog-overlay"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 17, "div", [["class", "dialog"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 3, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "h5", [["class", "text-left"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Change Status"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 0, "i", [["class", "bx bx-x close-status"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.cancel() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 7, "select", [["class", "mt-3"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "change"], [null, "blur"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("change" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).onChange($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 7).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_2 = (_co.selectedStatus = $event) !== false;
            ad = pd_2 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](7, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["SelectControlValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](9, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](11, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_13)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](13, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 4, "div", [["class", "dialog-actions mb-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "button", [["class", "mr-3"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.cancel() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Cancel"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "button", [["class", "btn"], ["style", "color:white;background: var(--CloudPrimary-Blue, #1A6AC9);"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.changeStatus() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Save"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_7 = _co.selectedStatus;

          _ck(_v, 9, 0, currVal_7);

          var currVal_8 = _co.statusOptions;

          _ck(_v, 13, 0, currVal_8);
        }, function (_ck, _v) {
          var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassUntouched;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassTouched;

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassPristine;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassDirty;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassValid;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassInvalid;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 11).ngClassPending;

          _ck(_v, 6, 0, currVal_0, currVal_1, currVal_2, currVal_3, currVal_4, currVal_5, currVal_6);
        });
      }

      function View_JobDetailsComponent_8(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 39, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 36, "div", [["class", "section-border m-2 mb-3 mt-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "h5", [["class", "ml-2 job-detail-header mt-2"], ["style", "border-bottom: none;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applications"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 33, "div", [["class", "mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 21, "table", [["class", "table m-0"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 15, "thead", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 14, "tr", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Total Exp"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](16, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Exp"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Status "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 1, "th", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Profile"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 4, "tbody", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_9)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](24, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_10)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](26, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 10, "div", [["class", "pagination mb-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 3, "div", [["class", "page-item"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](29, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](30, {
          "disabled": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 0, "i", [["class", "bx bx-chevron-left"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.prevPage() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_11)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](33, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](34, 0, null, null, 3, "div", [["class", "page-item"]], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](35, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgClass"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["KeyValueDiffers"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"]], {
          klass: [0, "klass"],
          ngClass: [1, "ngClass"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵpod"](36, {
          "disabled": 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](37, 0, null, null, 0, "i", [["class", "bx bx-chevron-right"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.nextPage() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_12)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](39, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](0, null, null, 0))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.visibleItems;

          _ck(_v, 24, 0, currVal_0);

          var currVal_1 = !(_co.visibleItems == null ? null : _co.visibleItems.length);

          _ck(_v, 26, 0, currVal_1);

          var currVal_2 = "page-item";

          var currVal_3 = _ck(_v, 30, 0, _co.currentPage === 1);

          _ck(_v, 29, 0, currVal_2, currVal_3);

          var currVal_4 = _co.pages;

          _ck(_v, 33, 0, currVal_4);

          var currVal_5 = "page-item";

          var currVal_6 = _ck(_v, 36, 0, _co.currentPage === _co.totalPages || _co.totalPages == 0);

          _ck(_v, 35, 0, currVal_5, currVal_6);

          var currVal_7 = _co.isDialogOpen;

          _ck(_v, 39, 0, currVal_7);
        }, null);
      }

      function View_JobDetailsComponent_2(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 37, "div", [["class", ""]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 29, "div", [["class", "section-border m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "p", [["class", "job-detail-header m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Details"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 26, "div", [["class", "row ml-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 4, "div", [["class", " col-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 3, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](9, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](10, 0, null, null, 4, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 3, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Assignment Start Date: "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](14, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 4, "div", [["class", "col-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](16, 0, null, null, 3, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](18, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](19, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](20, 0, null, null, 4, "div", [["class", "col-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](21, 0, null, null, 3, "div", [["class", "mt-2 details-sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Grade : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](24, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_3)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](26, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_5)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](28, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_6)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](30, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 4, "div", [["class", "mt-3 section-border m-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](32, 0, null, null, 1, "p", [["class", "job-detail-header m-2"], ["style", "padding-bottom:7px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Job Description"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_7)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](35, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_8)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](37, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_4 = _co.selectedJob == null ? null : _co.selectedJob.primarySkillsArray == null ? null : _co.selectedJob.primarySkillsArray.length;

          _ck(_v, 26, 0, currVal_4);

          var currVal_5 = _co.selectedJob == null ? null : _co.selectedJob.secondLevelTechPanel;

          _ck(_v, 28, 0, currVal_5);

          var currVal_6 = _co.selectedJob == null ? null : _co.selectedJob.secondLevelTechPanel;

          _ck(_v, 30, 0, currVal_6);

          var currVal_7 = (_co.selectedJob == null ? null : _co.selectedJob.jobDescription) || (_co.selectedJob == null ? null : _co.selectedJob.jobDescription) != null;

          _ck(_v, 35, 0, currVal_7);

          var currVal_8 = _co.selectedCategory == "dashboard";

          _ck(_v, 37, 0, currVal_8);
        }, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.selectedJob == null ? null : _co.selectedJob.location;

          _ck(_v, 9, 0, currVal_0);

          var currVal_1 = _co.selectedJob == null ? null : _co.selectedJob.assignmentStartDate;

          _ck(_v, 14, 0, currVal_1);

          var currVal_2 = _co.selectedJob == null ? null : _co.selectedJob.experience;

          _ck(_v, 19, 0, currVal_2);

          var currVal_3 = _co.selectedJob == null ? null : _co.selectedJob.grade;

          _ck(_v, 24, 0, currVal_3);
        });
      }

      function View_JobDetailsComponent_14(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_17(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Employee name is required. "]))], null, null);
      }

      function View_JobDetailsComponent_16(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_17)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["fname"].errors == null ? null : _co.frmEditProfile.controls["fname"].errors.required;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobDetailsComponent_18(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobDetailsComponent_19(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Employee Name cannot exceed 99 characters. "]))], null, null);
      }

      function View_JobDetailsComponent_21(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Phone number is required. "]))], null, null);
      }

      function View_JobDetailsComponent_22(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Phone number is not valid. "]))], null, null);
      }

      function View_JobDetailsComponent_20(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_21)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_22)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["phoneNumber"].errors == null ? null : _co.frmEditProfile.controls["phoneNumber"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["phoneNumber"].errors.pattern || _co.frmEditProfile.controls["phoneNumber"].errors.maxlength;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobDetailsComponent_24(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Email is required. "]))], null, null);
      }

      function View_JobDetailsComponent_25(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Provide valid email. "]))], null, null);
      }

      function View_JobDetailsComponent_23(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_24)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_25)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["email"].errors == null ? null : _co.frmEditProfile.controls["email"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["email"].errors == null ? null : _co.frmEditProfile.controls["email"].errors.pattern;

          _ck(_v, 4, 0, currVal_1);
        }, null);
      }

      function View_JobDetailsComponent_27(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Total experience is required. "]))], null, null);
      }

      function View_JobDetailsComponent_26(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_27)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["experience"].errors == null ? null : _co.frmEditProfile.controls["experience"].errors.required;

          _ck(_v, 2, 0, currVal_0);
        }, null);
      }

      function View_JobDetailsComponent_28(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Experience cannot be more than 99 years. "]))], null, null);
      }

      function View_JobDetailsComponent_30(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience is required. "]))], null, null);
      }

      function View_JobDetailsComponent_31(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience cannot be more than 99 years. "]))], null, null);
      }

      function View_JobDetailsComponent_32(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Trianz experience should be less than or equal to Total experience. "]))], null, null);
      }

      function View_JobDetailsComponent_29(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 6, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_30)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_31)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_32)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](6, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.required;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.max;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.frmEditProfile.controls["trianzExperience"].errors == null ? null : _co.frmEditProfile.controls["trianzExperience"].errors.experienceMismatch;

          _ck(_v, 6, 0, currVal_2);
        }, null);
      }

      function View_JobDetailsComponent_33(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Location is required. "]))], null, null);
      }

      function View_JobDetailsComponent_34(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Location cannot exceed 99 characters. "]))], null, null);
      }

      function View_JobDetailsComponent_35(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary Skill is required. "]))], null, null);
      }

      function View_JobDetailsComponent_36(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobDetailsComponent_37(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Primary skill cannot exceed 500 characters. "]))], null, null);
      }

      function View_JobDetailsComponent_38(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Only ASCII characters are allowed. "]))], null, null);
      }

      function View_JobDetailsComponent_39(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Secondary skill cannot exceed 500 characters. "]))], null, null);
      }

      function View_JobDetailsComponent_40(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "a", [["href", "javascript:void(0)"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.downloadDocument("") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.fileName;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_41(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "mt-1 text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](1, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.warningMessage;

          _ck(_v, 1, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_15(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 150, "form", [["class", "formClass"], ["novalidate", ""]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "submit"], [null, "reset"]], function (_v, en, $event) {
          var ad = true;

          if ("submit" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).onSubmit($event) !== false;
            ad = pd_0 && ad;
          }

          if ("reset" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 2).onReset() !== false;
            ad = pd_1 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_y"], [], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 540672, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"], [[8, null], [8, null]], {
          form: [0, "form"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormGroupDirective"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatusGroup"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 140, "div", [["class", "row mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 16, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Employee Name"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](11, 0, null, null, 5, "input", [["class", "form-control"], ["formControlName", "fname"], ["id", "txtFirstname"], ["placeholder", "*Employee name"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 12)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 12).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 12)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 12)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](12, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](14, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](16, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_16)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](18, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_18)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](20, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_19)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](22, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 15, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Phone Number"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 8, "input", [["class", "form-control"], ["formControlName", "phoneNumber"], ["id", "phoneNumber"], ["maxlength", "10"], ["min", "0"], ["placeholder", "*PhoneNumber"], ["type", "number"]], [[1, "maxlength", 0], [2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 29)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 29).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 29)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 29)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 30).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 30).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 30).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](29, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](30, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](31, 540672, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["MaxLengthValidator"], [], {
          maxlength: [0, "maxlength"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALIDATORS"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["MaxLengthValidator"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](34, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALIDATORS"]], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](36, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_20)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](38, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 12, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Email ID"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](42, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 5, "input", [["aria-describedby", "emailHelp"], ["class", "form-control"], ["formControlName", "email"], ["id", "exampleInputEmail1"], ["placeholder", "*Email Address"], ["readonly", ""], ["type", "email"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 45)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 45).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 45)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 45)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](45, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](47, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](49, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_23)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](51, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](52, 0, null, null, 15, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](53, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Experience"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](55, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](57, 0, null, null, 6, "input", [["class", "form-control"], ["formControlName", "experience"], ["id", "experience"], ["min", "1"], ["placeholder", "*Experience"], ["type", "number"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 58)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 58).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 58)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 58)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 59).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 59).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 59).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](58, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](59, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](61, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](63, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_26)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](65, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_28)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](67, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](68, 0, null, null, 13, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](69, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Experience"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](71, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](73, 0, null, null, 6, "input", [["class", "form-control"], ["formControlName", "trianzExperience"], ["id", "experience"], ["min", "0"], ["placeholder", "*Trianz Experience"], ["type", "number"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"], [null, "change"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 74)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 74).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 74)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 74)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("change" === en) {
            var pd_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 75).onChange($event.target.value) !== false;
            ad = pd_4 && ad;
          }

          if ("input" === en) {
            var pd_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 75).onChange($event.target.value) !== false;
            ad = pd_5 && ad;
          }

          if ("blur" === en) {
            var pd_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 75).onTouched() !== false;
            ad = pd_6 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](74, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](75, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0, p1_0) {
          return [p0_0, p1_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NumberValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](77, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](79, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_29)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](81, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](82, 0, null, null, 14, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](83, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](85, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](87, 0, null, null, 5, "input", [["class", "form-control"], ["formControlName", "location"], ["id", "location"], ["placeholder", "*Location"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 88)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 88).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 88)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 88)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](88, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](90, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](92, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_33)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](94, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_34)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](96, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](97, 0, null, null, 16, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](98, 0, null, null, 3, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](100, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](102, 0, null, null, 5, "input", [["class", "form-control"], ["formControlName", "primaryskill"], ["id", "primary"], ["placeholder", "*Primary Skill"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 103)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 103).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 103)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 103)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](103, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](105, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](107, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_35)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](109, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_36)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](111, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_37)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](113, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](114, 0, null, null, 12, "div", [["class", "form-group col-4 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](115, 0, null, null, 1, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skill"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](117, 0, null, null, 5, "input", [["class", "form-control"], ["formControlName", "secondaryskill"], ["id", "secondary"], ["placeholder", "Secondary Skill"], ["type", "text"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 118)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 118).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 118)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 118)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](118, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](120, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"], [[3, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ControlContainer"]], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ɵangular_packages_forms_forms_p"]]], {
          name: [0, "name"]
        }, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControlName"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](122, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_38)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](124, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_39)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](126, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](127, 0, null, null, 0, "div", [["class", "col-4"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](128, 0, null, null, 17, "div", [["class", "form-group col-12 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](129, 0, null, null, 1, "label", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*Attach the resume .pptx format"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](131, 0, null, null, 2, "a", [["class", "btn-download float-right"], ["download", ""], ["href", "../../assets/images/Sample Profile.pptx"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](132, 0, null, null, 0, "i", [["class", "bx bx-download"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Download Sample Resume "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](134, 0, null, null, 7, "div", [["class", "file-input-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](135, 0, [[1, 0], ["fileInput", 1]], null, 0, "input", [["accept", ".ppt,.pptx"], ["id", "imageUpload"], ["style", "display: none;"], ["type", "file"]], null, [[null, "change"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("change" === en) {
            var pd_0 = _co.uploadFile($event) !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](136, 0, null, null, 1, "label", [["class", "custom-file-upload"], ["for", "imageUpload"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, [" Choose File "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](138, 0, null, null, 3, "label", [["class", "continue-box"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](139, 0, null, null, 2, "span", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_40)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](141, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_41)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](143, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](144, 0, null, null, 1, "div", [["style", "font-size: 14px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["*Review the JD carefully and submit profiles that match at least 50%."])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](146, 0, null, null, 4, "div", [["class", "float-right mt-4 mb-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](147, 0, null, null, 1, "button", [["class", "mr-2 btn btn-secondary"], ["style", "cursor: pointer;"], ["type", "submit"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeJob() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Cancel"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](149, 0, null, null, 1, "button", [["class", "btn"], ["style", "color:white;background: var(--CloudPrimary-Blue, #1A6AC9);"], ["type", "submit"]], [[8, "disabled", 0]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.saveJob() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Apply"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_7 = _co.frmEditProfile;

          _ck(_v, 2, 0, currVal_7);

          var currVal_15 = "fname";

          _ck(_v, 14, 0, currVal_15);

          var currVal_16 = _co.frmEditProfile.controls["fname"].hasError("required") && _co.frmEditProfile.controls["fname"].touched;

          _ck(_v, 18, 0, currVal_16);

          var currVal_17 = _co.frmEditProfile.get("fname").hasError("nonAscii");

          _ck(_v, 20, 0, currVal_17);

          var currVal_18 = _co.frmEditProfile.get("fname").errors == null ? null : _co.frmEditProfile.get("fname").errors.maxlength;

          _ck(_v, 22, 0, currVal_18);

          var currVal_27 = "10";

          _ck(_v, 31, 0, currVal_27);

          var currVal_28 = "phoneNumber";

          _ck(_v, 34, 0, currVal_28);

          var currVal_29 = _co.frmEditProfile.controls["phoneNumber"].invalid && _co.frmEditProfile.controls["phoneNumber"].touched;

          _ck(_v, 38, 0, currVal_29);

          var currVal_37 = "email";

          _ck(_v, 47, 0, currVal_37);

          var currVal_38 = _co.frmEditProfile.controls["email"].invalid && _co.frmEditProfile.controls["email"].touched;

          _ck(_v, 51, 0, currVal_38);

          var currVal_46 = "experience";

          _ck(_v, 61, 0, currVal_46);

          var currVal_47 = _co.frmEditProfile.controls["experience"].invalid && _co.frmEditProfile.controls["experience"].touched;

          _ck(_v, 65, 0, currVal_47);

          var currVal_48 = _co.frmEditProfile.controls["experience"].errors == null ? null : _co.frmEditProfile.controls["experience"].errors.max;

          _ck(_v, 67, 0, currVal_48);

          var currVal_56 = "trianzExperience";

          _ck(_v, 77, 0, currVal_56);

          var currVal_57 = _co.frmEditProfile.controls["trianzExperience"].invalid && _co.frmEditProfile.controls["trianzExperience"].touched;

          _ck(_v, 81, 0, currVal_57);

          var currVal_65 = "location";

          _ck(_v, 90, 0, currVal_65);

          var currVal_66 = _co.frmEditProfile.get("location").hasError("required") && _co.frmEditProfile.get("location").touched;

          _ck(_v, 94, 0, currVal_66);

          var currVal_67 = _co.frmEditProfile.get("location").errors == null ? null : _co.frmEditProfile.get("location").errors.maxlength;

          _ck(_v, 96, 0, currVal_67);

          var currVal_75 = "primaryskill";

          _ck(_v, 105, 0, currVal_75);

          var currVal_76 = _co.frmEditProfile.get("primaryskill").hasError("required") && _co.frmEditProfile.get("primaryskill").touched;

          _ck(_v, 109, 0, currVal_76);

          var currVal_77 = _co.frmEditProfile.get("primaryskill").hasError("nonAscii");

          _ck(_v, 111, 0, currVal_77);

          var currVal_78 = _co.frmEditProfile.get("primaryskill").errors == null ? null : _co.frmEditProfile.get("primaryskill").errors.maxlength;

          _ck(_v, 113, 0, currVal_78);

          var currVal_86 = "secondaryskill";

          _ck(_v, 120, 0, currVal_86);

          var currVal_87 = _co.frmEditProfile.get("secondaryskill").hasError("nonAscii");

          _ck(_v, 124, 0, currVal_87);

          var currVal_88 = _co.frmEditProfile.get("secondaryskill").errors == null ? null : _co.frmEditProfile.get("secondaryskill").errors.maxlength;

          _ck(_v, 126, 0, currVal_88);

          var currVal_89 = _co.fileName;

          _ck(_v, 141, 0, currVal_89);

          var currVal_90 = _co.warningMessage;

          _ck(_v, 143, 0, currVal_90);
        }, function (_ck, _v) {
          var _co = _v.component;

          var currVal_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassUntouched;

          var currVal_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassTouched;

          var currVal_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassPristine;

          var currVal_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassDirty;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassValid;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassInvalid;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 4).ngClassPending;

          _ck(_v, 0, 0, currVal_0, currVal_1, currVal_2, currVal_3, currVal_4, currVal_5, currVal_6);

          var currVal_8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassUntouched;

          var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassTouched;

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassPristine;

          var currVal_11 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassDirty;

          var currVal_12 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassValid;

          var currVal_13 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassInvalid;

          var currVal_14 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 16).ngClassPending;

          _ck(_v, 11, 0, currVal_8, currVal_9, currVal_10, currVal_11, currVal_12, currVal_13, currVal_14);

          var currVal_19 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31).maxlength ? _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 31).maxlength : null;

          var currVal_20 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassUntouched;

          var currVal_21 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassTouched;

          var currVal_22 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassPristine;

          var currVal_23 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassDirty;

          var currVal_24 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassValid;

          var currVal_25 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassInvalid;

          var currVal_26 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 36).ngClassPending;

          _ck(_v, 28, 0, currVal_19, currVal_20, currVal_21, currVal_22, currVal_23, currVal_24, currVal_25, currVal_26);

          var currVal_30 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassUntouched;

          var currVal_31 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassTouched;

          var currVal_32 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassPristine;

          var currVal_33 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassDirty;

          var currVal_34 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassValid;

          var currVal_35 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassInvalid;

          var currVal_36 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 49).ngClassPending;

          _ck(_v, 44, 0, currVal_30, currVal_31, currVal_32, currVal_33, currVal_34, currVal_35, currVal_36);

          var currVal_39 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassUntouched;

          var currVal_40 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassTouched;

          var currVal_41 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassPristine;

          var currVal_42 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassDirty;

          var currVal_43 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassValid;

          var currVal_44 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassInvalid;

          var currVal_45 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 63).ngClassPending;

          _ck(_v, 57, 0, currVal_39, currVal_40, currVal_41, currVal_42, currVal_43, currVal_44, currVal_45);

          var currVal_49 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassUntouched;

          var currVal_50 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassTouched;

          var currVal_51 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassPristine;

          var currVal_52 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassDirty;

          var currVal_53 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassValid;

          var currVal_54 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassInvalid;

          var currVal_55 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 79).ngClassPending;

          _ck(_v, 73, 0, currVal_49, currVal_50, currVal_51, currVal_52, currVal_53, currVal_54, currVal_55);

          var currVal_58 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassUntouched;

          var currVal_59 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassTouched;

          var currVal_60 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassPristine;

          var currVal_61 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassDirty;

          var currVal_62 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassValid;

          var currVal_63 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassInvalid;

          var currVal_64 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 92).ngClassPending;

          _ck(_v, 87, 0, currVal_58, currVal_59, currVal_60, currVal_61, currVal_62, currVal_63, currVal_64);

          var currVal_68 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassUntouched;

          var currVal_69 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassTouched;

          var currVal_70 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassPristine;

          var currVal_71 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassDirty;

          var currVal_72 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassValid;

          var currVal_73 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassInvalid;

          var currVal_74 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 107).ngClassPending;

          _ck(_v, 102, 0, currVal_68, currVal_69, currVal_70, currVal_71, currVal_72, currVal_73, currVal_74);

          var currVal_79 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassUntouched;

          var currVal_80 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassTouched;

          var currVal_81 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassPristine;

          var currVal_82 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassDirty;

          var currVal_83 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassValid;

          var currVal_84 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassInvalid;

          var currVal_85 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 122).ngClassPending;

          _ck(_v, 117, 0, currVal_79, currVal_80, currVal_81, currVal_82, currVal_83, currVal_84, currVal_85);

          var currVal_91 = !_co.frmEditProfile.valid;

          _ck(_v, 149, 0, currVal_91);
        });
      }

      function View_JobDetailsComponent_42(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "span", [["class", "text-danger"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes cannot exceed 2000 characters"]))], null, null);
      }

      function View_JobDetailsComponent_43(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_44(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "progress-line"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "div", [["class", "progress"], ["style", "height: 100%;"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_45(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 8, "div", [["class", "step"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "bullet"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["-"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 5, "div", [["class", "details"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](4, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](5, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 1, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](7, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 0, "div", [], null, null, null, null, null))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.$implicit.applicationStatusName;

          _ck(_v, 5, 0, currVal_0);

          var currVal_1 = _co.getFormattedDate(_v.context.$implicit.lastUpdate);

          _ck(_v, 7, 0, currVal_1);
        });
      }

      function View_JobDetailsComponent_46(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "div", [["class", "notes-progress-line"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "div", [["class", "notes-progress"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_47(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 0, "textarea", [["class", "ml-3"], ["cols", "50"], ["readonly", ""], ["rows", "3"], ["style", "background: rgb(241, 241, 241);border-radius: 5px;font-size: 15px;"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "span", [["class", "note-date mb-4 mr-2"], ["style", "float: right;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](3, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _v.context.$implicit.notes;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = _co.getFormattedDate(_v.context.$implicit.lastUpdate);

          _ck(_v, 3, 0, currVal_1);
        });
      }

      function View_JobDetailsComponent_48(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 3, null, null, null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_JobDetailsComponent_49(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applied Date : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](3, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](4, null, ["", ""]))], null, function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 4, 0, currVal_0);
        });
      }

      function View_JobDetailsComponent_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵqud"](671088640, 1, {
          fileInput: 0
        }), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_2)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](4, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](5, 0, null, null, 16, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "application"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](6, 0, null, null, 15, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](7, 0, null, null, 14, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](8, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](9, 0, null, null, 12, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_14)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](11, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](12, 0, null, null, 0, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](13, 0, null, null, 6, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](14, 0, null, null, 4, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](15, 0, null, null, 1, "h4", [["class", "application-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["APPLICATION FORM"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](17, 0, null, null, 1, "h6", [["class", "sub-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Complete an application now."])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](19, 0, null, null, 0, "img", [["aria-label", "Close"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"], ["style", "height: 21px;cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_15)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](21, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](22, 0, null, null, 12, "div", [["aria-hidden", "true"], ["aria-labelledby", "welcomeLabel"], ["class", "modal fade"], ["data-backdrop", "static"], ["data-keyboard", "false"], ["id", "welcome"], ["role", "dialog"], ["style", "margin-top: 0px;"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](23, 0, null, null, 11, "div", [["class", "modal-dialog"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](24, 0, null, null, 10, "div", [["class", "modal-content modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](25, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](26, 0, null, null, 8, "div", [["class", "modal-body text-center"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](27, 0, null, null, 3, "div", [["class", "container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](28, 0, null, null, 2, "button", [["class", "tick-button"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](29, 0, null, null, 1, ":svg:svg", [["class", "feather feather-check"], ["fill", "none"], ["height", "48"], ["stroke", "currentColor"], ["stroke-linecap", "round"], ["stroke-linejoin", "round"], ["stroke-width", "4"], ["viewBox", "0 0 24 24"], ["width", "48"], ["xmlns", "http://www.w3.org/2000/svg"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](30, 0, null, null, 0, ":svg:polyline", [["points", "20 6 9 17 4 12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](31, 0, null, null, 1, "h5", [["class", "mt-2"], ["style", "color: #ed7932;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["YOUR APPLICATION HAS BEEN SUBMITTED SUCCESSFULLY"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](33, 0, null, null, 1, "button", [["class", "btn mt-4"], ["style", "background: #09c;color: white;"], ["type", "submit"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeJobRole("home") !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Close"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](35, 0, null, null, 22, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "notes"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](36, 0, null, null, 21, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](37, 0, null, null, 20, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](38, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](39, 0, null, null, 18, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](40, 0, null, null, 3, "div", [["class", "d-flex justify-content-between mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](41, 0, null, null, 1, "h4", [["class", "application-header"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](43, 0, null, null, 0, "img", [["aria-label", "Close"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"], ["style", "height: 21px;cursor: pointer;"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](44, 0, null, null, 8, "div", [["class", "form-group pt-3"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](45, 0, null, null, 5, "textarea", [["class", "form-control input-div"], ["cols", "50"], ["rows", "9"]], [[2, "ng-untouched", null], [2, "ng-touched", null], [2, "ng-pristine", null], [2, "ng-dirty", null], [2, "ng-valid", null], [2, "ng-invalid", null], [2, "ng-pending", null]], [[null, "ngModelChange"], [null, "input"], [null, "blur"], [null, "compositionstart"], [null, "compositionend"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("input" === en) {
            var pd_0 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 46)._handleInput($event.target.value) !== false;
            ad = pd_0 && ad;
          }

          if ("blur" === en) {
            var pd_1 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 46).onTouched() !== false;
            ad = pd_1 && ad;
          }

          if ("compositionstart" === en) {
            var pd_2 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 46)._compositionStart() !== false;
            ad = pd_2 && ad;
          }

          if ("compositionend" === en) {
            var pd_3 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 46)._compositionEnd($event.target.value) !== false;
            ad = pd_3 && ad;
          }

          if ("ngModelChange" === en) {
            var pd_4 = (_co.notesComments = $event) !== false;
            ad = pd_4 && ad;
          }

          return ad;
        }, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](46, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["Renderer2"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"], [2, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["COMPOSITION_BUFFER_MODE"]]], null, null), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](1024, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"], function (p0_0) {
          return [p0_0];
        }, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["DefaultValueAccessor"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](48, 671744, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"], [[8, null], [8, null], [8, null], [6, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NG_VALUE_ACCESSOR"]]], {
          model: [0, "model"]
        }, {
          update: "ngModelChange"
        }), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵprd"](2048, null, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"], null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgModel"]]), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](50, 16384, null, 0, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControlStatus"], [[4, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["NgControl"]]], null, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_42)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](52, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](53, 0, null, null, 4, "div", [["class", "float-right"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](54, 0, null, null, 1, "button", [["class", "btn btn-secondary mt-2"], ["type", "submit"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Close"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](56, 0, null, null, 1, "button", [["class", "btn mt-2 ml-3"], ["style", "color:white;background: var(--CloudPrimary-Blue, #1A6AC9);"], ["type", "submit"]], [[8, "disabled", 0]], [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.saveNotes() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Save"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](58, 0, null, null, 32, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "history"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](59, 0, null, null, 31, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](60, 0, null, null, 30, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](61, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](62, 0, null, null, 3, "div", [["class", "modal-header d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](63, 0, null, null, 1, "div", [["style", "color: #133B93;font-weight: 600;font-size: 21px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](64, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](65, 0, null, null, 0, "img", [["aria-label", "Close"], ["class", "close-modal-icon"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeHistoryModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](66, 0, null, null, 24, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_43)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](68, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](69, 0, null, null, 0, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](70, 0, null, null, 20, "div", [["class", "row"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](71, 0, null, null, 9, "div", [["class", "col-5"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](72, 0, null, null, 8, "div", [["class", "progress-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](73, 0, null, null, 1, "div", [["class", "progress-title"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Applicant Status"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](75, 0, null, null, 5, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_44)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](77, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](78, 0, null, null, 2, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_45)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](80, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](81, 0, null, null, 9, "div", [["class", "col-7"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](82, 0, null, null, 8, "div", [["class", "progress-container"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](83, 0, null, null, 1, "div", [["class", "progress-title"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Notes History"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](85, 0, null, null, 5, "div", [["class", "d-flex justify-content-between"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_46)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](87, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](88, 0, null, null, 2, "div", [["class", "row"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_47)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](90, 278528, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgForOf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["IterableDiffers"]], {
          ngForOf: [0, "ngForOf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](91, 0, null, null, 56, "div", [["aria-hidden", "true"], ["aria-labelledby", "rightModalLabel"], ["class", "modal fade"], ["id", "candidateModal"], ["role", "dialog"], ["tabindex", "-1"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](92, 0, null, null, 55, "div", [["class", "modal-dialog modal-dialog-slideout modal-dialog-centered"], ["role", "document"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](93, 0, null, null, 54, "div", [["class", "modal-content"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](94, 0, null, null, 0, "div", [["class", "modalBackground"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](95, 0, null, null, 3, "div", [["class", "modal-header d-flex justify-content-between"], ["style", "padding:13px 25px 13px 22px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](96, 0, null, null, 1, "div", [["style", "color: #133B93;font-weight: 600;font-size: 21px;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](97, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](98, 0, null, null, 0, "img", [["aria-label", "Close"], ["class", "close-modal-icon"], ["data-dismiss", "modal"], ["src", "../../assets/images/clear.svg"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeEmpDataModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](99, 0, null, null, 48, "div", [["class", "modal-body"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_48)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](101, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](102, 0, null, null, 45, "div", [["class", "row"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](103, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](104, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Name : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](106, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](107, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](108, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](109, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["email : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](111, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](112, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](113, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](114, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Mobile : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](116, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](117, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](118, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](119, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Location : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](121, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](122, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](123, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](124, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Total Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](126, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](127, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](128, 0, null, null, 4, "div", [["class", "col-6"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](129, 0, null, null, 3, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Trianz Experience : "])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](131, 0, null, null, 1, "span", [["style", "font-weight: normal;"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](132, null, ["", ""])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_JobDetailsComponent_49)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](134, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_2__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](135, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](136, 0, null, null, 1, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Primary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](138, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](139, 0, null, null, 0, "textarea", [["class", "form-control input-div font-size-14p"], ["cols", "3"], ["readonly", ""], ["rows", "3"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](140, 0, null, null, 4, "div", [["class", "col-12"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](141, 0, null, null, 1, "div", [["class", "mt-3"], ["style", "font-size: 15px;font-weight:600"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Secondary Skills :"])), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](143, 0, null, null, 1, "div", [["class", "mt-2 innerhtml"], ["style", "color: var(--on-primary);"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](144, 0, null, null, 0, "textarea", [["class", "form-control input-div font-size-14p"], ["cols", "3"], ["readonly", ""], ["rows", "3"]], [[8, "value", 0]], null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](145, 0, null, null, 2, "div", [["class", "col-12 mt-2"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](146, 0, null, null, 1, "button", [["class", "btn btn-secondary float-right mt-4 mb-2"], ["type", "submit"]], null, [[null, "click"]], function (_v, en, $event) {
          var ad = true;
          var _co = _v.component;

          if ("click" === en) {
            var pd_0 = _co.closeEmpDataModal() !== false;
            ad = pd_0 && ad;
          }

          return ad;
        }, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵted"](-1, null, ["Close"]))], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.loading == true;

          _ck(_v, 2, 0, currVal_0);

          var currVal_1 = _co.selectedJob;

          _ck(_v, 4, 0, currVal_1);

          var currVal_2 = _co.loading == true;

          _ck(_v, 11, 0, currVal_2);

          var currVal_3 = _co.userInfo;

          _ck(_v, 21, 0, currVal_3);

          var currVal_11 = _co.notesComments;

          _ck(_v, 48, 0, currVal_11);

          var currVal_12 = (_co.notesComments == null ? null : _co.notesComments.length) > 2000;

          _ck(_v, 52, 0, currVal_12);

          var currVal_15 = _co.loading == true;

          _ck(_v, 68, 0, currVal_15);

          var currVal_16 = _co.statusHistory == null ? null : _co.statusHistory.length;

          _ck(_v, 77, 0, currVal_16);

          var currVal_17 = _co.statusHistory;

          _ck(_v, 80, 0, currVal_17);

          var currVal_18 = _co.notesHistory == null ? null : _co.notesHistory.length;

          _ck(_v, 87, 0, currVal_18);

          var currVal_19 = _co.notesHistory;

          _ck(_v, 90, 0, currVal_19);

          var currVal_21 = _co.loading == true;

          _ck(_v, 101, 0, currVal_21);

          var currVal_28 = _co.empData == null ? null : _co.empData.appliedDate;

          _ck(_v, 134, 0, currVal_28);
        }, function (_ck, _v) {
          var _co = _v.component;

          var currVal_4 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassUntouched;

          var currVal_5 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassTouched;

          var currVal_6 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassPristine;

          var currVal_7 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassDirty;

          var currVal_8 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassValid;

          var currVal_9 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassInvalid;

          var currVal_10 = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵnov"](_v, 50).ngClassPending;

          _ck(_v, 45, 0, currVal_4, currVal_5, currVal_6, currVal_7, currVal_8, currVal_9, currVal_10);

          var currVal_13 = _co.notesComments == "" || (_co.notesComments == null ? null : _co.notesComments.length) > 2000 || _co.changeComment == _co.notesComments;

          _ck(_v, 56, 0, currVal_13);

          var currVal_14 = _co.candidateName;

          _ck(_v, 64, 0, currVal_14);

          var currVal_20 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 97, 0, currVal_20);

          var currVal_22 = _co.empData == null ? null : _co.empData.empName;

          _ck(_v, 107, 0, currVal_22);

          var currVal_23 = _co.empData == null ? null : _co.empData.email;

          _ck(_v, 112, 0, currVal_23);

          var currVal_24 = _co.empData == null ? null : _co.empData.mobile;

          _ck(_v, 117, 0, currVal_24);

          var currVal_25 = _co.empData == null ? null : _co.empData.location;

          _ck(_v, 122, 0, currVal_25);

          var currVal_26 = _co.empData == null ? null : _co.empData.totalExperience;

          _ck(_v, 127, 0, currVal_26);

          var currVal_27 = _co.empData == null ? null : _co.empData.trianzExperience;

          _ck(_v, 132, 0, currVal_27);

          var currVal_29 = _co.empData == null ? null : _co.empData.primarySkills;

          _ck(_v, 139, 0, currVal_29);

          var currVal_30 = _co.empData == null ? null : _co.empData.secondarySkills;

          _ck(_v, 144, 0, currVal_30);
        });
      }

      function View_JobDetailsComponent_Host_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "app-job-details", [], null, null, null, View_JobDetailsComponent_0, RenderType_JobDetailsComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 770048, null, 0, _job_details_component__WEBPACK_IMPORTED_MODULE_4__["JobDetailsComponent"], [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"], _providers_utility_service__WEBPACK_IMPORTED_MODULE_6__["UtilityService"], _providers_jump_service__WEBPACK_IMPORTED_MODULE_7__["JumpService"]], null, null)], function (_ck, _v) {
          _ck(_v, 1, 0);
        }, null);
      }

      var JobDetailsComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("app-job-details", _job_details_component__WEBPACK_IMPORTED_MODULE_4__["JobDetailsComponent"], View_JobDetailsComponent_Host_0, {
        jobDetails: "jobDetails",
        applyNowBtnClick: "applyNowBtnClick"
      }, {
        applyNowModelClose: "applyNowModelClose",
        closeApplyButton: "closeApplyButton"
      }, []);
      /***/

    },

    /***/
    "vEWE":
    /*!**************************************************************************!*\
      !*** ./src/app/job-mobility/job-mobility.component.scss.shim.ngstyle.js ***!
      \**************************************************************************/

    /*! exports provided: styles */

    /***/
    function vEWE(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "styles", function () {
        return styles;
      });
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles = [".container-fluid[_ngcontent-%COMP%] {\n  overflow-x: hidden;\n}\n\n.banner-section[_ngcontent-%COMP%] {\n  background-color: #00367e;\n  background-size: 100%;\n  min-height: 172px;\n  background-position: 100%;\n  background-repeat: no-repeat;\n  margin-left: -26px;\n  margin-right: -26px;\n}\n\n.jump-header[_ngcontent-%COMP%] {\n  padding-left: 34px;\n  padding-top: 29px;\n  color: white;\n  font-size: 34px;\n}\n\n.img-tag[_ngcontent-%COMP%] {\n  height: 134px;\n  width: 102%;\n  margin-left: -68px;\n  margin-top: 16px;\n}\n\n.font-size-18p[_ngcontent-%COMP%] {\n  font-size: 18px;\n}\n\n.font-size-16p[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\n.font-size-14p[_ngcontent-%COMP%] {\n  font-size: 14px;\n}\n\n.font-size-12p[_ngcontent-%COMP%] {\n  font-size: 12px;\n}\n\n.font-size-10p[_ngcontent-%COMP%] {\n  font-size: 10px;\n}\n\n.loaderDiv[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 60%;\n  left: 55%;\n  transform: translate(-50%, -50%);\n  font-size: 60px;\n}\n\n.centerLoader[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.card-img-height[_ngcontent-%COMP%] {\n  min-height: 210px;\n  max-height: 211px;\n}\n\n.canvas-height[_ngcontent-%COMP%] {\n  height: 210px;\n}\n\n@media (min-width: 1900px) {\n  .card-img-height[_ngcontent-%COMP%] {\n    min-height: 243px;\n    max-height: 245px;\n  }\n\n  .canvas-height[_ngcontent-%COMP%] {\n    height: 245px;\n  }\n}\n\n.categoryTabs[_ngcontent-%COMP%]   a[_ngcontent-%COMP%] {\n  color: #a7a7a7;\n  text-decoration: none;\n}\n\n.categoryTabs[_ngcontent-%COMP%]   a.active[_ngcontent-%COMP%] {\n  color: var(--on-background);\n  border-bottom: 2px solid #f60;\n  padding-bottom: 5px;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\n.text-justify[_ngcontent-%COMP%] {\n  color: var(--Body-text-color, #231F20);\n  font-family: Poppins;\n  font-size: 15px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 22px;\n  \n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%] {\n  font-size: 13px;\n  color: var(--clientnewstext);\n  font-weight: bold;\n  border: none;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   th[_ngcontent-%COMP%]   [_ngcontent-%COMP%]:hover {\n  color: #fff;\n}\n\n.table[_ngcontent-%COMP%]   thead[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  background-color: none;\n}\n\n.th-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  background: var(--table-bg);\n  color: var(--clientnewstext);\n  font-weight: 600;\n}\n\n.table[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%] {\n  text-align: left;\n}\n\ntd[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n\ntable[_ngcontent-%COMP%]   tbody[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%]:hover {\n  background: var(--d-9-d-9-d-9, #D1E1F4);\n}\n\ntable[_ngcontent-%COMP%]   tr[_ngcontent-%COMP%] {\n  background: #ffffff;\n}\n\ntable[_ngcontent-%COMP%]   .mat-tab-body-content[_ngcontent-%COMP%] {\n  overflow-x: hidden !important;\n}\n\n.row.matTab[_ngcontent-%COMP%] {\n  min-height: 200px;\n}\n\n.badgeStatus[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  padding: 1px 3px;\n  width: 98%;\n  background: #1a81ff 0% 0% no-repeat padding-box;\n  border-radius: 4px;\n  opacity: 1;\n}\n\n.details-button[_ngcontent-%COMP%] {\n  background-color: #f8f9fa;\n  border-radius: 50%;\n  transition: background-color 0.3s ease;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\nselect[_ngcontent-%COMP%] {\n  padding: 6px;\n  font-size: 13px;\n  border-radius: 4px;\n  border: 1px solid #ccc;\n  height: 40px;\n  background-color: white;\n  background-size: 12px;\n  width: 150px;\n}\n\nselect[_ngcontent-%COMP%]   option[_ngcontent-%COMP%]:hover {\n  background-color: black !important;\n  color: white;\n}\n\noption[disabled][_ngcontent-%COMP%] {\n  display: none;\n}\n\noption[_ngcontent-%COMP%]:hover {\n  color: #ccc;\n}\n\nselect[_ngcontent-%COMP%]:focus {\n  border-color: #007bff;\n  box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);\n}\n\na[_ngcontent-%COMP%]:hover {\n  color: #00367e;\n}\n\n.modal-content[_ngcontent-%COMP%] {\n  border-radius: 0;\n  border: 1px solid rgba(0, 0, 0, 0.2);\n  box-shadow: 0px 3px 6px #00000029;\n  position: absolute;\n  left: -100px;\n  min-height: 420px;\n  width: 800px;\n}\n\n.textColor[_ngcontent-%COMP%] {\n  margin-right: 11px;\n  margin-top: 9px;\n  font-size: 24px;\n}\n\n.modal-body[_ngcontent-%COMP%] {\n  padding: 1px 26px;\n  overflow-y: auto;\n  overflow-x: hidden;\n  height: 450px;\n}\n\n.form-control[_ngcontent-%COMP%] {\n  width: 100%;\n}\n\n.mb-3[_ngcontent-%COMP%] {\n  margin-bottom: 15px;\n}\n\n.text-danger[_ngcontent-%COMP%] {\n  color: red;\n  font-size: 13px;\n}\n\n.button[_ngcontent-%COMP%] {\n  border-radius: 21px;\n  width: 18%;\n}\n\n.badge-open[_ngcontent-%COMP%] {\n  color: white;\n  font-size: 13px !important;\n  font-weight: 300;\n  border-radius: 5px !important;\n  width: 99% !important;\n  height: auto !important;\n  cursor: pointer !important;\n}\n\n.form-group[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n}\n\n.create-btn[_ngcontent-%COMP%] {\n  margin-right: 23px;\n  padding-top: 6px;\n  color: white;\n  background-color: #FF6600;\n  width: 12%;\n  height: 39px;\n}\n\n.edit-btn[_ngcontent-%COMP%] {\n  float: right;\n  margin-top: -22px;\n  margin-right: 23px;\n  width: 6%;\n}\n\n.badge[_ngcontent-%COMP%] {\n  line-height: 1.5 !important;\n}\n\n.apply-btn[_ngcontent-%COMP%] {\n  padding-top: 2px;\n  padding-bottom: 2px;\n  display: inline-flex;\n  align-items: center;\n  background-color: #0099cc;\n  color: #F3F4F6;\n}\n\n.close-job[_ngcontent-%COMP%] {\n  z-index: 1;\n  position: relative;\n  font-size: 16px;\n  margin-top: 32px;\n  margin-right: 32px;\n  cursor: pointer;\n  color: white;\n  background-color: #09c;\n}\n\n.edit-job[_ngcontent-%COMP%] {\n  z-index: 1;\n  position: absolute;\n  font-size: 23px;\n  margin-top: 52px;\n  margin-left: 169px;\n  cursor: pointer;\n}\n\n.search-box[_ngcontent-%COMP%] {\n  padding: 8px;\n  font-size: 14px;\n  border: 1px solid #ccc;\n  height: 40px;\n  background-color: white;\n  background-size: 12px;\n  width: 180px;\n  border-top-left-radius: 4px;\n  border-bottom-left-radius: 4px;\n  padding-bottom: 3px;\n}\n\n.search-icon[_ngcontent-%COMP%] {\n  padding: 8px;\n  font-size: 18px;\n  height: 40px;\n  padding-top: 12px;\n  background-color: #09c;\n  color: white;\n  cursor: pointer;\n  border-top-right-radius: 4px;\n  border-bottom-right-radius: 4px;\n}\n\n.pagination[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  margin-top: 5px;\n  margin-right: -9px;\n}\n\n.page-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 34px;\n  height: 34px;\n  border: 1px solid #ddd;\n  cursor: pointer;\n  transition: background-color 0.3s;\n}\n\n.page-item.active[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  color: white;\n  background-color: #00367edb;\n  border: none;\n}\n\n.page-item.disabled[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n}\n\n.disabled[_ngcontent-%COMP%] {\n  cursor: not-allowed;\n  opacity: 0.5;\n  pointer-events: none;\n}\n\n.page-number[_ngcontent-%COMP%] {\n  font-size: 15px;\n  color: #09c;\n  transition: color 0.3s, -webkit-text-decoration 0.3s;\n  transition: color 0.3s, text-decoration 0.3s;\n  transition: color 0.3s, text-decoration 0.3s, -webkit-text-decoration 0.3s;\n}\n\n.page-number[_ngcontent-%COMP%]:hover {\n  color: #09c;\n  text-decoration: underline;\n}\n\n.page-number.active[_ngcontent-%COMP%] {\n  text-decoration: underline;\n  color: white;\n}\n\n.page-item[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  font-size: 24px;\n  color: #00367edb;\n  transition: color 0.3s;\n}\n\n.prev-page[_ngcontent-%COMP%] {\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\n.next-page[_ngcontent-%COMP%] {\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\n.assigned-label[_ngcontent-%COMP%] {\n  margin-left: 1px;\n  font-size: 15px;\n}\n\n.application-search[_ngcontent-%COMP%] {\n  margin-right: 7px;\n  margin-bottom: 10px;\n  margin-top: 3px;\n}\n\n.import-btn[_ngcontent-%COMP%] {\n  margin-right: 23px;\n  margin-top: 31px;\n  padding-top: 6px;\n  color: white;\n  background-color: #FF6600;\n  height: 39px;\n}\n\n.tr-details[_ngcontent-%COMP%] {\n  color: #09c;\n  cursor: pointer;\n}\n\n.tr-details[_ngcontent-%COMP%]:hover {\n  color: #09c;\n  text-decoration: underline;\n}\n\n.save-btn[_ngcontent-%COMP%] {\n  color: white;\n  background: var(--CloudPrimary-Blue, #1A6AC9);\n}\n\n.input-dropdown[_ngcontent-%COMP%] {\n  background-color: #09c;\n  color: white;\n  border-radius: 8px;\n  border: 1px solid var(--Gray-300, #D0D5DD);\n  box-shadow: 0px 1px 2px 0px rgba(16, 24, 40, 0.05);\n  cursor: pointer;\n}\n\n.dropdown-item.active[_ngcontent-%COMP%], .dropdown-item[_ngcontent-%COMP%]:active {\n  color: #fff;\n  text-decoration: none;\n  background-color: #00367edb;\n}\n\n.dropdown-item[_ngcontent-%COMP%]:hover {\n  color: white;\n  background-color: #00367edb;\n  cursor: pointer;\n}\n\n.input-group[_ngcontent-%COMP%]   .dropdown-menu[_ngcontent-%COMP%] {\n  top: 93%;\n  left: 0;\n  right: 0;\n  z-index: 1000;\n  display: none;\n  float: left;\n  min-width: 10rem;\n  padding: 0.5rem 0;\n  margin: 0.125rem 0 0;\n  font-size: 1rem;\n  color: #212529;\n  text-align: left;\n  list-style: none;\n  background-color: #fff;\n  background-clip: padding-box;\n  border: 1px solid rgba(0, 0, 0, 0.15);\n  border-radius: 0.25rem;\n}\n\n.input-group[_ngcontent-%COMP%]   .dropdown-menu.show[_ngcontent-%COMP%] {\n  display: block;\n  font-size: 13px;\n}\n\n.loader-background[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 1000;\n}\n\n.table-container[_ngcontent-%COMP%] {\n  position: relative;\n  text-align: center;\n}\n\n.loader[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate(-50%, -50%);\n  --d: 22px;\n  width: 4px;\n  height: 4px;\n  border-radius: 50%;\n  color: #09c;\n  box-shadow: calc(1 * var(--d)) calc(0 * var(--d)) 0 0, calc(0.707 * var(--d)) calc(0.707 * var(--d)) 0 1px, calc(0 * var(--d)) calc(1 * var(--d)) 0 2px, calc(-0.707 * var(--d)) calc(0.707 * var(--d)) 0 3px, calc(-1 * var(--d)) calc(0 * var(--d)) 0 4px, calc(-0.707 * var(--d)) calc(-0.707 * var(--d)) 0 5px, calc(0 * var(--d)) calc(-1 * var(--d)) 0 6px;\n  -webkit-animation: l27 1s infinite steps(8);\n          animation: l27 1s infinite steps(8);\n}\n\n@-webkit-keyframes l27 {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n\n@keyframes l27 {\n  0% {\n    transform: rotate(0deg);\n  }\n  100% {\n    transform: rotate(360deg);\n  }\n}\n\n.primary-skill-ellipsis[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 200px;\n  vertical-align: top;\n}\n\n.tooltip-container[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n}\n\n.tooltip-container[_ngcontent-%COMP%]   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: hidden;\n  width: 201px;\n  background-color: #555;\n  color: #fff;\n  text-align: center;\n  border-radius: 6px;\n  padding: 5px 0;\n  position: absolute;\n  z-index: 1;\n  right: -106px;\n  top: 30px;\n  transform: translateX(-50%);\n  opacity: 0;\n  transition: opacity 0.3s;\n}\n\n.tooltip-container[_ngcontent-%COMP%]:hover   .tooltip-text[_ngcontent-%COMP%] {\n  visibility: visible;\n  opacity: 1;\n}\n\n.wrapper[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.left-bar[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 5px;\n  height: 100%;\n  background-color: #000;\n  \n}\n\n.top-bar[_ngcontent-%COMP%] {\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 5px;\n  background-color: #000;\n  \n}\n\n.content[_ngcontent-%COMP%] {\n  padding-left: 5px;\n  padding-top: 5px;\n}\n\n.profile-dropdown[_ngcontent-%COMP%] {\n  position: relative;\n}\n\n.dropdown-content[_ngcontent-%COMP%] {\n  display: none;\n  position: absolute;\n  right: 0;\n  top: 100%;\n  background-color: white;\n  min-width: 200px;\n  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);\n  padding: 10px;\n  z-index: 1;\n  border: 1px solid #ddd;\n  border-radius: 4px;\n}\n\n.dropdown-content[_ngcontent-%COMP%]   p[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 5px 0;\n  color: #333;\n}\n\n.dropdown-content[_ngcontent-%COMP%]   strong[_ngcontent-%COMP%] {\n  display: block;\n  margin-top: 5px;\n}\n\n\n\n.dropdown-content.show[_ngcontent-%COMP%] {\n  display: block;\n}\n\n.profile-tooltip[_ngcontent-%COMP%] {\n  position: relative;\n  display: inline-block;\n  float: right;\n  margin-left: 17px;\n  margin-top: 6px;\n}\n\n.profile-tooltip[_ngcontent-%COMP%]   .tooltip-text[_ngcontent-%COMP%] {\n  width: 409px;\n  background-color: #fff;\n  color: black;\n  border-radius: 6px;\n  padding: 7px 8px;\n  position: absolute;\n  z-index: 1;\n  top: 31px;\n  right: -195px;\n  transform: translateX(-50%);\n  opacity: 1;\n  transition: opacity 0.3s;\n  border: 2px solid white;\n}\n\n.last-item[_ngcontent-%COMP%] {\n  border-bottom: 1px solid #dee2e6;\n}\n\n.navigation-link[_ngcontent-%COMP%] {\n  border: 1px solid lightgray;\n  border-radius: 9px;\n  width: 36px;\n  height: 28px;\n  cursor: pointer;\n}\n\n.banner-header[_ngcontent-%COMP%] {\n  display: flex;\n  height: 121px;\n  flex-direction: column;\n  align-items: center;\n  align-self: stretch;\n  background-color: #00367e;\n}\n\n.banner-image[_ngcontent-%COMP%] {\n  height: 48px;\n  padding: 0px 18px 6px 5px;\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  align-self: stretch;\n}\n\n.profile-logo[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n}\n\n.jump[_ngcontent-%COMP%] {\n  display: flex;\n  height: 67px;\n  padding-left: 32px;\n  align-items: center;\n  align-self: stretch;\n}\n\n.jump-title[_ngcontent-%COMP%] {\n  color: var(--White-col, #FFF);\n  font-family: Poppins;\n  font-size: 32px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 34px;\n  margin-right: 30px;\n  margin-bottom: 6px;\n}\n\n.title-div[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n  margin-top: 1px;\n  margin-left: 68px;\n}\n\n.apply-btn[_ngcontent-%COMP%] {\n  border-radius: 8px;\n  background: var(--Brand-orange-color, #F26C21);\n  padding: 4px 12px;\n  margin-top: 12px;\n  margin-right: 10px;\n}\n\n.banner-logo[_ngcontent-%COMP%] {\n  margin-right: 22px;\n  margin-top: 5px;\n  width: 351.78px;\n  height: 114px;\n  flex-shrink: 0;\n  background: url('JUMP-banner-Illustration.jpg') lightgray -176.016px 0px/151.708% 100% no-repeat;\n}\n\n.sub-header[_ngcontent-%COMP%] {\n  color: var(--White-col, #FFF);\n  font-family: Poppins;\n  font-size: 20px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 36px;\n  \n  padding-left: 79px;\n}\n\n.content-section[_ngcontent-%COMP%] {\n  background-color: #ffffff;\n  display: flex;\n  padding: 0px 28px;\n  flex-direction: column;\n  align-items: flex-start;\n  gap: 40px;\n  align-self: stretch;\n  margin-top: 4px;\n}\n\n.input-search[_ngcontent-%COMP%] {\n  width: 235px;\n  height: 36px;\n  margin-left: -13px;\n}\n\n.input-group[_ngcontent-%COMP%]   .form-control[_ngcontent-%COMP%] {\n  padding-right: 2.5rem;\n  \n  border-top-left-radius: 8px;\n  \n  border-bottom-left-radius: 8px;\n  border-top-right-radius: 0;\n  \n  border-bottom-right-radius: 0;\n  padding-top: 16px;\n}\n\n.input-group-append[_ngcontent-%COMP%] {\n  position: absolute;\n  right: 0;\n  top: 0;\n  z-index: 1;\n  padding-top: 5px;\n}\n\n.search[_ngcontent-%COMP%] {\n  padding: 7px;\n  font-size: 18px;\n}\n\n.badge-custom[_ngcontent-%COMP%] {\n  font-weight: bold !important;\n  padding: 0.3em 0.5em;\n  border-radius: 1.25rem !important;\n  width: 100% !important;\n  height: auto !important;\n  font-size: 12px !important;\n}\n\n.section-border[_ngcontent-%COMP%] {\n  border: 1px solid lightgray;\n  border-radius: 9px;\n  margin-right: 23px;\n  margin-bottom: 6px;\n}\n\n.dialog-overlay[_ngcontent-%COMP%] {\n  position: fixed;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.dialog[_ngcontent-%COMP%] {\n  background-color: #fff;\n  padding: 20px;\n  border-radius: 8px;\n  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);\n  width: 300px;\n  text-align: center;\n}\n\n.dialog[_ngcontent-%COMP%]   h2[_ngcontent-%COMP%] {\n  margin-bottom: 20px;\n}\n\n.dialog[_ngcontent-%COMP%]   select[_ngcontent-%COMP%] {\n  width: 100%;\n  padding: 8px;\n  margin-bottom: 20px;\n}\n\n.dialog-actions[_ngcontent-%COMP%] {\n  display: flex;\n  float: right;\n}\n\n.dialog-actions[_ngcontent-%COMP%]   button[_ngcontent-%COMP%] {\n  padding: 4px 20px;\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  block-size: 36px;\n}\n\n.close-status[_ngcontent-%COMP%] {\n  cursor: pointer;\n  font-size: 20px;\n}\n\n.badge[_ngcontent-%COMP%] {\n  line-height: 1.5 !important;\n}\n\n.status[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  gap: 4px;\n  width: 84%;\n}\n\n.badge-open[_ngcontent-%COMP%] {\n  color: white;\n  font-size: 13px;\n  border-radius: 5px;\n  width: 95% !important;\n  cursor: pointer;\n  height: auto !important;\n  border-radius: 16px !important;\n  font-weight: bold;\n}\n\n.details-container[_ngcontent-%COMP%] {\n  padding: 16px;\n  background-color: #f9f9f9;\n  border: 1px solid #ddd;\n  border-radius: 8px;\n}\n\n.details-container[_ngcontent-%COMP%]   h3[_ngcontent-%COMP%] {\n  color: #ff6600;\n}\n\n.detail-row[_ngcontent-%COMP%] {\n  display: flex;\n  justify-content: space-between;\n  margin-top: 8px;\n}\n\n.detail-row[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  margin-right: 16px;\n}\n\n.detail-row[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%] {\n  margin: 0;\n  padding: 0;\n  list-style-type: none;\n}\n\n.detail-row[_ngcontent-%COMP%]   ul[_ngcontent-%COMP%]   li[_ngcontent-%COMP%] {\n  margin: 0;\n}\n\n.job-details-header[_ngcontent-%COMP%] {\n  color: #212529;\n  font-size: 16px;\n}\n\n.details-sub-header[_ngcontent-%COMP%] {\n  color: var(--Gray-700, #344054);\n  font-family: Poppins;\n  font-size: 13px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 20px;\n}\n\n.job-detail-header[_ngcontent-%COMP%] {\n  color: var(--Brand-orange-color, #F26C21);\n  font-family: Poppins;\n  font-size: 16px;\n  font-style: normal;\n  font-weight: 600;\n  line-height: 20px;\n  padding-bottom: 5px;\n  border-bottom: 1px solid var(--Brand-orange-color, #F26C21);\n}\n\n.application-sub-header[_ngcontent-%COMP%] {\n  color: var(--Body-text-color, #231F20);\n  font-family: Poppins;\n  font-size: 15px;\n  font-style: normal;\n  font-weight: 400;\n  line-height: 18px;\n  \n}\n\n.file-input-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.custom-file-upload[_ngcontent-%COMP%] {\n  width: 30%;\n  border: 1px solid lightgray;\n  padding: 4px 12px;\n  cursor: pointer;\n  background-color: lightgray;\n  height: 28px;\n}\n\n#imageUpload[_ngcontent-%COMP%] {\n  width: 0;\n  opacity: 0;\n  overflow: hidden;\n  position: absolute;\n  z-index: -1;\n}\n\n.continue-box[_ngcontent-%COMP%] {\n  flex: 1;\n  border: 1px solid #f4dada14;\n  padding: 4px 33px;\n  background-color: #F3F4F6;\n  min-height: 28px;\n}\n\n.show-Details[_ngcontent-%COMP%] {\n  background-color: lightgray;\n}\n\n.nav-link[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-height: 60px;\n  width: 100%;\n  border-radius: 0;\n  color: #6c757d;\n  background-color: #f8f9fa;\n  transition: background-color 0.3s;\n  cursor: pointer;\n}\n\n.nav-link[_ngcontent-%COMP%]:hover, .nav-link.active[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #6c757d;\n}\n\n.nav-link[_ngcontent-%COMP%]   i[_ngcontent-%COMP%] {\n  margin-right: 10px;\n}\n\n.content[_ngcontent-%COMP%] {\n  padding: 20px;\n  border: 1px solid #ddd;\n  border-left: none;\n  height: 100%;\n}\n\n.tab-pane[_ngcontent-%COMP%] {\n  align-items: center;\n  justify-content: center;\n  height: 100%;\n}\n\nbody[_ngcontent-%COMP%] {\n  font-family: \"Circular Std Book\";\n  font-style: normal;\n  font-weight: normal;\n  font-size: 14px;\n  color: #71748d;\n  background-color: #ffffff;\n  -webkit-font-smoothing: antialiased;\n}\n\n.mt-20[_ngcontent-%COMP%] {\n  margin-top: 50px !important;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav.nav-tabs[_ngcontent-%COMP%] {\n  float: left;\n  display: block;\n  margin-right: 0px;\n  border-bottom: 0;\n  width: 100px;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav.nav-tabs[_ngcontent-%COMP%]   .nav-item[_ngcontent-%COMP%] {\n  margin-bottom: 6px;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav-tabs[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  border: 1px solid transparent;\n  border-top-left-radius: 0.25rem;\n  border-top-right-radius: 0.25rem;\n  background: #fff;\n  padding: 17px 49px;\n  color: #71748d;\n  background-color: #dddde8;\n  border-radius: 4px 0px 0px 4px;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav-tabs[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%] {\n  color: #fff;\n  background-color: #00367e;\n  border-color: transparent !important;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav-tabs[_ngcontent-%COMP%]   .nav-link.active[_ngcontent-%COMP%]::after {\n  content: \"\";\n  position: absolute;\n  right: -10px;\n  \n  top: 50%;\n  transform: translateY(-50%);\n  width: 0;\n  height: 0;\n  border-left: 10px solid #00367e;\n  border-top: 10px solid transparent;\n  border-bottom: 10px solid transparent;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .nav-tabs[_ngcontent-%COMP%]   .nav-link[_ngcontent-%COMP%] {\n  border: 1px solid transparent;\n  border-top-left-radius: 4px !important;\n  border-top-right-radius: 0px !important;\n  position: relative;\n}\n\n.tab-vertical[_ngcontent-%COMP%]   .tab-content[_ngcontent-%COMP%] {\n  overflow-x: hidden;\n  border-radius: 0px 4px 4px 4px;\n  background: #fff;\n  padding: 13px;\n  padding-top: 8px;\n}\n\n#candidateModal[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 400px !important;\n  top: 0rem;\n  left: -709px;\n  width: 710px;\n}\n\n#candidateModal[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  height: 430px;\n}\n\n#notes[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 400px !important;\n  top: 0rem;\n  left: -509px;\n  width: 510px;\n}\n\n#notes[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  height: 430px;\n}\n\n#history[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 400px !important;\n  top: 0rem;\n  left: -778px;\n  width: 779px;\n}\n\n#history[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  height: 430px;\n  padding: 7px 15px;\n}\n\n#notes[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  min-height: 400px !important;\n  top: 0rem;\n  left: -578px;\n  width: 579px;\n}\n\n#notes[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%]   .modal-body[_ngcontent-%COMP%] {\n  height: 430px;\n  padding: 7px 15px;\n}\n\n.modal-dialog-slideout[_ngcontent-%COMP%] {\n  position: fixed;\n  margin: 0;\n  right: 0;\n  height: 100%;\n  transform: translate3d(100%, 0, 0);\n}\n\n.modal-dialog-slideout[_ngcontent-%COMP%]   .modal-content[_ngcontent-%COMP%] {\n  height: 100vh;\n  overflow-y: auto;\n}\n\n.modal.show[_ngcontent-%COMP%]   .modal-dialog-slideout[_ngcontent-%COMP%] {\n  transform: translate3d(0, 0, 0);\n}\n\n.modal.fade[_ngcontent-%COMP%]   .modal-dialog[_ngcontent-%COMP%] {\n  transition: transform 0.3s ease-out;\n}\n\n.icon-container[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n}\n\n.icon-item[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  margin-right: 20px;\n}\n\n.icon[_ngcontent-%COMP%] {\n  font-size: 24px;\n  margin-right: 1px;\n  cursor: pointer;\n  color: #757575;\n}\n\n.icon-label[_ngcontent-%COMP%] {\n  font-size: 16px;\n  color: #555;\n}\n\n.progress-container[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  align-items: flex-start;\n}\n\n.progress-title[_ngcontent-%COMP%] {\n  font-size: 13px;\n  font-weight: bold;\n  margin-bottom: 10px;\n}\n\n.progress-line[_ngcontent-%COMP%] {\n  position: relative;\n  width: 7px;\n  background-color: #ddd;\n  flex-grow: 1;\n  border-radius: 5px;\n  margin-bottom: 27px;\n}\n\n.progress[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  background-color: #ff6600;\n  top: 0;\n}\n\n.step[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: flex-start;\n  margin-bottom: 23px;\n  position: relative;\n  font-size: 15px;\n}\n\n.step[_ngcontent-%COMP%]   .bullet[_ngcontent-%COMP%] {\n  width: 20px;\n  height: 20px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  color: #fff;\n  font-weight: bold;\n  position: absolute;\n  z-index: 1;\n  opacity: 1;\n}\n\n.step[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%] {\n  margin-left: 14px;\n}\n\n.step[_ngcontent-%COMP%]   .details[_ngcontent-%COMP%]   div[_ngcontent-%COMP%] {\n  margin-bottom: 5px;\n}\n\n.secondary-skill-ellipsis[_ngcontent-%COMP%] {\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  max-width: 172px;\n  vertical-align: top;\n}\n\n.notes-progress-line[_ngcontent-%COMP%] {\n  position: relative;\n  width: 8px;\n  background-color: #ddd;\n  border-radius: 5px;\n  margin-bottom: 21px;\n}\n\n.notes-progress[_ngcontent-%COMP%] {\n  position: absolute;\n  width: 100%;\n  background-color: #ff6600;\n  top: 0;\n  height: 100%;\n  border-radius: 7px;\n}\n\n.modal-close-btn[_ngcontent-%COMP%] {\n  height: 18px;\n  cursor: pointer;\n}\n\n.status-edit[_ngcontent-%COMP%] {\n  font-size: 16px;\n}\n\n.circle-arrow[_ngcontent-%COMP%] {\n  position: relative;\n  width: 50px;\n  height: 50px;\n  border-radius: 50%;\n  border: 2px solid #000;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.circle-arrow[_ngcontent-%COMP%]   .bx-right-arrow-alt[_ngcontent-%COMP%] {\n  position: absolute;\n}\n\n.open-roles-details[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 343px;\n  overflow-y: hidden;\n}\n\n.dashboard-details[_ngcontent-%COMP%] {\n  display: flex;\n  flex-direction: column;\n  height: 374px;\n  overflow-y: hidden;\n}\n\n.form-details[_ngcontent-%COMP%] {\n  height: 31px;\n  font-size: 13px;\n}\n\nlabel[_ngcontent-%COMP%] {\n  height: 13px;\n}\n\n.text-desc[_ngcontent-%COMP%] {\n  font-size: 13px;\n  background-color: #ffffff;\n  resize: none;\n}\n\n.notes-border[_ngcontent-%COMP%] {\n  border: none;\n}\n\n.note-date[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n\n.details[_ngcontent-%COMP%] {\n  font-size: 13px;\n}\n\n.dialog-container[_ngcontent-%COMP%] {\n  position: relative;\n  background: white;\n  \n  border: 1px solid #ccc;\n  border-radius: 4px;\n  padding: 10px;\n}\n\n\n\n.dialog-container[_ngcontent-%COMP%] {\n  top: 100%;\n  left: 0;\n  transform: translateY(5px);\n}\n\n.badge[_ngcontent-%COMP%] {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 40px;\n  \n  height: 40px;\n  \n  border-radius: 50%;\n  background-color: #3498db;\n  \n  color: white;\n  \n  font-size: 16px;\n  \n  font-weight: bold;\n  \n}\n\n.badge-text[_ngcontent-%COMP%] {\n  text-transform: uppercase;\n  \n}\n\n.contact[_ngcontent-%COMP%] {\n  color: var(--White-col, #FFF);\n  font-family: Poppins, sans-serif;\n  font-size: 13px;\n  font-style: normal;\n  font-weight: 400;\n  margin-right: 20px;\n  line-height: 36px;\n  \n  padding-left: 79px;\n}\n\n.matTab[_ngcontent-%COMP%] {\n  margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvam9iLW1vYmlsaXR5L2pvYi1tb2JpbGl0eS5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGtCQUFBO0FBQ0Y7O0FBQ0E7RUFFRSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLDRCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUNBO0VBQ0Usa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBRUY7O0FBQUE7RUFDRSxhQUFBO0VBQ0EsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7QUFHRjs7QUFBQTtFQUNFLGVBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtBQUdGOztBQUFBO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFHRjs7QUFBQTtFQUNFLGlCQUFBO0VBQ0EsaUJBQUE7QUFHRjs7QUFBQTtFQUNFLGFBQUE7QUFHRjs7QUFBQTtFQUNFO0lBQ0UsaUJBQUE7SUFDQSxpQkFBQTtFQUdGOztFQUFBO0lBQ0UsYUFBQTtFQUdGO0FBQ0Y7O0FBQUE7RUFDRSxjQUFBO0VBRUEscUJBQUE7QUFDRjs7QUFFQTtFQUNFLDJCQUFBO0VBQ0EsNkJBQUE7RUFDQSxtQkFBQTtBQUNGOztBQUVBO0VBQ0UsZ0JBQUE7QUFDRjs7QUFDQTtFQUNBLHNDQUFBO0VBQ0Esb0JBQUE7RUFDQSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGlCQUFBO0VBQW1CLGFBQUE7QUFHbkI7O0FBREE7RUFJRSxlQUFBO0VBRUEsNEJBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUFBRjs7QUFLQTtFQUlFLFdBQUE7QUFMRjs7QUFPQTtFQUNFLHNCQUFBO0FBSkY7O0FBTUE7RUFDRSxlQUFBO0VBQ0EsMkJBQUE7RUFDQSw0QkFBQTtFQUNBLGdCQUFBO0FBSEY7O0FBTUE7RUFDRSxnQkFBQTtBQUhGOztBQU1BO0VBSUUsZUFBQTtBQU5GOztBQVFBO0VBRUUsdUNBQUE7QUFORjs7QUFRQTtFQUNFLG1CQUFBO0FBTEY7O0FBUUE7RUFHRSw2QkFBQTtBQVBGOztBQVVBO0VBQ0UsaUJBQUE7QUFQRjs7QUFVQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsK0NBQUE7RUFDQSxrQkFBQTtFQUNBLFVBQUE7QUFQRjs7QUFVQTtFQUNFLHlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQ0FBQTtFQUNBLGFBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBUEY7O0FBVUE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsdUJBQUE7RUFDQSxxQkFBQTtFQUNBLFlBQUE7QUFQRjs7QUFVQTtFQUNFLGtDQUFBO0VBQ0EsWUFBQTtBQVBGOztBQVVBO0VBQ0UsYUFBQTtBQVBGOztBQVVBO0VBQ0UsV0FBQTtBQVBGOztBQVVBO0VBQ0UscUJBQUE7RUFDQSxnREFBQTtBQVBGOztBQVVBO0VBRUUsY0FBQTtBQVJGOztBQVdBO0VBQ0UsZ0JBQUE7RUFDQSxvQ0FBQTtFQUNBLGlDQUFBO0VBQ0Esa0JBQUE7RUFFQSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0FBVEY7O0FBYUE7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxlQUFBO0FBVkY7O0FBYUE7RUFDRSxpQkFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxhQUFBO0FBVkY7O0FBYUE7RUFDRSxXQUFBO0FBVkY7O0FBY0E7RUFDRSxtQkFBQTtBQVhGOztBQWNBO0VBQ0UsVUFBQTtFQUNBLGVBQUE7QUFYRjs7QUFjQTtFQUNFLG1CQUFBO0VBQ0EsVUFBQTtBQVhGOztBQWNBO0VBQ0UsWUFBQTtFQUNBLDBCQUFBO0VBQ0EsZ0JBQUE7RUFDQSw2QkFBQTtFQUNBLHFCQUFBO0VBQ0EsdUJBQUE7RUFDQSwwQkFBQTtBQVhGOztBQWNBO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0FBWEY7O0FBY0E7RUFDRSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFYRjs7QUFxQkE7RUFDRSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsMkJBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsZ0JBQUE7RUFDQSxtQkFBQTtFQUNBLG9CQUFBO0VBQ0EsbUJBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0FBbEJGOztBQXFCQTtFQUNFLFVBQUE7RUFDQSxrQkFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQWxCRjs7QUFxQkE7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0VBQ0EsMkJBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0FBbEJGOztBQXFCQTtFQUNFLFlBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7QUFsQkY7O0FBcUJBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFFQSxlQUFBO0VBQ0Esa0JBQUE7QUFuQkY7O0FBc0JBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBRUEsZUFBQTtFQUNBLGlDQUFBO0FBcEJGOztBQXVCQTtFQUNFLDBCQUFBO0VBQ0EsWUFBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtBQXBCRjs7QUFzQkE7RUFDRSxtQkFBQTtBQW5CRjs7QUF1QkE7RUFDRSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxvQkFBQTtBQXBCRjs7QUFzQkE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtFQUNBLG9EQUFBO0VBQUEsNENBQUE7RUFBQSwwRUFBQTtBQW5CRjs7QUFzQkE7RUFDRSxXQUFBO0VBQ0EsMEJBQUE7QUFuQkY7O0FBc0JBO0VBQ0UsMEJBQUE7RUFDQSxZQUFBO0FBbkJGOztBQXNCQTtFQUNFLGVBQUE7RUFDQSxnQkFBQTtFQUNBLHNCQUFBO0FBbkJGOztBQXlCQTtFQUNFLDJCQUFBO0VBQ0EsOEJBQUE7QUF0QkY7O0FBd0JBO0VBQ0UsNEJBQUE7RUFDQSwrQkFBQTtBQXJCRjs7QUF1QkE7RUFDRSxnQkFBQTtFQUNBLGVBQUE7QUFwQkY7O0FBdUJBO0VBQ0UsaUJBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUFwQkY7O0FBdUJBO0VBQ0Usa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsWUFBQTtBQXBCRjs7QUF1QkE7RUFDRSxXQUFBO0VBQ0EsZUFBQTtBQXBCRjs7QUF1QkE7RUFDRSxXQUFBO0VBQ0EsMEJBQUE7QUFwQkY7O0FBdUJBO0VBQ0UsWUFBQTtFQUNBLDZDQUFBO0FBcEJGOztBQXVCQTtFQUNFLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0YsMENBQUE7RUFFQSxrREFBQTtFQUNFLGVBQUE7QUFyQkY7O0FBd0JBOztFQUVFLFdBQUE7RUFDQSxxQkFBQTtFQUNBLDJCQUFBO0FBckJGOztBQXdCQTtFQUNFLFlBQUE7RUFDQSwyQkFBQTtFQUNBLGVBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsUUFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsYUFBQTtFQUNBLGFBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0Esc0JBQUE7RUFDQSw0QkFBQTtFQUNBLHFDQUFBO0VBQ0Esc0JBQUE7QUFyQkY7O0FBd0JBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUFyQkY7O0FBd0JBO0VBQ0Usa0JBQUE7RUFDQSxNQUFBO0VBQ0EsT0FBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxhQUFBO0FBckJGOztBQXlCQTtFQUNFLGtCQUFBO0VBQ0Esa0JBQUE7QUF0QkY7O0FBeUJBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLGdDQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsZ1dBQUE7RUFPQSwyQ0FBQTtVQUFBLG1DQUFBO0FBNUJGOztBQStCQTtFQUNFO0lBQ0UsdUJBQUE7RUE1QkY7RUErQkE7SUFDRSx5QkFBQTtFQTdCRjtBQUNGOztBQXNCQTtFQUNFO0lBQ0UsdUJBQUE7RUE1QkY7RUErQkE7SUFDRSx5QkFBQTtFQTdCRjtBQUNGOztBQWdDQTtFQUNFLG1CQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsbUJBQUE7QUE5QkY7O0FBaUNBO0VBQ0Usa0JBQUE7RUFDQSxxQkFBQTtBQTlCRjs7QUFpQ0E7RUFDRSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxzQkFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLGFBQUE7RUFDQSxTQUFBO0VBQ0EsMkJBQUE7RUFDQSxVQUFBO0VBQ0Esd0JBQUE7QUE5QkY7O0FBaUNBO0VBQ0UsbUJBQUE7RUFDQSxVQUFBO0FBOUJGOztBQWdDQTtFQUNFLGtCQUFBO0FBN0JGOztBQWdDQTtFQUNFLGtCQUFBO0VBQ0EsTUFBQTtFQUNBLE9BQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtFQUNBLHNCQUFBO0VBQXdCLGlDQUFBO0FBNUIxQjs7QUErQkE7RUFDRSxrQkFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7RUFDQSxzQkFBQTtFQUF3QixpQ0FBQTtBQTNCMUI7O0FBOEJBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtBQTNCRjs7QUE2QkE7RUFDRSxrQkFBQTtBQTFCRjs7QUE2QkE7RUFDRSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxRQUFBO0VBQ0EsU0FBQTtFQUNBLHVCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5Q0FBQTtFQUNBLGFBQUE7RUFDQSxVQUFBO0VBQ0Esc0JBQUE7RUFDQSxrQkFBQTtBQTFCRjs7QUE2QkE7RUFDRSxTQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUExQkY7O0FBNkJBO0VBQ0UsY0FBQTtFQUNBLGVBQUE7QUExQkY7O0FBNkJBLGtCQUFBOztBQUNBO0VBQ0UsY0FBQTtBQTFCRjs7QUE2QkE7RUFDRSxrQkFBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtBQTFCRjs7QUE2QkE7RUFFRSxZQUFBO0VBQ0Esc0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtFQUNBLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxhQUFBO0VBQ0EsMkJBQUE7RUFDQSxVQUFBO0VBQ0Esd0JBQUE7RUFDQSx1QkFBQTtBQTNCRjs7QUE2Q0E7RUFDRSxnQ0FBQTtBQTFDRjs7QUE0Q0E7RUFDRSwyQkFBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0FBekNGOztBQTJDQTtFQUNBLGFBQUE7RUFDQSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxtQkFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7QUF4Q0E7O0FBMENBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsYUFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxtQkFBQTtBQXZDQTs7QUF5Q0E7RUFDRSxhQUFBO0VBQ0Ysc0JBQUE7RUFDQSx1QkFBQTtBQXRDQTs7QUF3Q0E7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBRUEsbUJBQUE7RUFDQSxtQkFBQTtBQXRDRjs7QUF3Q0E7RUFDQSw2QkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFyQ0E7O0FBdUNBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsdUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUFwQ0E7O0FBdUNBO0VBQ0Esa0JBQUE7RUFDQSw4Q0FBQTtFQUNBLGlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBQXBDQTs7QUFzQ0E7RUFDRSxrQkFBQTtFQUNBLGVBQUE7RUFDRSxlQUFBO0VBQ0EsYUFBQTtFQUNGLGNBQUE7RUFDQSxnR0FBQTtBQW5DRjs7QUFxQ0E7RUFDQSw2QkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFFQSxpQkFBQTtFQUFtQixTQUFBO0VBQ25CLGtCQUFBO0FBbENBOztBQW9DQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtFQUNGLGlCQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtFQUNBLFNBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7QUFqQ0E7O0FBbUNBO0VBRUUsWUFBQTtFQUdBLFlBQUE7RUFDQSxrQkFBQTtBQW5DRjs7QUFxQ0E7RUFDRSxxQkFBQTtFQUF1QixnQ0FBQTtFQUN2QiwyQkFBQTtFQUE2QixnQ0FBQTtFQUM3Qiw4QkFBQTtFQUNBLDBCQUFBO0VBQTRCLCtCQUFBO0VBQzVCLDZCQUFBO0VBQ0EsaUJBQUE7QUEvQkY7O0FBa0NBO0VBQ0Usa0JBQUE7RUFDQSxRQUFBO0VBQ0EsTUFBQTtFQUNBLFVBQUE7RUFDQSxnQkFBQTtBQS9CRjs7QUFvQ0E7RUFDRSxZQUFBO0VBQ0EsZUFBQTtBQWpDRjs7QUFtQ0E7RUFLRSw0QkFBQTtFQUNBLG9CQUFBO0VBQ0EsaUNBQUE7RUFDQSxzQkFBQTtFQUNBLHVCQUFBO0VBQ0EsMEJBQUE7QUFwQ0Y7O0FBc0NBO0VBQ0UsMkJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUFuQ0Y7O0FBcUNBO0VBQ0UsZUFBQTtFQUNBLE1BQUE7RUFDQSxPQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFFQSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtBQW5DRjs7QUFzQ0E7RUFDRSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHlDQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBbkNGOztBQXNDQTtFQUNFLG1CQUFBO0FBbkNGOztBQXNDQTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7QUFuQ0Y7O0FBc0NBO0VBQ0UsYUFBQTtFQUNBLFlBQUE7QUFuQ0Y7O0FBc0NBO0VBQ0UsaUJBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFuQ0Y7O0FBc0NBO0VBQ0UsZUFBQTtFQUNBLGVBQUE7QUFuQ0Y7O0FBcUNBO0VBQ0UsMkJBQUE7QUFsQ0Y7O0FBb0NBO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsdUJBQUE7RUFDQSxRQUFBO0VBQ0EsVUFBQTtBQWpDRjs7QUFtQ0E7RUFDRSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EscUJBQUE7RUFDQSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSw4QkFBQTtFQUNBLGlCQUFBO0FBaENGOztBQWtDQTtFQUNFLGFBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7QUEvQkY7O0FBa0NBO0VBQ0UsY0FBQTtBQS9CRjs7QUFrQ0E7RUFDRSxhQUFBO0VBQ0EsOEJBQUE7RUFDQSxlQUFBO0FBL0JGOztBQWtDQTtFQUNFLGtCQUFBO0FBL0JGOztBQWtDQTtFQUNFLFNBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7QUEvQkY7O0FBa0NBO0VBQ0UsU0FBQTtBQS9CRjs7QUFpQ0E7RUFDRSxjQUFBO0VBQ0EsZUFBQTtBQTlCRjs7QUFnQ0E7RUFDRSwrQkFBQTtFQUNBLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtBQTdCRjs7QUErQkU7RUFDRSx5Q0FBQTtFQUNGLG9CQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0VBQ0EsMkRBQUE7QUE1QkY7O0FBOEJFO0VBQ0Usc0NBQUE7RUFDRixvQkFBQTtFQUNBLGVBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFBbUIsV0FBQTtBQTFCckI7O0FBOEJFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FBM0JKOztBQThCRTtFQUNFLFVBQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLDJCQUFBO0VBQ0EsWUFBQTtBQTNCSjs7QUE4QkU7RUFDRSxRQUFBO0VBQ0EsVUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0FBM0JKOztBQTZCRTtFQUNFLE9BQUE7RUFDQSwyQkFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxnQkFBQTtBQTFCSjs7QUE0QkU7RUFDRSwyQkFBQTtBQXpCSjs7QUErQkU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsY0FBQTtFQUNBLHlCQUFBO0VBQ0EsaUNBQUE7RUFDQSxlQUFBO0FBNUJKOztBQThCRTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtBQTNCSjs7QUE2QkU7RUFDRSxrQkFBQTtBQTFCSjs7QUE0QkU7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7QUF6Qko7O0FBMkJFO0VBRUUsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFlBQUE7QUF6Qko7O0FBOEJFO0VBQ0UsZ0NBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUNBLG1DQUFBO0FBM0JKOztBQThCQTtFQUNJLDJCQUFBO0FBM0JKOztBQThCQTtFQUNJLFdBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7QUEzQko7O0FBOEJBO0VBQ0ksa0JBQUE7QUEzQko7O0FBOEJBO0VBQ0ksNkJBQUE7RUFDQSwrQkFBQTtFQUNBLGdDQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGNBQUE7RUFDQSx5QkFBQTtFQUdBLDhCQUFBO0FBM0JKOztBQThCQTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtFQUNBLG9DQUFBO0FBM0JGOztBQStCQTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFBYyxnQ0FBQTtFQUNkLFFBQUE7RUFDQSwyQkFBQTtFQUNBLFFBQUE7RUFDQSxTQUFBO0VBQ0EsK0JBQUE7RUFDQSxrQ0FBQTtFQUNBLHFDQUFBO0FBM0JGOztBQThCQTtFQUNJLDZCQUFBO0VBQ0Esc0NBQUE7RUFDQSx1Q0FBQTtFQUNBLGtCQUFBO0FBM0JKOztBQThCQTtFQUNJLGtCQUFBO0VBR0EsOEJBQUE7RUFDQSxnQkFBQTtFQUNBLGFBQUE7RUFDQSxnQkFBQTtBQTNCSjs7QUE2QkE7RUFDRSw0QkFBQTtFQUlBLFNBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQTdCRjs7QUF3QkU7RUFDRSxhQUFBO0FBdEJKOztBQTRCQTtFQUNFLDRCQUFBO0VBSUEsU0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBNUJGOztBQXVCRTtFQUNFLGFBQUE7QUFyQko7O0FBMkJBO0VBQ0UsNEJBQUE7RUFLQSxTQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUE1QkY7O0FBc0JFO0VBQ0UsYUFBQTtFQUNBLGlCQUFBO0FBcEJKOztBQTBCQTtFQUNFLDRCQUFBO0VBS0EsU0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBM0JGOztBQXFCRTtFQUNFLGFBQUE7RUFDQSxpQkFBQTtBQW5CSjs7QUEwQkE7RUFDRSxlQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxZQUFBO0VBQ0Esa0NBQUE7QUF2QkY7O0FBMEJBO0VBQ0UsYUFBQTtFQUNBLGdCQUFBO0FBdkJGOztBQTBCQTtFQUNFLCtCQUFBO0FBdkJGOztBQTBCQTtFQUNFLG1DQUFBO0FBdkJGOztBQTBCQTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtBQXZCRjs7QUEwQkE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQXZCRjs7QUEwQkE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBQXZCRjs7QUEwQkE7RUFDRSxlQUFBO0VBQ0EsV0FBQTtBQXZCRjs7QUEwQkE7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSx1QkFBQTtBQXZCRjs7QUEyQkE7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxtQkFBQTtBQXhCRjs7QUEyQkE7RUFDRSxrQkFBQTtFQUNBLFVBQUE7RUFDQSxzQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FBeEJGOztBQTJCQTtFQUNFLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLHlCQUFBO0VBQ0EsTUFBQTtBQXhCRjs7QUEyQkE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZUFBQTtBQXhCRjs7QUEyQkE7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUVBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxVQUFBO0VBQ0EsVUFBQTtBQXpCRjs7QUE0QkE7RUFDRSxpQkFBQTtBQXpCRjs7QUE0QkE7RUFDRSxrQkFBQTtBQXpCRjs7QUEyQkE7RUFDRSxtQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxnQkFBQTtFQUNBLG1CQUFBO0FBeEJGOztBQTJCQTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLHNCQUFBO0VBRUEsa0JBQUE7RUFDQSxtQkFBQTtBQXpCRjs7QUE0QkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLE1BQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUF6QkY7O0FBMkJBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUF4QkY7O0FBMEJBO0VBQ0UsZUFBQTtBQXZCRjs7QUF5QkE7RUFDRSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0FBdEJGOztBQXlCQTtFQUNFLGtCQUFBO0FBdEJGOztBQXdCQTtFQUNFLGFBQUE7RUFDQSxzQkFBQTtFQUNBLGFBQUE7RUFDQSxrQkFBQTtBQXJCRjs7QUF1QkE7RUFDRSxhQUFBO0VBQ0Esc0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7QUFwQkY7O0FBMkJBO0VBQ0UsWUFBQTtFQUNBLGVBQUE7QUF4QkY7O0FBMEJBO0VBQ0UsWUFBQTtBQXZCRjs7QUF5QkE7RUFDRSxlQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBdEJGOztBQXdCQTtFQUNFLFlBQUE7QUFyQkY7O0FBdUJBO0VBQ0UsZUFBQTtBQXBCRjs7QUFzQkE7RUFDRSxlQUFBO0FBbkJGOztBQXFCQTtFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFBbUIsdUNBQUE7RUFDbkIsc0JBQUE7RUFDQSxrQkFBQTtFQUNBLGFBQUE7QUFqQkY7O0FBcUJBLDJCQUFBOztBQUNBO0VBQ0UsU0FBQTtFQUNBLE9BQUE7RUFDQSwwQkFBQTtBQWxCRjs7QUFvQkE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7RUFBYSwwQkFBQTtFQUNiLFlBQUE7RUFBYywwQkFBQTtFQUNkLGtCQUFBO0VBQ0EseUJBQUE7RUFBMkIsMkJBQUE7RUFDM0IsWUFBQTtFQUFjLGVBQUE7RUFDZCxlQUFBO0VBQWlCLGNBQUE7RUFDakIsaUJBQUE7RUFBbUIsZ0JBQUE7QUFYckI7O0FBY0E7RUFDRSx5QkFBQTtFQUEyQixpQ0FBQTtBQVY3Qjs7QUFpQkE7RUFDRSw2QkFBQTtFQUNBLGdDQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0VBQWtCLFNBQUE7RUFDbEIsa0JBQUE7QUFiRjs7QUFnQkE7RUFDRSxnQkFBQTtBQWJGIiwiZmlsZSI6InNyYy9hcHAvam9iLW1vYmlsaXR5L2pvYi1tb2JpbGl0eS5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXItZmx1aWR7XHJcbiAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG59XHJcbi5iYW5uZXItc2VjdGlvbiB7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogIzEzM0I5MztcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzNjdlO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMTAwJTtcclxuICBtaW4taGVpZ2h0OiAxNzJweDtcclxuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgbWFyZ2luLWxlZnQ6IC0yNnB4O1xyXG4gIG1hcmdpbi1yaWdodDogLTI2cHg7XHJcbn1cclxuLmp1bXAtaGVhZGVye1xyXG4gIHBhZGRpbmctbGVmdDogMzRweDtcclxuICBwYWRkaW5nLXRvcDoyOXB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBmb250LXNpemU6IDM0cHg7XHJcbn1cclxuLmltZy10YWcge1xyXG4gIGhlaWdodDogMTM0cHg7XHJcbiAgd2lkdGg6IDEwMiU7XHJcbiAgbWFyZ2luLWxlZnQ6IC02OHB4O1xyXG4gIG1hcmdpbi10b3A6IDE2cHg7XHJcbn1cclxuXHJcbi5mb250LXNpemUtMThwIHtcclxuICBmb250LXNpemU6IDE4cHg7XHJcbn1cclxuXHJcbi5mb250LXNpemUtMTZwIHtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbn1cclxuXHJcbi5mb250LXNpemUtMTRwIHtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbn1cclxuXHJcbi5mb250LXNpemUtMTJwIHtcclxuICBmb250LXNpemU6IDEycHg7XHJcbn1cclxuXHJcbi5mb250LXNpemUtMTBwIHtcclxuICBmb250LXNpemU6IDEwcHg7XHJcbn1cclxuXHJcbi5sb2FkZXJEaXYge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICB0b3A6IDYwJTtcclxuICBsZWZ0OiA1NSU7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUoLTUwJSwgLTUwJSk7XHJcbiAgZm9udC1zaXplOiA2MHB4O1xyXG59XHJcblxyXG4uY2VudGVyTG9hZGVyIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jYXJkLWltZy1oZWlnaHQge1xyXG4gIG1pbi1oZWlnaHQ6IDIxMHB4O1xyXG4gIG1heC1oZWlnaHQ6IDIxMXB4O1xyXG59XHJcblxyXG4uY2FudmFzLWhlaWdodCB7XHJcbiAgaGVpZ2h0OiAyMTBweDtcclxufVxyXG5cclxuQG1lZGlhIChtaW4td2lkdGg6IDE5MDBweCkge1xyXG4gIC5jYXJkLWltZy1oZWlnaHQge1xyXG4gICAgbWluLWhlaWdodDogMjQzcHg7XHJcbiAgICBtYXgtaGVpZ2h0OiAyNDVweDtcclxuICB9XHJcblxyXG4gIC5jYW52YXMtaGVpZ2h0IHtcclxuICAgIGhlaWdodDogMjQ1cHg7XHJcbiAgfVxyXG59XHJcblxyXG4uY2F0ZWdvcnlUYWJzIGEge1xyXG4gIGNvbG9yOiAjYTdhN2E3O1xyXG4gIDtcclxuICB0ZXh0LWRlY29yYXRpb246IG5vbmU7XHJcbn1cclxuXHJcbi5jYXRlZ29yeVRhYnMgYS5hY3RpdmUge1xyXG4gIGNvbG9yOiB2YXIoLS1vbi1iYWNrZ3JvdW5kKTtcclxuICBib3JkZXItYm90dG9tOiAycHggc29saWQgI2Y2MDtcclxuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG4udGFibGUgdGhlYWQge1xyXG4gIHRleHQtYWxpZ246IGxlZnQ7XHJcbn1cclxuLnRleHQtanVzdGlmeXtcclxuY29sb3I6IHZhcigtLUJvZHktdGV4dC1jb2xvciwgIzIzMUYyMCk7XHJcbmZvbnQtZmFtaWx5OiBQb3BwaW5zO1xyXG5mb250LXNpemU6IDE1cHg7XHJcbmZvbnQtc3R5bGU6IG5vcm1hbDtcclxuZm9udC13ZWlnaHQ6IDQwMDtcclxubGluZS1oZWlnaHQ6IDIycHg7IC8qIDEyMi4yMjIlICovXHJcbn1cclxuLnRhYmxlIHRoZWFkIHRoIHtcclxuICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tR3JheS0yMDAsICNFNEU3RUMpO1xyXG4gIC8vIGJhY2tncm91bmQ6IHZhcigtLXRhYmxlLWhlYWRlciwgI0Q2RENFMyk7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2Y0ZjhmYjtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI0UxRjNGRjtcclxuICBjb2xvcjogdmFyKC0tY2xpZW50bmV3c3RleHQpO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIGJvcmRlcjogbm9uZTtcclxuICAvLyBwYWRkaW5nOiAyOHB4O1xyXG4gIC8vIGJvcmRlci1yaWdodDogMC41cHggc29saWQgdmFyKC0tdXNlci10YWJsZSk7XHJcbiAgLy8gYm9yZGVyLWJvdHRvbTogMC41cHggc29saWQgdmFyKC0tdXNlci10YWJsZSk7XHJcbn1cclxuLnRhYmxlIHRoZWFkIHRoIDpob3ZlcntcclxuICAvLyBib3JkZXItYm90dG9tOiAxcHggc29saWQgdmFyKC0tR3JheS0yMDAsICNFNEU3RUMpO1xyXG4gIC8vIGJhY2tncm91bmQ6IHZhcigtLWQtOS1kLTktZC05LCAjRDFFMUY0KTtcclxuICAvLyBiYWNrZ3JvdW5kOiAjMDAzNjdlZGI7XHJcbiAgY29sb3I6ICNmZmY7XHJcbn1cclxuLnRhYmxlIHRoZWFkIHRyOmhvdmVye1xyXG4gIGJhY2tncm91bmQtY29sb3I6IG5vbmU7XHJcbn1cclxuLnRoLXRpdGxlIHtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0tdGFibGUtYmcpO1xyXG4gIGNvbG9yOiB2YXIoLS1jbGllbnRuZXdzdGV4dCk7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxufVxyXG5cclxuLnRhYmxlIHRib2R5IHtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG59XHJcblxyXG50ZCB7XHJcbiAgLy8gcGFkZGluZy1sZWZ0OiAyOXB4ICFpbXBvcnRhbnQ7XHJcbiAgLy8gYm9yZGVyLXJpZ2h0OiAwLjVweCBzb2xpZCB2YXIoLS11c2VyLXRhYmxlKTtcclxuICAvLyBib3JkZXItdG9wOiAwLjVweCBzb2xpZCB2YXIoLS11c2VyLXRhYmxlKTtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxudGFibGUgdGJvZHkgdHI6aG92ZXIge1xyXG4gIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1HcmF5LTIwMCwgI0U0RTdFQyk7XHJcbiAgYmFja2dyb3VuZDogdmFyKC0tZC05LWQtOS1kLTksICNEMUUxRjQpO1xyXG59XHJcbnRhYmxlIHRye1xyXG4gIGJhY2tncm91bmQ6ICNmZmZmZmY7XHJcbiAgLy8gYm9yZGVyLWJvdHRvbTogNXB4IHNvbGlkICNmNGY4ZmJcclxufVxyXG50YWJsZVxyXG5cclxuLm1hdC10YWItYm9keS1jb250ZW50IHtcclxuICBvdmVyZmxvdy14OiBoaWRkZW4gIWltcG9ydGFudDtcclxufVxyXG5cclxuLnJvdy5tYXRUYWIge1xyXG4gIG1pbi1oZWlnaHQ6IDIwMHB4O1xyXG59XHJcblxyXG4uYmFkZ2VTdGF0dXMge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBwYWRkaW5nOiAxcHggM3B4O1xyXG4gIHdpZHRoOiA5OCU7XHJcbiAgYmFja2dyb3VuZDogIzFhODFmZiAwJSAwJSBuby1yZXBlYXQgcGFkZGluZy1ib3g7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIG9wYWNpdHk6IDE7XHJcbn1cclxuXHJcbi5kZXRhaWxzLWJ1dHRvbiB7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjlmYTtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgdHJhbnNpdGlvbjogYmFja2dyb3VuZC1jb2xvciAwLjNzIGVhc2U7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG5zZWxlY3Qge1xyXG4gIHBhZGRpbmc6IDZweDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgaGVpZ2h0OiA0MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IHdoaXRlO1xyXG4gIGJhY2tncm91bmQtc2l6ZTogMTJweDtcclxuICB3aWR0aDogMTUwcHg7XHJcbn1cclxuXHJcbnNlbGVjdCBvcHRpb246aG92ZXIge1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGJsYWNrICFpbXBvcnRhbnQ7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG59XHJcblxyXG5vcHRpb25bZGlzYWJsZWRdIHtcclxuICBkaXNwbGF5OiBub25lO1xyXG59XHJcblxyXG5vcHRpb246aG92ZXIge1xyXG4gIGNvbG9yOiAjY2NjO1xyXG59XHJcblxyXG5zZWxlY3Q6Zm9jdXMge1xyXG4gIGJvcmRlci1jb2xvcjogIzAwN2JmZjtcclxuICBib3gtc2hhZG93OiAwIDAgMCAwLjJyZW0gcmdiYSgwLCAxMjMsIDI1NSwgMC4yNSk7XHJcbn1cclxuXHJcbmE6aG92ZXIge1xyXG4gIC8vIGJvcmRlci1ib3R0b206IDFweCBzb2xpZDtcclxuICBjb2xvcjogIzAwMzY3ZTtcclxufVxyXG5cclxuLm1vZGFsLWNvbnRlbnQge1xyXG4gIGJvcmRlci1yYWRpdXM6IDA7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiYSgwLCAwLCAwLCAuMik7XHJcbiAgYm94LXNoYWRvdzogMHB4IDNweCA2cHggIzAwMDAwMDI5O1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAvLyB0b3A6IDFyZW07XHJcbiAgbGVmdDogLTEwMHB4O1xyXG4gIG1pbi1oZWlnaHQ6IDQyMHB4O1xyXG4gIHdpZHRoOiA4MDBweDtcclxuICAvLyBiYWNrZ3JvdW5kOiB2YXIoLS1ib2R5YmFja2dyb3VuZCk7XHJcbn1cclxuXHJcbi50ZXh0Q29sb3Ige1xyXG4gIG1hcmdpbi1yaWdodDogMTFweDtcclxuICBtYXJnaW4tdG9wOiA5cHg7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG59XHJcblxyXG4ubW9kYWwtYm9keSB7XHJcbiAgcGFkZGluZzogMXB4IDI2cHg7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxuICBvdmVyZmxvdy14OiBoaWRkZW47XHJcbiAgaGVpZ2h0OiA0NTBweDtcclxufVxyXG5cclxuLmZvcm0tY29udHJvbCB7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI0YzRjRGNjtcclxufVxyXG5cclxuLm1iLTMge1xyXG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XHJcbn1cclxuXHJcbi50ZXh0LWRhbmdlciB7XHJcbiAgY29sb3I6IHJlZDtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuXHJcbi5idXR0b24ge1xyXG4gIGJvcmRlci1yYWRpdXM6IDIxcHg7XHJcbiAgd2lkdGg6IDE4JTtcclxufVxyXG5cclxuLmJhZGdlLW9wZW4ge1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBmb250LXNpemU6IDEzcHggIWltcG9ydGFudDtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweCAhaW1wb3J0YW50O1xyXG4gIHdpZHRoOiA5OSUgIWltcG9ydGFudDtcclxuICBoZWlnaHQ6IGF1dG8gIWltcG9ydGFudDtcclxuICBjdXJzb3I6IHBvaW50ZXIgIWltcG9ydGFudDtcclxufVxyXG5cclxuLmZvcm0tZ3JvdXAge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxufVxyXG5cclxuLmNyZWF0ZS1idG4ge1xyXG4gIG1hcmdpbi1yaWdodDogMjNweDtcclxuICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkY2NjAwO1xyXG4gIHdpZHRoOiAxMiU7XHJcbiAgaGVpZ2h0OiAzOXB4O1xyXG59XHJcblxyXG4vLyAuY2xvc2Utc3RhdHVzIHtcclxuLy8gICBmbG9hdDogcmlnaHQ7XHJcbi8vICAgZm9udC1zaXplOiAxNnB4O1xyXG4vLyAgIG1hcmdpbi10b3A6IC0yMnB4O1xyXG4vLyAgIG1hcmdpbi1yaWdodDogMTFweDtcclxuLy8gfVxyXG5cclxuLmVkaXQtYnRuIHtcclxuICBmbG9hdDogcmlnaHQ7XHJcbiAgbWFyZ2luLXRvcDogLTIycHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyM3B4O1xyXG4gIHdpZHRoOiA2JTtcclxufVxyXG5cclxuLmJhZGdlIHtcclxuICBsaW5lLWhlaWdodDogMS41ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5hcHBseS1idG4ge1xyXG4gIHBhZGRpbmctdG9wOiAycHg7XHJcbiAgcGFkZGluZy1ib3R0b206IDJweDtcclxuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDk5Y2M7XHJcbiAgY29sb3I6ICNGM0Y0RjY7XHJcbn1cclxuXHJcbi5jbG9zZS1qb2Ige1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBtYXJnaW4tdG9wOiAzMnB4O1xyXG4gIG1hcmdpbi1yaWdodDogMzJweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwOWM7XHJcbn1cclxuXHJcbi5lZGl0LWpvYiB7XHJcbiAgei1pbmRleDogMTtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgZm9udC1zaXplOiAyM3B4O1xyXG4gIG1hcmdpbi10b3A6IDUycHg7XHJcbiAgbWFyZ2luLWxlZnQ6IDE2OXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnNlYXJjaC1ib3gge1xyXG4gIHBhZGRpbmc6IDhweDtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1zaXplOiAxMnB4O1xyXG4gIHdpZHRoOiAxODBweDtcclxuICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA0cHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogNHB4O1xyXG4gIHBhZGRpbmctYm90dG9tOiAzcHg7XHJcbn1cclxuXHJcbi5zZWFyY2gtaWNvbiB7XHJcbiAgcGFkZGluZzogOHB4O1xyXG4gIGZvbnQtc2l6ZTogMThweDtcclxuICBoZWlnaHQ6IDQwcHg7XHJcbiAgcGFkZGluZy10b3A6IDEycHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzA5YztcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA0cHg7XHJcbiAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDRweDtcclxufVxyXG5cclxuLnBhZ2luYXRpb24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAvLyBnYXA6IDVweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgbWFyZ2luLXJpZ2h0OiAtOXB4O1xyXG59XHJcblxyXG4ucGFnZS1pdGVtIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgd2lkdGg6IDM0cHg7XHJcbiAgaGVpZ2h0OiAzNHB4O1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNkZGQ7XHJcbiAgLy8gYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICB0cmFuc2l0aW9uOiBiYWNrZ3JvdW5kLWNvbG9yIDAuM3M7XHJcbn1cclxuXHJcbi5wYWdlLWl0ZW0uYWN0aXZlIHtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzY3ZWRiO1xyXG4gIGJvcmRlcjogbm9uZTtcclxufVxyXG4ucGFnZS1pdGVtLmRpc2FibGVkIHtcclxuICBjdXJzb3I6IG5vdC1hbGxvd2VkO1xyXG4gIC8vIG9wYWNpdHk6IDAuNTtcclxuICAvLyBwb2ludGVyLWV2ZW50czogbm9uZTtcclxufVxyXG4uZGlzYWJsZWQge1xyXG4gIGN1cnNvcjogbm90LWFsbG93ZWQ7XHJcbiAgb3BhY2l0eTogMC41O1xyXG4gIHBvaW50ZXItZXZlbnRzOiBub25lO1xyXG59XHJcbi5wYWdlLW51bWJlciB7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG4gIGNvbG9yOiAjMDljO1xyXG4gIHRyYW5zaXRpb246IGNvbG9yIDAuM3MsIHRleHQtZGVjb3JhdGlvbiAwLjNzO1xyXG59XHJcblxyXG4ucGFnZS1udW1iZXI6aG92ZXIge1xyXG4gIGNvbG9yOiAjMDljO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG59XHJcblxyXG4ucGFnZS1udW1iZXIuYWN0aXZlIHtcclxuICB0ZXh0LWRlY29yYXRpb246IHVuZGVybGluZTtcclxuICBjb2xvcjogd2hpdGU7XHJcbn1cclxuXHJcbi5wYWdlLWl0ZW0gaSB7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG4gIGNvbG9yOiAjMDAzNjdlZGI7XHJcbiAgdHJhbnNpdGlvbjogY29sb3IgMC4zcztcclxufVxyXG5cclxuLy8gLnBhZ2UtaXRlbSBpOmhvdmVyIHtcclxuLy8gICBjb2xvcjogIzA5YztcclxuLy8gfVxyXG4ucHJldi1wYWdle1xyXG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbn1cclxuLm5leHQtcGFnZXtcclxuICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbn1cclxuLmFzc2lnbmVkLWxhYmVsIHtcclxuICBtYXJnaW4tbGVmdDogMXB4O1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxufVxyXG5cclxuLmFwcGxpY2F0aW9uLXNlYXJjaCB7XHJcbiAgbWFyZ2luLXJpZ2h0OiA3cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxuICBtYXJnaW4tdG9wOiAzcHg7XHJcbn1cclxuXHJcbi5pbXBvcnQtYnRuIHtcclxuICBtYXJnaW4tcmlnaHQ6IDIzcHg7XHJcbiAgbWFyZ2luLXRvcDogMzFweDtcclxuICBwYWRkaW5nLXRvcDogNnB4O1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjRkY2NjAwO1xyXG4gIGhlaWdodDogMzlweDtcclxufVxyXG5cclxuLnRyLWRldGFpbHMge1xyXG4gIGNvbG9yOiAjMDljO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLnRyLWRldGFpbHM6aG92ZXIge1xyXG4gIGNvbG9yOiAjMDljO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG59XHJcblxyXG4uc2F2ZS1idG4ge1xyXG4gIGNvbG9yOndoaXRlO1xyXG4gIGJhY2tncm91bmQ6IHZhcigtLUNsb3VkUHJpbWFyeS1CbHVlLCAjMUE2QUM5KTtcclxufVxyXG5cclxuLmlucHV0LWRyb3Bkb3duIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDljO1xyXG4gIGNvbG9yOiB3aGl0ZTtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbmJvcmRlcjogMXB4IHNvbGlkIHZhcigtLUdyYXktMzAwLCAjRDBENUREKTtcclxuLy8gYmFja2dyb3VuZDogdmFyKC0tYnV0dG9uLWNvbCwgI0U2RUZGQyk7XHJcbmJveC1zaGFkb3c6IDBweCAxcHggMnB4IDBweCByZ2JhKDE2LCAyNCwgNDAsIDAuMDUpO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmRyb3Bkb3duLWl0ZW0uYWN0aXZlLFxyXG4uZHJvcGRvd24taXRlbTphY3RpdmUge1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAzNjdlZGI7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1pdGVtOmhvdmVyIHtcclxuICBjb2xvcjogd2hpdGU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzY3ZWRiO1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxufVxyXG5cclxuLmlucHV0LWdyb3VwIC5kcm9wZG93bi1tZW51IHtcclxuICB0b3A6IDkzJTtcclxuICBsZWZ0OiAwO1xyXG4gIHJpZ2h0OiAwO1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbiAgZGlzcGxheTogbm9uZTtcclxuICBmbG9hdDogbGVmdDtcclxuICBtaW4td2lkdGg6IDEwcmVtO1xyXG4gIHBhZGRpbmc6IC41cmVtIDA7XHJcbiAgbWFyZ2luOiAuMTI1cmVtIDAgMDtcclxuICBmb250LXNpemU6IDFyZW07XHJcbiAgY29sb3I6ICMyMTI1Mjk7XHJcbiAgdGV4dC1hbGlnbjogbGVmdDtcclxuICBsaXN0LXN0eWxlOiBub25lO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbiAgYmFja2dyb3VuZC1jbGlwOiBwYWRkaW5nLWJveDtcclxuICBib3JkZXI6IDFweCBzb2xpZCByZ2JhKDAsIDAsIDAsIC4xNSk7XHJcbiAgYm9yZGVyLXJhZGl1czogLjI1cmVtO1xyXG59XHJcblxyXG4uaW5wdXQtZ3JvdXAgLmRyb3Bkb3duLW1lbnUuc2hvdyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcblxyXG4ubG9hZGVyLWJhY2tncm91bmQge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDEwMCU7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIHotaW5kZXg6IDEwMDA7XHJcbiAgLy8gYmFja2dyb3VuZDogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjgpO1xyXG59XHJcblxyXG4udGFibGUtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4ubG9hZGVyIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgdG9wOiA1MCU7XHJcbiAgbGVmdDogNTAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlKC01MCUsIC01MCUpO1xyXG4gIC0tZDogMjJweDtcclxuICB3aWR0aDogNHB4O1xyXG4gIGhlaWdodDogNHB4O1xyXG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICBjb2xvcjogIzA5YztcclxuICBib3gtc2hhZG93OiBjYWxjKDEgKiB2YXIoLS1kKSkgY2FsYygwICogdmFyKC0tZCkpIDAgMCxcclxuICAgIGNhbGMoMC43MDcgKiB2YXIoLS1kKSkgY2FsYygwLjcwNyAqIHZhcigtLWQpKSAwIDFweCxcclxuICAgIGNhbGMoMCAqIHZhcigtLWQpKSBjYWxjKDEgKiB2YXIoLS1kKSkgMCAycHgsXHJcbiAgICBjYWxjKC0wLjcwNyAqIHZhcigtLWQpKSBjYWxjKDAuNzA3ICogdmFyKC0tZCkpIDAgM3B4LFxyXG4gICAgY2FsYygtMSAqIHZhcigtLWQpKSBjYWxjKDAgKiB2YXIoLS1kKSkgMCA0cHgsXHJcbiAgICBjYWxjKC0wLjcwNyAqIHZhcigtLWQpKSBjYWxjKC0wLjcwNyAqIHZhcigtLWQpKSAwIDVweCxcclxuICAgIGNhbGMoMCAqIHZhcigtLWQpKSBjYWxjKC0xICogdmFyKC0tZCkpIDAgNnB4O1xyXG4gIGFuaW1hdGlvbjogbDI3IDFzIGluZmluaXRlIHN0ZXBzKDgpO1xyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGwyNyB7XHJcbiAgMCUge1xyXG4gICAgdHJhbnNmb3JtOiByb3RhdGUoMGRlZyk7XHJcbiAgfVxyXG5cclxuICAxMDAlIHtcclxuICAgIHRyYW5zZm9ybTogcm90YXRlKDM2MGRlZyk7XHJcbiAgfVxyXG59XHJcblxyXG4ucHJpbWFyeS1za2lsbC1lbGxpcHNpcyB7XHJcbiAgd2hpdGUtc3BhY2U6IG5vd3JhcDtcclxuICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIHRleHQtb3ZlcmZsb3c6IGVsbGlwc2lzO1xyXG4gIG1heC13aWR0aDogMjAwcHg7XHJcbiAgdmVydGljYWwtYWxpZ246IHRvcDtcclxufVxyXG5cclxuLnRvb2x0aXAtY29udGFpbmVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG59XHJcblxyXG4udG9vbHRpcC1jb250YWluZXIgLnRvb2x0aXAtdGV4dCB7XHJcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xyXG4gIHdpZHRoOiAyMDFweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjNTU1O1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA2cHg7XHJcbiAgcGFkZGluZzogNXB4IDA7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgcmlnaHQ6IC0xMDZweDtcclxuICB0b3A6IDMwcHg7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4gIG9wYWNpdHk6IDA7XHJcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjNzO1xyXG59XHJcblxyXG4udG9vbHRpcC1jb250YWluZXI6aG92ZXIgLnRvb2x0aXAtdGV4dCB7XHJcbiAgdmlzaWJpbGl0eTogdmlzaWJsZTtcclxuICBvcGFjaXR5OiAxO1xyXG59XHJcbi53cmFwcGVyIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5sZWZ0LWJhciB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiA1cHg7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMwMDA7IC8qIENoYW5nZSB0byB5b3VyIGRlc2lyZWQgY29sb3IgKi9cclxufVxyXG5cclxuLnRvcC1iYXIge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB0b3A6IDA7XHJcbiAgbGVmdDogMDtcclxuICB3aWR0aDogMTAwJTtcclxuICBoZWlnaHQ6IDVweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwOyAvKiBDaGFuZ2UgdG8geW91ciBkZXNpcmVkIGNvbG9yICovXHJcbn1cclxuXHJcbi5jb250ZW50IHtcclxuICBwYWRkaW5nLWxlZnQ6IDVweDtcclxuICBwYWRkaW5nLXRvcDogNXB4O1xyXG59XHJcbi5wcm9maWxlLWRyb3Bkb3duIHtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1jb250ZW50IHtcclxuICBkaXNwbGF5OiBub25lO1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICByaWdodDogMDtcclxuICB0b3A6IDEwMCU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogd2hpdGU7XHJcbiAgbWluLXdpZHRoOiAyMDBweDtcclxuICBib3gtc2hhZG93OiAwIDhweCAxNnB4IHJnYmEoMCwwLDAsMC4yKTtcclxuICBwYWRkaW5nOiAxMHB4O1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbn1cclxuXHJcbi5kcm9wZG93bi1jb250ZW50IHAge1xyXG4gIG1hcmdpbjogMDtcclxuICBwYWRkaW5nOiA1cHggMDtcclxuICBjb2xvcjogIzMzMztcclxufVxyXG5cclxuLmRyb3Bkb3duLWNvbnRlbnQgc3Ryb25nIHtcclxuICBkaXNwbGF5OiBibG9jaztcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbn1cclxuXHJcbi8qIFNob3cgZHJvcGRvd24gKi9cclxuLmRyb3Bkb3duLWNvbnRlbnQuc2hvdyB7XHJcbiAgZGlzcGxheTogYmxvY2s7XHJcbn1cclxuXHJcbi5wcm9maWxlLXRvb2x0aXAge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgZmxvYXQ6cmlnaHQ7XHJcbiAgbWFyZ2luLWxlZnQ6IDE3cHg7XHJcbiAgbWFyZ2luLXRvcDogNnB4O1xyXG59XHJcblxyXG4ucHJvZmlsZS10b29sdGlwIC50b29sdGlwLXRleHQge1xyXG4gIC8vIHZpc2liaWxpdHk6IGhpZGRlbjtcclxuICB3aWR0aDogNDA5cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZjtcclxuICBjb2xvcjogYmxhY2s7XHJcbiAgYm9yZGVyLXJhZGl1czogNnB4O1xyXG4gIHBhZGRpbmc6IDdweCA4cHg7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgdG9wOiAzMXB4O1xyXG4gIHJpZ2h0OiAtMTk1cHg7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4gIG9wYWNpdHk6IDE7XHJcbiAgdHJhbnNpdGlvbjogb3BhY2l0eSAwLjNzO1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkIHdoaXRlO1xyXG59XHJcblxyXG4vLyAucHJvZmlsZS10b29sdGlwOmhvdmVyIC50b29sdGlwLXRleHQge1xyXG4vLyAgIHZpc2liaWxpdHk6IHZpc2libGU7XHJcbi8vICAgb3BhY2l0eTogMTtcclxuLy8gfVxyXG5cclxuLy8gLnByb2ZpbGUtdG9vbHRpcCAudG9vbHRpcC10ZXh0OjphZnRlciB7XHJcbi8vICAgY29udGVudDogJyc7XHJcbi8vICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4vLyAgIGJvdHRvbTogMTAzJTtcclxuLy8gICByaWdodDogMCU7XHJcbi8vICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVYKC01MCUpO1xyXG4vLyAgIGJvcmRlci13aWR0aDogOHB4O1xyXG4vLyAgIGJvcmRlci1zdHlsZTogc29saWQ7XHJcbi8vICAgYm9yZGVyLWNvbG9yOiB0cmFuc3BhcmVudCB0cmFuc3BhcmVudCB3aGl0ZSB0cmFuc3BhcmVudDtcclxuLy8gfVxyXG4ubGFzdC1pdGVtIHtcclxuICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2RlZTJlNjsgXHJcbn1cclxuLm5hdmlnYXRpb24tbGlua3tcclxuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgYm9yZGVyLXJhZGl1czogOXB4O1xyXG4gIHdpZHRoOiAzNnB4O1xyXG4gIGhlaWdodDogMjhweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbn1cclxuLmJhbm5lci1oZWFkZXJ7XHJcbmRpc3BsYXk6IGZsZXg7XHJcbmhlaWdodDogMTIxcHg7XHJcbmZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbmFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbmFsaWduLXNlbGY6IHN0cmV0Y2g7XHJcbmJhY2tncm91bmQtY29sb3I6ICMwMDM2N2U7XHJcbn1cclxuLmJhbm5lci1pbWFnZXtcclxuaGVpZ2h0OiA0OHB4O1xyXG5wYWRkaW5nOjBweCAxOHB4IDZweCA1cHg7XHJcbmRpc3BsYXk6IGZsZXg7XHJcbmp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuYWxpZ24tc2VsZjogc3RyZXRjaDtcclxufVxyXG4ucHJvZmlsZS1sb2dve1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbmZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbmFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG59XHJcbi5qdW1we1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgaGVpZ2h0OiA2N3B4O1xyXG4gIHBhZGRpbmctbGVmdDogMzJweDtcclxuICAvLyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBhbGlnbi1zZWxmOiBzdHJldGNoO1xyXG59XHJcbi5qdW1wLXRpdGxle1xyXG5jb2xvcjogdmFyKC0tV2hpdGUtY29sLCAjRkZGKTtcclxuZm9udC1mYW1pbHk6IFBvcHBpbnM7XHJcbmZvbnQtc2l6ZTogMzJweDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogNjAwO1xyXG5saW5lLWhlaWdodDogMzRweDtcclxubWFyZ2luLXJpZ2h0OiAzMHB4O1xyXG5tYXJnaW4tYm90dG9tOiA2cHg7XHJcbn1cclxuLnRpdGxlLWRpdntcclxuZGlzcGxheTogZmxleDtcclxuZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbm1hcmdpbi10b3A6MXB4O1xyXG5tYXJnaW4tbGVmdDo2OHB4O1xyXG5cclxufVxyXG4uYXBwbHktYnRue1xyXG5ib3JkZXItcmFkaXVzOiA4cHg7XHJcbmJhY2tncm91bmQ6IHZhcigtLUJyYW5kLW9yYW5nZS1jb2xvciwgI0YyNkMyMSk7XHJcbnBhZGRpbmc6IDRweCAxMnB4O1xyXG5tYXJnaW4tdG9wOiAxMnB4O1xyXG5tYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbn1cclxuLmJhbm5lci1sb2dve1xyXG4gIG1hcmdpbi1yaWdodDogMjJweDtcclxuICBtYXJnaW4tdG9wOiA1cHg7XHJcbiAgICB3aWR0aDogMzUxLjc4cHg7XHJcbiAgICBoZWlnaHQ6IDExNHB4O1xyXG4gIGZsZXgtc2hyaW5rOiAwO1xyXG4gIGJhY2tncm91bmQ6IHVybCguLi8uLi9hc3NldHMvaW1hZ2VzL0pVTVAtYmFubmVyLUlsbHVzdHJhdGlvbi5qcGcpIGxpZ2h0Z3JheSAtMTc2LjAxNnB4IDBweCAvIDE1MS43MDglIDEwMCUgbm8tcmVwZWF0O1xyXG59XHJcbi5zdWItaGVhZGVye1xyXG5jb2xvcjogdmFyKC0tV2hpdGUtY29sLCAjRkZGKTtcclxuZm9udC1mYW1pbHk6IFBvcHBpbnM7XHJcbmZvbnQtc2l6ZTogMjBweDtcclxuZm9udC1zdHlsZTogbm9ybWFsO1xyXG5mb250LXdlaWdodDogNDAwO1xyXG4vLyBtYXJnaW4tbGVmdDo3OHB4O1xyXG5saW5lLWhlaWdodDogMzZweDsgLyogMTIwJSAqL1xyXG5wYWRkaW5nLWxlZnQ6IDc5cHg7XHJcbn1cclxuLmNvbnRlbnQtc2VjdGlvbntcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbnBhZGRpbmc6IDBweCAyOHB4O1xyXG5mbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG5hbGlnbi1pdGVtczogZmxleC1zdGFydDtcclxuZ2FwOiA0MHB4O1xyXG5hbGlnbi1zZWxmOiBzdHJldGNoO1xyXG5tYXJnaW4tdG9wOjRweFxyXG59XHJcbi5pbnB1dC1zZWFyY2hcclxue1xyXG4gIHdpZHRoOiAyMzVweDtcclxuICAvLyBtYXJnaW4tbGVmdDogNXB4O1xyXG4gIC8vIGJvcmRlci1yYWRpdXM6IDEwcHggIWltcG9ydGFudDtcclxuICBoZWlnaHQ6IDM2cHg7XHJcbiAgbWFyZ2luLWxlZnQ6IC0xM3B4O1xyXG59XHJcbi5pbnB1dC1ncm91cCAuZm9ybS1jb250cm9sIHtcclxuICBwYWRkaW5nLXJpZ2h0OiAyLjVyZW07IC8qIEFkanVzdCB0aGlzIHZhbHVlIGlmIG5lZWRlZCAqL1xyXG4gIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDhweDsgLyogQm9yZGVyIHJhZGl1cyBmb3IgdGhlIGlucHV0ICovXHJcbiAgYm9yZGVyLWJvdHRvbS1sZWZ0LXJhZGl1czogOHB4O1xyXG4gIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwOyAvKiBSZW1vdmUgcmlnaHQgYm9yZGVyIHJhZGl1cyAqL1xyXG4gIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiAwO1xyXG4gIHBhZGRpbmctdG9wOiAxNnB4O1xyXG59XHJcblxyXG4uaW5wdXQtZ3JvdXAtYXBwZW5kIHtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgdG9wOiAwO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgcGFkZGluZy10b3A6IDVweDtcclxufVxyXG4vLyAuaW5wdXQtZ3JvdXAtdGV4dCAuYngtc2VhcmNoIHtcclxuLy8gICBjdXJzb3I6IHBvaW50ZXI7XHJcbi8vIH1cclxuLnNlYXJjaHtcclxuICBwYWRkaW5nOiA3cHg7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG59XHJcbi5iYWRnZS1jdXN0b20ge1xyXG4gIC8vIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIC8vIHBhZGRpbmc6IDAuNWVtIDFlbTtcclxuICAvLyBib3JkZXItcmFkaXVzOiAxLjI1cmVtO1xyXG4gIC8vIHdpZHRoOiAxMDAlO1xyXG4gIGZvbnQtd2VpZ2h0OiBib2xkICFpbXBvcnRhbnQ7XHJcbiAgcGFkZGluZzogMC4zZW0gMC41ZW07XHJcbiAgYm9yZGVyLXJhZGl1czogMS4yNXJlbSAhaW1wb3J0YW50O1xyXG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgaGVpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XHJcbiAgZm9udC1zaXplOiAxMnB4ICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNlY3Rpb24tYm9yZGVyIHtcclxuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgYm9yZGVyLXJhZGl1czogOXB4O1xyXG4gIG1hcmdpbi1yaWdodDogMjNweDtcclxuICBtYXJnaW4tYm90dG9tOjZweFxyXG59XHJcbi5kaWFsb2ctb3ZlcmxheSB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIHRvcDogMDtcclxuICBsZWZ0OiAwO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICAvLyBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNSk7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uZGlhbG9nIHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmO1xyXG4gIHBhZGRpbmc6IDIwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xyXG4gIGJveC1zaGFkb3c6IDAgMnB4IDEwcHggcmdiYSgwLCAwLCAwLCAwLjEpO1xyXG4gIHdpZHRoOiAzMDBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5kaWFsb2cgaDIge1xyXG4gIG1hcmdpbi1ib3R0b206IDIwcHg7XHJcbn1cclxuXHJcbi5kaWFsb2cgc2VsZWN0IHtcclxuICB3aWR0aDogMTAwJTtcclxuICBwYWRkaW5nOiA4cHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjBweDtcclxufVxyXG5cclxuLmRpYWxvZy1hY3Rpb25zIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGZsb2F0OiByaWdodDtcclxufVxyXG5cclxuLmRpYWxvZy1hY3Rpb25zIGJ1dHRvbiB7XHJcbiAgcGFkZGluZzogNHB4IDIwcHg7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIGJvcmRlci1yYWRpdXM6IDRweDtcclxuICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgYmxvY2stc2l6ZTogMzZweDtcclxufVxyXG5cclxuLmNsb3NlLXN0YXR1cyB7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxufVxyXG4uYmFkZ2Uge1xyXG4gIGxpbmUtaGVpZ2h0OiAxLjUgIWltcG9ydGFudDtcclxufVxyXG4uc3RhdHVzIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgZ2FwOiA0cHg7XHJcbiAgd2lkdGg6IDg0JTtcclxufVxyXG4uYmFkZ2Utb3BlbiB7XHJcbiAgY29sb3I6IHdoaXRlO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBib3JkZXItcmFkaXVzOiA1cHg7XHJcbiAgd2lkdGg6IDk1JSAhaW1wb3J0YW50O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBoZWlnaHQ6IGF1dG8gIWltcG9ydGFudDtcclxuICBib3JkZXItcmFkaXVzOiAxNnB4ICFpbXBvcnRhbnQ7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbn1cclxuLmRldGFpbHMtY29udGFpbmVyIHtcclxuICBwYWRkaW5nOiAxNnB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmOWY5Zjk7XHJcbiAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICBib3JkZXItcmFkaXVzOiA4cHg7XHJcbn1cclxuXHJcbi5kZXRhaWxzLWNvbnRhaW5lciBoMyB7XHJcbiAgY29sb3I6ICNmZjY2MDA7XHJcbn1cclxuXHJcbi5kZXRhaWwtcm93IHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICBtYXJnaW4tdG9wOiA4cHg7XHJcbn1cclxuXHJcbi5kZXRhaWwtcm93IGRpdiB7XHJcbiAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xyXG59XHJcblxyXG4uZGV0YWlsLXJvdyB1bCB7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIHBhZGRpbmc6IDA7XHJcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xyXG59XHJcblxyXG4uZGV0YWlsLXJvdyB1bCBsaSB7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcbi5qb2ItZGV0YWlscy1oZWFkZXJ7XHJcbiAgY29sb3I6IHJnYigzMywgMzcsIDQxKTsgXHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbi5kZXRhaWxzLXN1Yi1oZWFkZXJ7XHJcbiAgY29sb3I6IHZhcigtLUdyYXktNzAwLCAjMzQ0MDU0KTtcclxuICBmb250LWZhbWlseTogUG9wcGlucztcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xyXG4gIGZvbnQtd2VpZ2h0OiA2MDA7XHJcbiAgbGluZS1oZWlnaHQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5qb2ItZGV0YWlsLWhlYWRlcntcclxuICAgIGNvbG9yOiB2YXIoLS1CcmFuZC1vcmFuZ2UtY29sb3IsICNGMjZDMjEpO1xyXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBsaW5lLWhlaWdodDogMjBweDtcclxuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xyXG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB2YXIoLS1CcmFuZC1vcmFuZ2UtY29sb3IsICNGMjZDMjEpO1xyXG4gIH1cclxuICAuYXBwbGljYXRpb24tc3ViLWhlYWRlcntcclxuICAgIGNvbG9yOiB2YXIoLS1Cb2R5LXRleHQtY29sb3IsICMyMzFGMjApO1xyXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zO1xyXG4gIGZvbnQtc2l6ZTogMTVweDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBsaW5lLWhlaWdodDogMThweDsgLyogMTEyLjUlICovXHJcbiAgfVxyXG5cclxuXHJcbiAgLmZpbGUtaW5wdXQtY29udGFpbmVyIHtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIH1cclxuICBcclxuICAuY3VzdG9tLWZpbGUtdXBsb2FkIHtcclxuICAgIHdpZHRoOiAzMCU7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgICBwYWRkaW5nOiA0cHggMTJweDtcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcclxuICAgIGhlaWdodDogMjhweDtcclxuICB9XHJcbiAgXHJcbiAgI2ltYWdlVXBsb2FkIHtcclxuICAgIHdpZHRoOiAwO1xyXG4gICAgb3BhY2l0eTogMDtcclxuICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICB6LWluZGV4OiAtMTtcclxuICB9XHJcbiAgLmNvbnRpbnVlLWJveCB7XHJcbiAgICBmbGV4OiAxO1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Y0ZGFkYTE0O1xyXG4gICAgcGFkZGluZzogNHB4IDMzcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjRjNGNEY2O1xyXG4gICAgbWluLWhlaWdodDogMjhweDtcclxuICB9XHJcbiAgLnNob3ctRGV0YWlsc3tcclxuICAgIGJhY2tncm91bmQtY29sb3I6IGxpZ2h0Z3JheTtcclxuICB9XHJcbiAgLy8gW0BzbGlkZUluT3V0XT1cInNob3dBcHBseURldGFpbHMgPyAnb3V0JyA6ICdpbidcIiBzdHlsZT1cInRyYW5zaXRpb246IHRyYW5zZm9ybSAwLjVzIGVhc2UtaW4tb3V0O1wiXHJcblxyXG4gIC5uYXYtaXRlbSB7XHJcbiAgfVxyXG4gIC5uYXYtbGluayB7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgbWluLWhlaWdodDogNjBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMDtcclxuICAgIGNvbG9yOiAjNmM3NTdkO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogI2Y4ZjlmYTtcclxuICAgIHRyYW5zaXRpb246IGJhY2tncm91bmQtY29sb3IgMC4zcztcclxuICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICB9XHJcbiAgLm5hdi1saW5rOmhvdmVyLCAubmF2LWxpbmsuYWN0aXZlIHtcclxuICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzZjNzU3ZDtcclxuICB9XHJcbiAgLm5hdi1saW5rIGkge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gIH1cclxuICAuY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAyMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2RkZDtcclxuICAgIGJvcmRlci1sZWZ0OiBub25lO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gIH1cclxuICAudGFiLXBhbmUge1xyXG4gICAgLy8gZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICB9XHJcblxyXG5cclxuXHJcbiAgYm9keSB7XHJcbiAgICBmb250LWZhbWlseTogJ0NpcmN1bGFyIFN0ZCBCb29rJztcclxuICAgIGZvbnQtc3R5bGU6IG5vcm1hbDtcclxuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogIzcxNzQ4ZDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmZmZmY7XHJcbiAgICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcclxufVxyXG5cclxuLm10LTIwe1xyXG4gICAgbWFyZ2luLXRvcDogNTBweCAhaW1wb3J0YW50O1xyXG59XHJcblxyXG4udGFiLXZlcnRpY2FsIC5uYXYubmF2LXRhYnMge1xyXG4gICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICBkaXNwbGF5OiBibG9jaztcclxuICAgIG1hcmdpbi1yaWdodDogMHB4O1xyXG4gICAgYm9yZGVyLWJvdHRvbTogMDtcclxuICAgIHdpZHRoOiAxMDBweDtcclxufVxyXG5cclxuLnRhYi12ZXJ0aWNhbCAubmF2Lm5hdi10YWJzIC5uYXYtaXRlbSB7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA2cHg7XHJcbn1cclxuXHJcbi50YWItdmVydGljYWwgLm5hdi10YWJzIC5uYXYtbGluayB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IC4yNXJlbTtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAuMjVyZW07XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmZmO1xyXG4gICAgcGFkZGluZzogMTdweCA0OXB4O1xyXG4gICAgY29sb3I6ICM3MTc0OGQ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkZGU4O1xyXG4gICAgLXdlYmtpdC1ib3JkZXItcmFkaXVzOiA0cHggMHB4IDBweCA0cHg7XHJcbiAgICAtbW96LWJvcmRlci1yYWRpdXM6IDRweCAwcHggMHB4IDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDRweCAwcHggMHB4IDRweDtcclxufVxyXG5cclxuLnRhYi12ZXJ0aWNhbCAubmF2LXRhYnMgLm5hdi1saW5rLmFjdGl2ZSB7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzAwMzY3ZTtcclxuICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgLy8gYm94LXNoYWRvdzogMCAwIDAgMC4ycmVtIHJnYmEoMCwgMTIzLCAyNTUsIDAuMjUpO1xyXG4gICAgXHJcbn1cclxuLnRhYi12ZXJ0aWNhbCAubmF2LXRhYnMgLm5hdi1saW5rLmFjdGl2ZTo6YWZ0ZXJ7XHJcbiAgY29udGVudDogXCJcIjtcclxuICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgcmlnaHQ6IC0xMHB4OyAvKiBBZGp1c3QgdGhpcyB2YWx1ZSBhcyBuZWVkZWQgKi9cclxuICB0b3A6IDUwJTtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XHJcbiAgd2lkdGg6IDA7XHJcbiAgaGVpZ2h0OiAwO1xyXG4gIGJvcmRlci1sZWZ0OiAxMHB4IHNvbGlkICMwMDM2N2U7XHJcbiAgYm9yZGVyLXRvcDogMTBweCBzb2xpZCB0cmFuc3BhcmVudDtcclxuICBib3JkZXItYm90dG9tOiAxMHB4IHNvbGlkIHRyYW5zcGFyZW50O1xyXG59XHJcblxyXG4udGFiLXZlcnRpY2FsIC5uYXYtdGFicyAubmF2LWxpbmsge1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgdHJhbnNwYXJlbnQ7XHJcbiAgICBib3JkZXItdG9wLWxlZnQtcmFkaXVzOiA0cHggIWltcG9ydGFudDtcclxuICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiAwcHggIWltcG9ydGFudDtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxufVxyXG5cclxuLnRhYi12ZXJ0aWNhbCAudGFiLWNvbnRlbnQge1xyXG4gICAgb3ZlcmZsb3cteDogaGlkZGVuO1xyXG4gICAgLXdlYmtpdC1ib3JkZXItcmFkaXVzOiAwcHggNHB4IDRweCA0cHg7XHJcbiAgICAtbW96LWJvcmRlci1yYWRpdXM6IDBweCA0cHggNHB4IDRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDBweCA0cHggNHB4IDRweDtcclxuICAgIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICBwYWRkaW5nOiAxM3B4O1xyXG4gICAgcGFkZGluZy10b3A6IDhweDtcclxufVxyXG4jY2FuZGlkYXRlTW9kYWwgLm1vZGFsLWNvbnRlbnR7XHJcbiAgbWluLWhlaWdodDogNDAwcHggIWltcG9ydGFudDtcclxuICAubW9kYWwtYm9keXtcclxuICAgIGhlaWdodDogNDMwcHg7XHJcbiAgfVxyXG4gIHRvcDowcmVtO1xyXG4gIGxlZnQ6IC03MDlweDtcclxuICB3aWR0aDogNzEwcHg7XHJcbn1cclxuI25vdGVzIC5tb2RhbC1jb250ZW50e1xyXG4gIG1pbi1oZWlnaHQ6IDQwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLm1vZGFsLWJvZHl7XHJcbiAgICBoZWlnaHQ6IDQzMHB4O1xyXG4gIH1cclxuICB0b3A6MHJlbTtcclxuICBsZWZ0OiAtNTA5cHg7XHJcbiAgd2lkdGg6IDUxMHB4O1xyXG59XHJcbiNoaXN0b3J5IC5tb2RhbC1jb250ZW50e1xyXG4gIG1pbi1oZWlnaHQ6IDQwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLm1vZGFsLWJvZHl7XHJcbiAgICBoZWlnaHQ6IDQzMHB4O1xyXG4gICAgcGFkZGluZzogN3B4IDE1cHg7XHJcbiAgfVxyXG4gIHRvcDowcmVtO1xyXG4gIGxlZnQ6IC03NzhweDtcclxuICB3aWR0aDogNzc5cHg7XHJcbn1cclxuI25vdGVzIC5tb2RhbC1jb250ZW50e1xyXG4gIG1pbi1oZWlnaHQ6IDQwMHB4ICFpbXBvcnRhbnQ7XHJcbiAgLm1vZGFsLWJvZHl7XHJcbiAgICBoZWlnaHQ6IDQzMHB4O1xyXG4gICAgcGFkZGluZzogN3B4IDE1cHg7XHJcbiAgfVxyXG4gIHRvcDowcmVtO1xyXG4gIGxlZnQ6IC01NzhweDtcclxuICB3aWR0aDogNTc5cHg7XHJcbn1cclxuXHJcbi5tb2RhbC1kaWFsb2ctc2xpZGVvdXQge1xyXG4gIHBvc2l0aW9uOiBmaXhlZDtcclxuICBtYXJnaW46IDA7XHJcbiAgcmlnaHQ6IDA7XHJcbiAgaGVpZ2h0OiAxMDAlO1xyXG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlM2QoMTAwJSwgMCwgMCk7XHJcbn1cclxuXHJcbi5tb2RhbC1kaWFsb2ctc2xpZGVvdXQgLm1vZGFsLWNvbnRlbnQge1xyXG4gIGhlaWdodDogMTAwdmg7XHJcbiAgb3ZlcmZsb3cteTogYXV0bztcclxufVxyXG5cclxuLm1vZGFsLnNob3cgLm1vZGFsLWRpYWxvZy1zbGlkZW91dCB7XHJcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGUzZCgwLCAwLCAwKTtcclxufVxyXG5cclxuLm1vZGFsLmZhZGUgLm1vZGFsLWRpYWxvZyB7XHJcbiAgdHJhbnNpdGlvbjogdHJhbnNmb3JtIDAuM3MgZWFzZS1vdXQ7XHJcbn1cclxuXHJcbi5pY29uLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG59XHJcblxyXG4uaWNvbi1pdGVtIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG59XHJcblxyXG4uaWNvbiB7XHJcbiAgZm9udC1zaXplOiAyNHB4O1xyXG4gIG1hcmdpbi1yaWdodDogMXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBjb2xvcjogIzc1NzU3NTtcclxufVxyXG5cclxuLmljb24tbGFiZWwge1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBjb2xvcjogIzU1NTtcclxufVxyXG5cclxuLnByb2dyZXNzLWNvbnRhaW5lciB7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGFsaWduLWl0ZW1zOiBmbGV4LXN0YXJ0O1xyXG4gIC8vIHdpZHRoOiAzMDBweDtcclxufVxyXG5cclxuLnByb2dyZXNzLXRpdGxlIHtcclxuICBmb250LXNpemU6IDEzcHg7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgbWFyZ2luLWJvdHRvbTogMTBweDtcclxufVxyXG5cclxuLnByb2dyZXNzLWxpbmUge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogN3B4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNkZGQ7XHJcbiAgZmxleC1ncm93OiAxO1xyXG4gIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICBtYXJnaW4tYm90dG9tOiAyN3B4O1xyXG59XHJcblxyXG4ucHJvZ3Jlc3Mge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICB3aWR0aDogMTAwJTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmY2NjAwO1xyXG4gIHRvcDogMDtcclxufVxyXG5cclxuLnN0ZXAge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGZsZXgtc3RhcnQ7XHJcbiAgbWFyZ2luLWJvdHRvbTogMjNweDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgZm9udC1zaXplOiAxNXB4O1xyXG59XHJcblxyXG4uc3RlcCAuYnVsbGV0IHtcclxuICB3aWR0aDogMjBweDtcclxuICBoZWlnaHQ6IDIwcHg7XHJcbiAgLy8gYmFja2dyb3VuZC1jb2xvcjogI2ZmNjYwMDtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgY29sb3I6ICNmZmY7XHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHotaW5kZXg6IDE7XHJcbiAgb3BhY2l0eTogMTtcclxufVxyXG5cclxuLnN0ZXAgLmRldGFpbHMge1xyXG4gIG1hcmdpbi1sZWZ0OiAxNHB4O1xyXG59XHJcblxyXG4uc3RlcCAuZGV0YWlscyBkaXYge1xyXG4gIG1hcmdpbi1ib3R0b206IDVweDtcclxufVxyXG4uc2Vjb25kYXJ5LXNraWxsLWVsbGlwc2lzIHtcclxuICB3aGl0ZS1zcGFjZTogbm93cmFwO1xyXG4gIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgdGV4dC1vdmVyZmxvdzogZWxsaXBzaXM7XHJcbiAgbWF4LXdpZHRoOiAxNzJweDtcclxuICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG59XHJcblxyXG4ubm90ZXMtcHJvZ3Jlc3MtbGluZSB7XHJcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gIHdpZHRoOiA4cHg7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogI2RkZDtcclxuICAvLyBmbGV4LWdyb3c6IDE7XHJcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gIG1hcmdpbi1ib3R0b206IDIxcHg7XHJcbn1cclxuXHJcbi5ub3Rlcy1wcm9ncmVzcyB7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gIHdpZHRoOiAxMDAlO1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmZjY2MDA7XHJcbiAgdG9wOiAwO1xyXG4gIGhlaWdodDogMTAwJTtcclxuICBib3JkZXItcmFkaXVzOiA3cHg7XHJcbn1cclxuLm1vZGFsLWNsb3NlLWJ0bntcclxuICBoZWlnaHQ6IDE4cHg7XHJcbiAgY3Vyc29yOiBwb2ludGVyO1xyXG59XHJcbi5zdGF0dXMtZWRpdCB7XHJcbiAgZm9udC1zaXplOiAxNnB4O1xyXG59XHJcbi5jaXJjbGUtYXJyb3cge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICB3aWR0aDogNTBweDtcclxuICBoZWlnaHQ6IDUwcHg7XHJcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gIGJvcmRlcjogMnB4IHNvbGlkICMwMDA7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG59XHJcblxyXG4uY2lyY2xlLWFycm93IC5ieC1yaWdodC1hcnJvdy1hbHQge1xyXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxufVxyXG4ub3Blbi1yb2xlcy1kZXRhaWxze1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcclxuICBoZWlnaHQ6IDM0M3B4O1xyXG4gIG92ZXJmbG93LXk6IGhpZGRlbjtcclxufVxyXG4uZGFzaGJvYXJkLWRldGFpbHN7XHJcbiAgZGlzcGxheTogZmxleDtcclxuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gIGhlaWdodDogMzc0cHg7XHJcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xyXG59XHJcbi8vIGNvbG9yOiAjMTMzQjkzO1xyXG4vLyAuZm9ybS1jb250cm9se1xyXG4vLyAgIGhlaWdodDogMzFweDtcclxuLy8gICBmb250LXNpemU6IDEzcHg7XHJcbi8vIH1cclxuLmZvcm0tZGV0YWlsc3tcclxuICBoZWlnaHQ6IDMxcHg7XHJcbiAgZm9udC1zaXplOiAxM3B4O1xyXG59XHJcbmxhYmVse1xyXG4gIGhlaWdodDogMTNweDtcclxufVxyXG4udGV4dC1kZXNje1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjZmZmZmZmO1xyXG4gIHJlc2l6ZTogbm9uZTtcclxufVxyXG4ubm90ZXMtYm9yZGVye1xyXG4gIGJvcmRlcjogbm9uZTtcclxufVxyXG4ubm90ZS1kYXRle1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxufVxyXG4uZGV0YWlsc3tcclxuICBmb250LXNpemU6IDEzcHg7XHJcbn1cclxuLmRpYWxvZy1jb250YWluZXIge1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICBiYWNrZ3JvdW5kOiB3aGl0ZTsgLyogb3IgYW55IGJhY2tncm91bmQgY29sb3IgeW91IHByZWZlciAqL1xyXG4gIGJvcmRlcjogMXB4IHNvbGlkICNjY2M7XHJcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgLy8gei1pbmRleDogMTA7IFxyXG59XHJcblxyXG4vKiBQb3NpdGlvbmluZyB0aGUgZGlhbG9nICovXHJcbi5kaWFsb2ctY29udGFpbmVyIHtcclxuICB0b3A6IDEwMCU7XHJcbiAgbGVmdDogMDtcclxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoNXB4KTtcclxufVxyXG4uYmFkZ2Uge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICB3aWR0aDogNDBweDsgLyogQWRqdXN0IHNpemUgYXMgbmVlZGVkICovXHJcbiAgaGVpZ2h0OiA0MHB4OyAvKiBBZGp1c3Qgc2l6ZSBhcyBuZWVkZWQgKi9cclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogIzM0OThkYjsgLyogQmFkZ2UgYmFja2dyb3VuZCBjb2xvciAqL1xyXG4gIGNvbG9yOiB3aGl0ZTsgLyogVGV4dCBjb2xvciAqL1xyXG4gIGZvbnQtc2l6ZTogMTZweDsgLyogRm9udCBzaXplICovXHJcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7IC8qIEZvbnQgd2VpZ2h0ICovXHJcbn1cclxuXHJcbi5iYWRnZS10ZXh0IHtcclxuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyAvKiBFbnN1cmUgbGV0dGVycyBhcmUgdXBwZXJjYXNlICovXHJcbn1cclxuLy8gc2VhcmNoLWJ0biBib3JkZXJcclxuLy8gYm94LXNoYWRvdzogMHB4IDFweCAycHggMHB4IHJnYmEoMTYsIDI0LCA0MCwgMC4wNSk7aGVpZ2h0OjM2cHg7XHJcblxyXG4vLyAgICAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcclxuLy8gYm9yZGVyLWJvdHRvbTogNXB4IHNvbGlkICNmNGY4ZmJcclxuLmNvbnRhY3Qge1xyXG4gIGNvbG9yOiB2YXIoLS1XaGl0ZS1jb2wsICNGRkYpO1xyXG4gIGZvbnQtZmFtaWx5OiBQb3BwaW5zLCBzYW5zLXNlcmlmO1xyXG4gIGZvbnQtc2l6ZTogMTNweDtcclxuICBmb250LXN0eWxlOiBub3JtYWw7XHJcbiAgZm9udC13ZWlnaHQ6IDQwMDtcclxuICBtYXJnaW4tcmlnaHQ6MjBweDtcclxuICBsaW5lLWhlaWdodDogMzZweDsvKiAxMjAlICovXHJcbiAgcGFkZGluZy1sZWZ0OiA3OXB4O1xyXG59XHJcblxyXG4ubWF0VGFiIHtcclxuICBtYXJnaW4tdG9wOiAyMHB4O1xyXG59Il19 */"];
      /***/
    },

    /***/
    "vY5A":
    /*!***************************************!*\
      !*** ./src/app/app-routing.module.ts ***!
      \***************************************/

    /*! exports provided: AppRoutingModule */

    /***/
    function vY5A(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
        return AppRoutingModule;
      });
      /* harmony import */


      var _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./job-mobility/job-mobility.component */
      "SDTg");
      /* harmony import */


      var _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./job-details/job-details.component */
      "HJCg"); // import { LandingComponent } from './landing/landing.component';;


      var routes = [{
        path: '',
        component: _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_0__["JobMobilityComponent"]
      }, {
        path: 'jump',
        component: _job_mobility_job_mobility_component__WEBPACK_IMPORTED_MODULE_0__["JobMobilityComponent"]
      }, {
        path: 'job-details',
        component: _job_details_job_details_component__WEBPACK_IMPORTED_MODULE_1__["JobDetailsComponent"]
      }];

      var AppRoutingModule = function AppRoutingModule() {
        _classCallCheck(this, AppRoutingModule);
      };
      /***/

    },

    /***/
    "yvrC":
    /*!********************************************!*\
      !*** ./src/app/app.component.ngfactory.js ***!
      \********************************************/

    /*! exports provided: RenderType_AppComponent, View_AppComponent_0, View_AppComponent_Host_0, AppComponentNgFactory */

    /***/
    function yvrC(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "RenderType_AppComponent", function () {
        return RenderType_AppComponent;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_AppComponent_0", function () {
        return View_AppComponent_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "View_AppComponent_Host_0", function () {
        return View_AppComponent_Host_0;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AppComponentNgFactory", function () {
        return AppComponentNgFactory;
      });
      /* harmony import */


      var _app_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./app.component.scss.shim.ngstyle */
      "OvOj");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "iInd");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/common */
      "SVse");
      /* harmony import */


      var _app_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./app.component */
      "Sy1n");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");
      /**
       * @fileoverview This file was generated by the Angular template compiler. Do not edit.
       *
       * @suppress {suspiciousCode,uselessCode,missingProperties,missingOverride,checkTypes,extraRequire}
       * tslint:disable
       */


      var styles_AppComponent = [_app_component_scss_shim_ngstyle__WEBPACK_IMPORTED_MODULE_0__["styles"]];

      var RenderType_AppComponent = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵcrt"]({
        encapsulation: 0,
        styles: styles_AppComponent,
        data: {}
      });

      function View_AppComponent_1(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [["class", "loader-background"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 0, null, null, 1, "div", [["class", "loaderDiv"]], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](2, 0, null, null, 0, "img", [["src", "../../assets/images/Loader-150X150-Alpha.gif"], ["style", "height: 80px;"]], null, null, null, null, null))], null, null);
      }

      function View_AppComponent_2(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 2, "div", [], null, null, null, null, null)), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](1, 16777216, null, null, 1, "router-outlet", [], null, null, null, null, null)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](2, 212992, null, 0, _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterOutlet"], [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ChildrenOutletContexts"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ComponentFactoryResolver"], [8, null], _angular_core__WEBPACK_IMPORTED_MODULE_1__["ChangeDetectorRef"]], null, null)], function (_ck, _v) {
          _ck(_v, 2, 0);
        }, null);
      }

      function View_AppComponent_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AppComponent_1)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null), (_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵand"](16777216, null, null, 1, null, View_AppComponent_2)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](3, 16384, null, 0, _angular_common__WEBPACK_IMPORTED_MODULE_3__["NgIf"], [_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewContainerRef"], _angular_core__WEBPACK_IMPORTED_MODULE_1__["TemplateRef"]], {
          ngIf: [0, "ngIf"]
        }, null)], function (_ck, _v) {
          var _co = _v.component;
          var currVal_0 = _co.loading;

          _ck(_v, 1, 0, currVal_0);

          var currVal_1 = !_co.loading;

          _ck(_v, 3, 0, currVal_1);
        }, null);
      }

      function View_AppComponent_Host_0(_l) {
        return _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵvid"](0, [(_l()(), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵeld"](0, 0, null, null, 1, "app-root", [], null, null, null, View_AppComponent_0, RenderType_AppComponent)), _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵdid"](1, 49152, null, 0, _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["DomSanitizer"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], _angular_platform_browser__WEBPACK_IMPORTED_MODULE_5__["Title"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]], null, null)], null, null);
      }

      var AppComponentNgFactory = _angular_core__WEBPACK_IMPORTED_MODULE_1__["ɵccf"]("app-root", _app_component__WEBPACK_IMPORTED_MODULE_4__["AppComponent"], View_AppComponent_Host_0, {}, {}, []);
      /***/

    },

    /***/
    "zUnb":
    /*!*********************!*\
      !*** ./src/main.ts ***!
      \*********************/

    /*! no exports provided */

    /***/
    function zUnb(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "8Y7J");
      /* harmony import */


      var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./environments/environment */
      "AytR");
      /* harmony import */


      var _app_app_module_ngfactory__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./app/app.module.ngfactory */
      "Ss9G");
      /* harmony import */


      var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/platform-browser */
      "cUpR");

      if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__["environment"].production) {
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
      }

      _angular_platform_browser__WEBPACK_IMPORTED_MODULE_3__["platformBrowser"]().bootstrapModuleFactory(_app_app_module_ngfactory__WEBPACK_IMPORTED_MODULE_2__["AppModuleNgFactory"])["catch"](function (err) {
        return console.error(err);
      });
      /***/

    },

    /***/
    "zn8P":
    /*!******************************************************!*\
      !*** ./$$_lazy_route_resource lazy namespace object ***!
      \******************************************************/

    /*! no static exports found */

    /***/
    function zn8P(module, exports) {
      function webpackEmptyAsyncContext(req) {
        // Here Promise.resolve().then() is used instead of new Promise() to prevent
        // uncaught exception popping up in devtools
        return Promise.resolve().then(function () {
          var e = new Error("Cannot find module '" + req + "'");
          e.code = 'MODULE_NOT_FOUND';
          throw e;
        });
      }

      webpackEmptyAsyncContext.keys = function () {
        return [];
      };

      webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
      module.exports = webpackEmptyAsyncContext;
      webpackEmptyAsyncContext.id = "zn8P";
      /***/
    }
  }, [[0, "runtime", "vendor"]]]);
})();
//# sourceMappingURL=main-es5.js.map