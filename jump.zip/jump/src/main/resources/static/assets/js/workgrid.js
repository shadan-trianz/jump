showWorkgridToolbar({
  toolbarId: sessionStorage.getItem('wToolbarId'),
  version: sessionStorage.getItem('wGridVersion'),
  companyCode: sessionStorage.getItem('companyCode'),
  spaceId: sessionStorage.getItem('spaceId'),
  clientId: sessionStorage.getItem('clientId'),
  tenantId: sessionStorage.getItem('tenantId'),
  authorizerUrl: sessionStorage.getItem('authorizerUrl')
});



